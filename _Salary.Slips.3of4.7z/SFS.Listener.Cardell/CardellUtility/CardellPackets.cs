﻿using SFS.ConfigManager;

namespace SFS.Listener.Cardell.CardellUtility
{
    public static class CardellPackets
    {
        /// <summary>
        /// Get Connect_Req_Length
        /// </summary>
        /// <CreatedBy>Om Shakya</CreatedBy>
        /// <CreatedDate>Oct 2016</CreatedDate>
        /// <ModifyBy>...</ModifyBy>
        /// <ModifyDate>...</ModifyDate>
        public static int Connect_Req_Length
        {
            get { return AppConfigurations.Cardell_Connect_Req_Length; }
        }
        /// <summary>
        /// Get Connect_Accept_Length
        /// </summary>
        /// <CreatedBy>Om Shakya</CreatedBy>
        /// <CreatedDate>Oct 2016</CreatedDate>
        /// <ModifyBy>...</ModifyBy>
        /// <ModifyDate>...</ModifyDate>
        public static int Connect_Accept_Length
        {
            get { return AppConfigurations.Cardell_Connect_Accept_Length; ; }
        }
        /// <summary>
        /// Get Connect_REQ_Length_Heartbeat
        /// </summary>
        /// <CreatedBy>Om Shakya</CreatedBy>
        /// <CreatedDate>Oct 2016</CreatedDate>
        /// <ModifyBy>...</ModifyBy>
        /// <ModifyDate>...</ModifyDate>
        public static int Connect_REQ_Length_Heartbeat
        {
            get { return AppConfigurations.Cardell_Connect_REQ_Length_heartbeat; }
        }
        /// <summary>
        /// Get Connect_ACCEPT_Length_Receive_patient
        /// </summary>
        /// <CreatedBy>Om Shakya</CreatedBy>
        /// <CreatedDate>Oct 2016</CreatedDate>
        /// <ModifyBy>...</ModifyBy>
        /// <ModifyDate>...</ModifyDate>
        public static int Connect_ACCEPT_Length_Receive_patient
        {
            get { return AppConfigurations.Cardell_Connect_ACCEPT_Length_Receive_patient; }
        }
        /// <summary>
        /// Get Disconnect_Req_Length
        /// </summary>
        /// <CreatedBy>Om Shakya</CreatedBy>
        /// <CreatedDate>Oct 2016</CreatedDate>
        /// <ModifyBy>...</ModifyBy>
        /// <ModifyDate>...</ModifyDate>
        public static int Disconnect_Req_Length
        {
            get { return AppConfigurations.Cardell_Disconnect_Req_Length; }
        }
        /// <summary>
        /// Get Connect_FIRSTSEND_Length
        /// </summary>
        /// <CreatedBy>Om Shakya</CreatedBy>
        /// <CreatedDate>Oct 2016</CreatedDate>
        /// <ModifyBy>...</ModifyBy>
        /// <ModifyDate>...</ModifyDate>
        public static int Connect_FIRSTSEND_Length
        {
            get { return AppConfigurations.Cardell_FIRSTSEND_Req_Length; }
        }
        /// <summary>
        /// Method FIRSTSEND
        /// </summary>
        /// <returns></returns>
        /// <CreatedBy>Om Shakya</CreatedBy>
        /// <CreatedDate>Oct 2016</CreatedDate>
        /// <ModifyBy>...</ModifyBy>
        /// <ModifyDate>...</ModifyDate>
        public static byte[] FIRSTSEND()
        {
            byte[] bytes = null;
            try
            {
                //BB-BB-01-01-09-00-03-00-0E-EE-EE
                bytes = new byte[CardellPackets.Connect_FIRSTSEND_Length];
                // Monitor Model Packet
                bytes[0] = 0xBB;
                bytes[1] = 0xBB;
                bytes[2] = 0x01;
                bytes[3] = 0x01;
                bytes[4] = 0x09;
                bytes[5] = 0x00;
                bytes[6] = 0x03;
                bytes[7] = 0x00;
                bytes[8] = 0x0E;
                bytes[9] = 0xEE;
                bytes[10] = 0xEE;
                bytes[11] = 0x00;
                // Moduler Information Packet
                //BB-BB-03-01-0F-00-31-03-04-00-01-00-00-00-4C-EE-EE
                bytes[12] = 0xBB;
                bytes[13] = 0xBB;
                bytes[14] = 0x03;
                bytes[15] = 0x01;
                bytes[16] = 0x0F;
                bytes[17] = 0x00;
                bytes[18] = 0x31;
                bytes[19] = 0x03;
                bytes[20] = 0x04;
                bytes[21] = 0x00;
                bytes[22] = 0x01;
                bytes[23] = 0x00;
                bytes[24] = 0x00;
                bytes[25] = 0x00;
                bytes[26] = 0x4C;
                bytes[27] = 0xEE;
                bytes[28] = 0xEE;
                bytes[29] = 0x00;
                //Patient information Packet
                //BB-BB-05-01-B9-03-01-00-00-00-00-00-00-C3-EE-EE
                bytes[30] = 0xBB;
                bytes[31] = 0xBB;
                bytes[32] = 0x05;
                bytes[33] = 0x01;
                bytes[34] = 0xB9;
                bytes[35] = 0x03;
                bytes[36] = 0x01;
                bytes[37] = 0x00;
                bytes[38] = 0x00;
                bytes[39] = 0x00;
                bytes[40] = 0x00;
                bytes[41] = 0x00;
                bytes[42] = 0x00;
                bytes[43] = 0xC3;
                bytes[44] = 0xEE;
                bytes[45] = 0xEE;
                bytes[46] = 0x00;
                // Network Control Packet
                // BB-BB-1E-01-0B-00-02-00-00-01-2D-EE-EE
                bytes[47] = 0xBB;
                bytes[48] = 0xBB;
                bytes[49] = 0x1E;
                bytes[50] = 0x01;
                bytes[51] = 0x0B;
                bytes[52] = 0x00;
                bytes[53] = 0x02;
                bytes[54] = 0x00;
                bytes[55] = 0x00;
                bytes[56] = 0x01;
                bytes[57] = 0x2D;
                bytes[58] = 0xEE;
                bytes[59] = 0xEE;
                bytes[60] = 0x00;
                return bytes;
            }
            catch
            {
                throw;
            }
        }
        /// <summary>
        /// Method CONNECT_REQ
        /// </summary>
        /// <returns></returns>
        /// <CreatedBy>Om Shakya</CreatedBy>
        /// <CreatedDate>Oct 2016</CreatedDate>
        /// <ModifyBy>...</ModifyBy>
        /// <ModifyDate>...</ModifyDate>
        public static byte[] CONNECT_REQ()
        {
            byte[] bytes = null;
            try
            {
                bytes = new byte[Connect_Req_Length];
                bytes[0] = 0xBB;
                bytes[1] = 0xBB;
                bytes[2] = 0x09;
                bytes[3] = 0x01;
                bytes[4] = 0x0D;
                bytes[5] = 0x00;
                bytes[6] = 0xFE;
                bytes[7] = 0x00;
                bytes[8] = 0x01;
                bytes[9] = 0x00;
                bytes[10] = 0x03;
                bytes[11] = 0x00;
                bytes[12] = 0x1A;
                bytes[13] = 0xEE;
                bytes[14] = 0xEE;
                bytes[15] = 0x00;
                return bytes;
            }
            catch
            {
                throw;
            }
        }
        /// <summary>
        /// Method CONNECT_ACCEPT
        /// </summary>
        /// <param name="bedNum"></param>
        /// <returns></returns>
        /// <CreatedBy>Om Shakya</CreatedBy>
        /// <CreatedDate>Oct 2016</CreatedDate>
        /// <ModifyBy>...</ModifyBy>
        /// <ModifyDate>...</ModifyDate>
        public static byte[] CONNECT_ACCEPT(ushort bedNum)
        {
            byte[] bytes = null;
            try
            {
                bytes = new byte[Connect_Accept_Length];
                bytes[0] = 0xBB;
                bytes[1] = 0xBB;
                bytes[2] = 0x0A;
                bytes[3] = (byte)bedNum;
                bytes[4] = 0x09;
                bytes[5] = 0x00;
                bytes[6] = 0x00;
                bytes[7] = 0x00;
                bytes[8] = 0x14;
                bytes[9] = 0xEE;
                bytes[10] = 0xEE;
                return bytes;
            }
            catch
            {
                throw;
            }
        }
        /// <summary>
        /// Method DISCONNECT_REQ
        /// </summary>
        /// <returns></returns>
        /// <CreatedBy>Om Shakya</CreatedBy>
        /// <CreatedDate>Oct 2016</CreatedDate>
        /// <ModifyBy>...</ModifyBy>
        /// <ModifyDate>...</ModifyDate>
        public static byte[] DISCONNECT_REQ()
        {
            byte[] bytes = null;
            try
            {
                bytes = new byte[Disconnect_Req_Length];
                bytes[0] = 0xC0;
                bytes[1] = 0x03;
                bytes[2] = 16;
                return bytes;
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Method HEARTBEAT_REQ
        /// </summary>
        /// <returns></returns>
        /// <CreatedBy>Om Shakya</CreatedBy>
        /// <CreatedDate>Oct 2016</CreatedDate>
        /// <ModifyBy>...</ModifyBy>
        /// <ModifyDate>...</ModifyDate>
        public static byte[] HEARTBEAT_REQ()
        {
            byte[] bytes = null;
            try
            {
                bytes = new byte[Connect_REQ_Length_Heartbeat];
                bytes[0] = 0xBB;
                bytes[1] = 0xBB;
                bytes[2] = 0x08;
                bytes[3] = 0x01;
                bytes[4] = 0x07;
                bytes[5] = 0x00;
                bytes[6] = 0x10;
                bytes[7] = 0xEE;
                bytes[8] = 0xEE;
                bytes[9] = 0x00;
                return bytes;
            }
            catch
            {
                throw;
            }
        }
        /// <summary>
        /// Method RECEIVEPATIENT_ACCEPT
        /// </summary>
        /// <param name="bedNum"></param>
        /// <returns></returns>
        /// <CreatedBy>Om Shakya</CreatedBy>
        /// <CreatedDate>Oct 2016</CreatedDate>
        /// <ModifyBy>...</ModifyBy>
        /// <ModifyDate>...</ModifyDate>
        public static byte[] RECEIVEPATIENT_ACCEPT(ushort bedNum)
        {
            byte[] bytes = null;
            try
            {
                bytes = new byte[Connect_ACCEPT_Length_Receive_patient];
                bytes[0] = 0xBB;
                bytes[1] = 0xBB;
                bytes[2] = 0x06;
                bytes[3] = (byte)bedNum;
                bytes[4] = 0x00;
                bytes[5] = 0x00;
                bytes[6] = 0x00;
                bytes[7] = 0x00;
                bytes[8] = 0x07;
                bytes[9] = 0xEE;
                bytes[10] = 0xEE;
                return bytes;
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Method Data_Ack_Length
        /// </summary>
        /// <CreatedBy>Om Shakya</CreatedBy>
        /// <CreatedDate>Oct 2016</CreatedDate>
        /// <ModifyBy>...</ModifyBy>
        /// <ModifyDate>...</ModifyDate>
        public static int Data_Ack_Length
        {
            get { return AppConfigurations.Cardell_Data_Ack_Length; }
        }
        /// <summary>
        /// Method DATA_ACK
        /// </summary>
        /// <param name="bedNum"></param>
        /// <returns></returns>
        /// <CreatedBy>Om Shakya</CreatedBy>
        /// <CreatedDate>Oct 2016</CreatedDate>
        /// <ModifyBy>...</ModifyBy>
        /// <ModifyDate>...</ModifyDate>
        public static byte[] DATA_ACK(ushort bedNum)
        {
            byte[] bytes = null;
            try
            {
                bytes = new byte[Data_Ack_Length];
                bytes[0] = 0xD2;
                bytes[1] = 0x01;
                bytes[2] = (byte)bedNum;
                return bytes;
            }
            catch
            {
                throw;
            }
        }
    }
}
