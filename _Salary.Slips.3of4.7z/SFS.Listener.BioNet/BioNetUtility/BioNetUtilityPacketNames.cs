﻿namespace SFS.Listener.BioNet.BioNetUtility
{
    /// <summary>
    /// BioNet Utility Information Packets Class.
    /// </summary>
    /// <CreatedBy>Om Shakya</CreatedBy>
    /// <CreatedDate>Sep 2015</CreatedDate>
    /// <ModifyBy>...</ModifyBy>
    /// <ModifyDate>...</ModifyDate>
    public static class BioNetUtilityPacketNames
    {
        /// <summary>
        /// Get CONNECT_REQ req name, (It is fixed representation of individual packet as per Bionet protocol documentation).
        /// </summary>
        public static string CONNECT_REQ { get { return "CONNECT_REQ"; } }
        /// <summary>
        /// Get CONNECT_ACCEPT req name, (It is fixed representation of individual packet as per Bionet protocol documentation).
        /// </summary>
        /// <CreatedBy>Om Shakya</CreatedBy>
        /// <CreatedDate>Sep 2015</CreatedDate>
        /// <ModifyBy>...</ModifyBy>
        /// <ModifyDate>...</ModifyDate>
        public static string CONNECT_ACCEPT { get { return "CONNECT_ACCEPT"; } }
        /// <summary>
        /// Get DISCONNECT_REQ req name, (It is fixed representation of individual packet as per Bionet protocol documentation).
        /// </summary>
        /// <CreatedBy>Om Shakya</CreatedBy>
        /// <CreatedDate>Sep 2015</CreatedDate>
        /// <ModifyBy>...</ModifyBy>
        /// <ModifyDate>...</ModifyDate>
        public static string DISCONNECT_REQ { get { return "DISCONNECT_REQ"; } }
        /// <summary>
        /// Get DATA_ACK req name, (It is fixed representation of individual packet as per Bionet protocol documentation).
        /// </summary>
        /// <CreatedBy>Om Shakya</CreatedBy>
        /// <CreatedDate>Sep 2015</CreatedDate>
        /// <ModifyBy>...</ModifyBy>
        /// <ModifyDate>...</ModifyDate>
        public static string DATA_ACK { get { return "DATA_ACK"; } }
        /// <summary>
        /// Get USER_INFO req name, (It is fixed representation of individual packet as per Bionet protocol documentation).
        /// </summary>
        /// <CreatedBy>Om Shakya</CreatedBy>
        /// <CreatedDate>Sep 2015</CreatedDate>
        /// <ModifyBy>...</ModifyBy>
        /// <ModifyDate>...</ModifyDate>
        public static string USER_INFO { get { return "USER_INFO"; } }
        /// <summary>
        /// Get ADMIT_INFO req name, (It is fixed representation of individual packet as per Bionet protocol documentation).
        /// </summary>
        /// <CreatedBy>Om Shakya</CreatedBy>
        /// <CreatedDate>Sep 2015</CreatedDate>
        /// <ModifyBy>...</ModifyBy>
        /// <ModifyDate>...</ModifyDate>
        public static string ADMIT_INFO { get { return "ADMIT_INFO"; } }
        /// <summary>
        /// Get ALARM_INFO req name, (It is fixed representation of individual packet as per Bionet protocol documentation).
        /// </summary>
        /// <CreatedBy>Om Shakya</CreatedBy>
        /// <CreatedDate>Sep 2015</CreatedDate>
        /// <ModifyBy>...</ModifyBy>
        /// <ModifyDate>...</ModifyDate>
        public static string ALARM_INFO { get { return "ALARM_INFO"; } }
        /// <summary>
        /// Get SETTING_INFO req name, (It is fixed representation of individual packet as per Bionet protocol documentation).
        /// </summary>
        /// <CreatedBy>Om Shakya</CreatedBy>
        /// <CreatedDate>Sep 2015</CreatedDate>
        /// <ModifyBy>...</ModifyBy>
        /// <ModifyDate>...</ModifyDate>
        public static string SETTING_INFO { get { return "SETTING_INFO"; } }
        /// <summary>
        /// Get PARAMETER_DATA req name, (It is fixed representation of individual packet as per Bionet protocol documentation).
        /// </summary>
        /// <CreatedBy>Om Shakya</CreatedBy>
        /// <CreatedDate>Sep 2015</CreatedDate>
        /// <ModifyBy>...</ModifyBy>
        /// <ModifyDate>...</ModifyDate>
        public static string PARAMETER_DATA { get { return "PARAMETER_DATA"; } }
    }
}
