﻿using System;
using System.Configuration;

namespace SFS.ConfigManager
{
    /// <summary>
    /// Class for application configuration settings.
    /// </summary>
    /// <CreatedBy>Om Shakya</CreatedBy>
    /// <CreatedDate>Aug 2016</CreatedDate>
    /// <ModifyBy>...</ModifyBy>
    /// <ModifyDate>...</ModifyDate>
    public static class AppConfigurations
    {
        #region BioNet
        /// <summary>
        /// Get BioNet Server Port.
        /// </summary>
        /// <CreatedBy>Om Shakya</CreatedBy>
        /// <CreatedDate>Sep 2015</CreatedDate>
        /// <ModifyBy>...</ModifyBy>
        /// <ModifyDate>...</ModifyDate>
        public static int BioNet_ServerPort
        {
            get
            {
                int bioNetServerPort = 0;
                string configVal = ConfigurationManager.AppSettings["BioNet_ServerPort"];
                if (!string.IsNullOrEmpty(configVal))
                    int.TryParse(configVal, out bioNetServerPort);
                return bioNetServerPort;
            }
        }
        /// <summary>
        /// Get BioNet_Connect_Req_Length (It is fixed as per Bionet protocol documentation).
        /// </summary>
        /// <CreatedBy>Om Shakya</CreatedBy>
        /// <CreatedDate>Sep 2015</CreatedDate>
        /// <ModifyBy>...</ModifyBy>
        /// <ModifyDate>...</ModifyDate>
        public static int BioNet_Connect_Req_Length
        {
            get
            {
                //It is fixed length
                int length = 3;
                string configVal = ConfigurationManager.AppSettings["BioNet_Connect_Req_Length"];
                if (!string.IsNullOrEmpty(configVal))
                    int.TryParse(configVal, out length);
                return length;
            }
        }
        /// <summary>
        /// Get BioNet_Connect_Accept_Length (It is fixed as per Bionet protocol documentation).
        /// </summary>
        /// <CreatedBy>Om Shakya</CreatedBy>
        /// <CreatedDate>Sep 2015</CreatedDate>
        /// <ModifyBy>...</ModifyBy>
        /// <ModifyDate>...</ModifyDate>
        public static int BioNet_Connect_Accept_Length
        {
            get
            {
                //It is fixed length
                int length = 3;
                string configVal = ConfigurationManager.AppSettings["BioNet_Connect_Accept_Length"];
                if (!string.IsNullOrEmpty(configVal))
                    int.TryParse(configVal, out length);
                return length;
            }
        }
        /// <summary>
        /// Get BioNet_Disconnect_Req_Length (It is fixed as per Bionet protocol documentation).
        /// </summary>
        /// <CreatedBy>Om Shakya</CreatedBy>
        /// <CreatedDate>Sep 2015</CreatedDate>
        /// <ModifyBy>...</ModifyBy>
        /// <ModifyDate>...</ModifyDate>
        public static int BioNet_Disconnect_Req_Length
        {
            get
            {
                //It is fixed length
                int length = 3;
                string configVal = ConfigurationManager.AppSettings["BioNet_Disconnect_Req_Length"];
                if (!string.IsNullOrEmpty(configVal))
                    int.TryParse(configVal, out length);
                return length;
            }
        }
        /// <summary>
        /// Get BioNet_Data_Ack_Length (It is fixed as per Bionet protocol documentation).
        /// </summary>
        /// <CreatedBy>Om Shakya</CreatedBy>
        /// <CreatedDate>Sep 2015</CreatedDate>
        /// <ModifyBy>...</ModifyBy>
        /// <ModifyDate>...</ModifyDate>
        public static int BioNet_Data_Ack_Length
        {
            get
            {
                //It is fixed length
                int length = 3;
                string configVal = ConfigurationManager.AppSettings["BioNet_Data_Ack_Length"];
                if (!string.IsNullOrEmpty(configVal))
                    int.TryParse(configVal, out length);
                return length;
            }
        }
        /// <summary>
        /// Get BioNet_Parameter_Data_Length (It is fixed as per Bionet protocol documentation).
        /// </summary>
        /// <CreatedBy>Om Shakya</CreatedBy>
        /// <CreatedDate>Sep 2015</CreatedDate>
        /// <ModifyBy>...</ModifyBy>
        /// <ModifyDate>...</ModifyDate>
        public static int BioNet_Parameter_Data_Length
        {
            get
            {
                //It is fixed length
                int length = 53;
                string configVal = ConfigurationManager.AppSettings["BioNet_Parameter_Data_Length"];
                if (!string.IsNullOrEmpty(configVal))
                    int.TryParse(configVal, out length);
                return length;
            }
        }
        /// <summary>
        /// Get BioNet_User_Info_Length (It is fixed as per Bionet protocol documentation).
        /// </summary>
        /// <CreatedBy>Om Shakya</CreatedBy>
        /// <CreatedDate>Sep 2015</CreatedDate>
        /// <ModifyBy>...</ModifyBy>
        /// <ModifyDate>...</ModifyDate>
        public static int BioNet_User_Info_Length
        {
            get
            {
                //It is fixed length
                int length = 23;
                string configVal = ConfigurationManager.AppSettings["BioNet_User_Info_Length"];
                if (!string.IsNullOrEmpty(configVal))
                    int.TryParse(configVal, out length);
                return length;
            }
        }
        /// <summary>
        /// Get BioNet_Admit_Info_Length (It is fixed as per Bionet protocol documentation).
        /// </summary>
        /// <CreatedBy>Om Shakya</CreatedBy>
        /// <CreatedDate>Sep 2015</CreatedDate>
        /// <ModifyBy>...</ModifyBy>
        /// <ModifyDate>...</ModifyDate>
        public static int BioNet_Admit_Info_Length
        {
            get
            {
                //It is fixed length
                int length = 49;
                string configVal = ConfigurationManager.AppSettings["BioNet_Admit_Info_Length"];
                if (!string.IsNullOrEmpty(configVal))
                    int.TryParse(configVal, out length);
                return length;
            }
        }
        /// <summary>
        /// Get BioNet_Alarm_Info_Length (It is fixed as per Bionet protocol documentation).
        /// </summary>
        /// <CreatedBy>Om Shakya</CreatedBy>
        /// <CreatedDate>Sep 2015</CreatedDate>
        /// <ModifyBy>...</ModifyBy>
        /// <ModifyDate>...</ModifyDate>
        public static int BioNet_Alarm_Info_Length
        {
            get
            {
                //It is fixed length
                int length = 95;
                string configVal = ConfigurationManager.AppSettings["BioNet_Alarm_Info_Length"];
                if (!string.IsNullOrEmpty(configVal))
                    int.TryParse(configVal, out length);
                return length;
            }
        }
        /// <summary>
        /// Get BioNet_Setting_Info_Length (It is fixed as per Bionet protocol documentation).
        /// </summary>
        /// <CreatedBy>Om Shakya</CreatedBy>
        /// <CreatedDate>Sep 2015</CreatedDate>
        /// <ModifyBy>...</ModifyBy>
        /// <ModifyDate>...</ModifyDate>
        public static int BioNet_Setting_Info_Length
        {
            get
            {
                //It is fixed length
                int length = 22;
                string configVal = ConfigurationManager.AppSettings["BioNet_Setting_Info_Length"];
                if (!string.IsNullOrEmpty(configVal))
                    int.TryParse(configVal, out length);
                return length;
            }
        }

        #endregion

        #region DigiCare
        /// <summary>
        /// Get DigiCare Server Port.
        /// </summary>
        /// <CreatedBy>Om Shakya</CreatedBy>
        /// <CreatedDate>Sep 2015</CreatedDate>
        /// <ModifyBy>...</ModifyBy>
        /// <ModifyDate>...</ModifyDate>
        public static int Digicare_ServerPort
        {
            get
            {
                int bioNetServerPort = 0;
                string configVal = ConfigurationManager.AppSettings["Digicare_ServerPort"];
                if (!string.IsNullOrEmpty(configVal))
                    int.TryParse(configVal, out bioNetServerPort);
                return bioNetServerPort;
            }
        }
        /// <summary>
        /// Get Digicare_Connect_Req_Length (It is fixed as per DigiCare protocol documentation).
        /// </summary>
        /// <CreatedBy>Om Shakya</CreatedBy>
        /// <CreatedDate>Aug 2016</CreatedDate>
        /// <ModifyBy>...</ModifyBy>
        /// <ModifyDate>...</ModifyDate>
        public static int Digicare_Connect_Req_Length
        {
            get
            {
                //It is fixed length
                int length = 3;
                string configVal = ConfigurationManager.AppSettings["Digicare_Connect_Req_Length"];
                if (!string.IsNullOrEmpty(configVal))
                    int.TryParse(configVal, out length);
                return length;
            }
        }
        /// <summary>
        /// Get Digicare_Connect_Accept_Length (It is fixed as per DigiCare protocol documentation).
        /// </summary>
        /// <CreatedBy>Om Shakya</CreatedBy>
        /// <CreatedDate>Aug 2016</CreatedDate>
        /// <ModifyBy>...</ModifyBy>
        /// <ModifyDate>...</ModifyDate>
        public static int Digicare_Connect_Accept_Length
        {
            get
            {
                //It is fixed length
                int length = 3;
                string configVal = ConfigurationManager.AppSettings["Digicare_Connect_Accept_Length"];
                if (!string.IsNullOrEmpty(configVal))
                    int.TryParse(configVal, out length);
                return length;
            }
        }
        /// <summary>
        /// Get Digicare_Disconnect_Req_Length (It is fixed as per DigiCare protocol documentation).
        /// </summary>
        /// <CreatedBy>Om Shakya</CreatedBy>
        /// <CreatedDate>Aug 2016</CreatedDate>
        /// <ModifyBy>...</ModifyBy>
        /// <ModifyDate>...</ModifyDate>
        public static int Digicare_Disconnect_Req_Length
        {
            get
            {
                //It is fixed length
                int length = 3;
                string configVal = ConfigurationManager.AppSettings["Digicare_Disconnect_Req_Length"];
                if (!string.IsNullOrEmpty(configVal))
                    int.TryParse(configVal, out length);
                return length;
            }
        }
        /// <summary>
        /// Get Digicare_Data_Ack_Length (It is fixed as per DigiCare protocol documentation).
        /// </summary>
        /// <CreatedBy>Om Shakya</CreatedBy>
        /// <CreatedDate>Aug 2016</CreatedDate>
        /// <ModifyBy>...</ModifyBy>
        /// <ModifyDate>...</ModifyDate>
        public static int Digicare_Data_Ack_Length
        {
            get
            {
                //It is fixed length
                int length = 3;
                string configVal = ConfigurationManager.AppSettings["Digicare_Data_Ack_Length"];
                if (!string.IsNullOrEmpty(configVal))
                    int.TryParse(configVal, out length);
                return length;
            }
        }
        /// <summary>
        /// Get Digicare_Admit_Info_Length (It is fixed as per DigiCare protocol documentation).
        /// </summary>
        /// <CreatedBy>Om Shakya</CreatedBy>
        /// <CreatedDate>Aug 2016</CreatedDate>
        /// <ModifyBy>...</ModifyBy>
        /// <ModifyDate>...</ModifyDate>
        public static int Digicare_Admit_Info_Length
        {
            get
            {
                //It is fixed length
                int length = 54;
                string configVal = ConfigurationManager.AppSettings["Digicare_Admit_Info_Length"];
                if (!string.IsNullOrEmpty(configVal))
                    int.TryParse(configVal, out length);
                return length;
            }
        }
        /// <summary>
        /// Get Digicare_Unit_Info_Length (It is fixed as per DigiCare protocol documentation).
        /// </summary>
        /// <CreatedBy>Om Shakya</CreatedBy>
        /// <CreatedDate>Aug 2016</CreatedDate>
        /// <ModifyBy>...</ModifyBy>
        /// <ModifyDate>...</ModifyDate>
        public static int Digicare_Unit_Info_Length
        {
            get
            {
                //It is fixed length
                int length = 14;
                string configVal = ConfigurationManager.AppSettings["Digicare_Unit_Info_Length"];
                if (!string.IsNullOrEmpty(configVal))
                    int.TryParse(configVal, out length);
                return length;
            }
        }
        /// <summary>
        /// Get Digicare_Observation_Data_Length (It is fixed as per DigiCare protocol documentation).
        /// </summary>
        /// <CreatedBy>Om Shakya</CreatedBy>
        /// <CreatedDate>Aug 2016</CreatedDate>
        /// <ModifyBy>...</ModifyBy>
        /// <ModifyDate>...</ModifyDate>
        public static int Digicare_Observation_Data_Length
        {
            get
            {
                //It is fixed length
                int length = 30;
                string configVal = ConfigurationManager.AppSettings["Digicare_Observation_Data_Length"];
                if (!string.IsNullOrEmpty(configVal))
                    int.TryParse(configVal, out length);
                return length;
            }
        }
        #endregion

        #region SimulatorValues
        /// <summary>
        /// Get Simulator_Value_Temp (For simulating the values for simulator).
        /// </summary>
        /// <CreatedBy>Om Shakya</CreatedBy>
        /// <CreatedDate>Aug 2016</CreatedDate>
        /// <ModifyBy>...</ModifyBy>
        /// <ModifyDate>...</ModifyDate>
        public static UInt16 Simulator_Value_Temp
        {
            get
            {
                //It is default value
                UInt16 temp = 9820;
                bool b = false;
                string configVal = ConfigurationManager.AppSettings["Simulator_Value_Temp"];
                if (!string.IsNullOrEmpty(configVal))
                {
                    decimal midval = 0;
                    b = decimal.TryParse(configVal, out midval);
                    if (b)
                    {
                        midval = midval * 100;
                    }
                    b = UInt16.TryParse(midval.ToString().Split('.')[0], out temp);
                }
                return temp;
            }
        }
        /// <summary>
        /// Get Simulator_Value_ETCO2 (For simulating the values for simulator).
        /// </summary>
        /// <CreatedBy>Om Shakya</CreatedBy>
        /// <CreatedDate>Aug 2016</CreatedDate>
        /// <ModifyBy>...</ModifyBy>
        /// <ModifyDate>...</ModifyDate>
        public static byte Simulator_Value_ETCO2
        {
            get
            {
                //It is default value
                byte etco2 = 38;
                string configVal = ConfigurationManager.AppSettings["Simulator_Value_ETCO2"];
                if (!string.IsNullOrEmpty(configVal))
                    byte.TryParse(configVal, out etco2);
                return etco2;
            }
        }
        /// <summary>
        /// Get Simulator_Value_SPO2 (For simulating the values for simulator).
        /// </summary>
        /// <CreatedBy>Om Shakya</CreatedBy>
        /// <CreatedDate>Aug 2016</CreatedDate>
        /// <ModifyBy>...</ModifyBy>
        /// <ModifyDate>...</ModifyDate>
        public static byte Simulator_Value_SPO2
        {
            get
            {
                //It is fixed length
                byte spo2 = 98;
                string configVal = ConfigurationManager.AppSettings["Simulator_Value_SPO2"];
                if (!string.IsNullOrEmpty(configVal))
                    byte.TryParse(configVal, out spo2);
                return spo2;
            }
        }
        /// <summary>
        /// Get Simulator_Value_RR (For simulating the values for simulator).
        /// </summary>
        /// <CreatedBy>Om Shakya</CreatedBy>
        /// <CreatedDate>Aug 2016</CreatedDate>
        /// <ModifyBy>...</ModifyBy>
        /// <ModifyDate>...</ModifyDate>
        public static byte Simulator_Value_RR
        {
            get
            {
                //It is default value
                byte rr = 13;
                string configVal = ConfigurationManager.AppSettings["Simulator_Value_RR"];
                if (!string.IsNullOrEmpty(configVal))
                    byte.TryParse(configVal, out rr);
                return rr;
            }
        }
        /// <summary>
        /// Get Simulator_Value_Temp_Part1 (For simulating the values for simulator).
        /// </summary>
        /// <CreatedBy>Om Shakya</CreatedBy>
        /// <CreatedDate>Aug 2016</CreatedDate>
        /// <ModifyBy>...</ModifyBy>
        /// <ModifyDate>...</ModifyDate>
        public static byte Simulator_Value_Temp_Part1
        {
            get
            {
                //It is default value
                string temp = "98.2";
                string configVal = ConfigurationManager.AppSettings["Simulator_Value_Temp"];
                if (!string.IsNullOrEmpty(configVal))
                    temp = configVal;

                string[] parts = temp.Split('.');

                //It is default value
                byte temp_part1 = 98;
                if (parts.Length > 1)
                {
                    if (!string.IsNullOrEmpty(parts[0]))
                    {
                        byte.TryParse(parts[0], out temp_part1);
                    }
                }
                return temp_part1;
            }
        }
        /// <summary>
        /// Get Simulator_Value_Temp_Part2 (For simulating the values for simulator).
        /// </summary>
        /// <CreatedBy>Om Shakya</CreatedBy>
        /// <CreatedDate>Aug 2016</CreatedDate>
        /// <ModifyBy>...</ModifyBy>
        /// <ModifyDate>...</ModifyDate>
        public static byte Simulator_Value_Temp_Part2
        {
            get
            {
                //It is default value
                string temp = "98.2";
                string configVal = ConfigurationManager.AppSettings["Simulator_Value_Temp"];
                if (!string.IsNullOrEmpty(configVal))
                    temp = configVal;

                string[] parts = temp.Split('.');

                //It is default value
                byte temp_part2 = 2;
                if (parts.Length > 1)
                {
                    if (!string.IsNullOrEmpty(parts[1]))
                    {
                        byte.TryParse(parts[1], out temp_part2);
                    }
                }
                return temp_part2;
            }
        }
        /// <summary>
        /// Get Simulator_Value_HR (For simulating the values for simulator).
        /// </summary>
        /// <CreatedBy>Om Shakya</CreatedBy>
        /// <CreatedDate>Aug 2016</CreatedDate>
        /// <ModifyBy>...</ModifyBy>
        /// <ModifyDate>...</ModifyDate>
        public static UInt16 Simulator_Value_HR
        {
            get
            {
                //It is default value
                UInt16 hr = 75;
                string configVal = ConfigurationManager.AppSettings["Simulator_Value_HR"];
                if (!string.IsNullOrEmpty(configVal))
                    UInt16.TryParse(configVal, out hr);
                return hr;
            }
        }
        /// <summary>
        /// Get Simulator_Value_DBP (For simulating the values for simulator).
        /// </summary>
        /// <CreatedBy>Om Shakya</CreatedBy>
        /// <CreatedDate>Aug 2016</CreatedDate>
        /// <ModifyBy>...</ModifyBy>
        /// <ModifyDate>...</ModifyDate>
        public static UInt16 Simulator_Value_DBP
        {
            get
            {
                //It is default value
                UInt16 dbp = 83;
                string configVal = ConfigurationManager.AppSettings["Simulator_Value_DBP"];
                if (!string.IsNullOrEmpty(configVal))
                    UInt16.TryParse(configVal, out dbp);
                return dbp;
            }
        }
        /// <summary>
        /// Get Simulator_Value_SBP (For simulating the values for simulator).
        /// </summary>
        /// <CreatedBy>Om Shakya</CreatedBy>
        /// <CreatedDate>Aug 2016</CreatedDate>
        /// <ModifyBy>...</ModifyBy>
        /// <ModifyDate>...</ModifyDate>
        public static UInt16 Simulator_Value_SBP
        {
            get
            {
                //It is default value
                UInt16 sbp = 138;
                string configVal = ConfigurationManager.AppSettings["Simulator_Value_SBP"];
                if (!string.IsNullOrEmpty(configVal))
                    UInt16.TryParse(configVal, out sbp);
                return sbp;
            }
        }
        /// <summary>
        /// Get Simulator_Value_MAP (For simulating the values for simulator).
        /// </summary>
        /// <CreatedBy>Om Shakya</CreatedBy>
        /// <CreatedDate>Aug 2016</CreatedDate>
        /// <ModifyBy>...</ModifyBy>
        /// <ModifyDate>...</ModifyDate>
        public static UInt16 Simulator_Value_MAP
        {
            get
            {
                //It is default value
                UInt16 map = 104;
                string configVal = ConfigurationManager.AppSettings["Simulator_Value_MAP"];
                if (!string.IsNullOrEmpty(configVal))
                    UInt16.TryParse(configVal, out map);
                return map;
            }
        }
        #endregion

        #region WinApp_Settings
        /// <summary>
        /// Get WinApp_Settings_BaseFolderName.
        /// </summary>
        /// <CreatedBy>Om Shakya</CreatedBy>
        /// <CreatedDate>Aug 2016</CreatedDate>
        /// <ModifyBy>...</ModifyBy>
        /// <ModifyDate>...</ModifyDate>
        public static string WinApp_Settings_BaseFolderName
        {
            get
            {
                string folderName = "SmartFlowSheet";
                string name = ConfigurationManager.AppSettings["WinApp_Settings_BaseFolderName"];
                if (!string.IsNullOrEmpty(name))
                    folderName = name;
                return folderName;
            }
        }
        /// <summary>
        /// Get WinApp_Settings_Disconnect_FileName.
        /// </summary>
        /// <CreatedBy>Om Shakya</CreatedBy>
        /// <CreatedDate>Aug 2016</CreatedDate>
        /// <ModifyBy>...</ModifyBy>
        /// <ModifyDate>...</ModifyDate>
        public static string WinApp_Settings_Disconnect_FileName
        {
            get
            {
                string disconnect_FileName = "SFS.Shutdown.sfs";
                string name = ConfigurationManager.AppSettings["WinApp_Settings_Disconnect_FileName"];
                if (!string.IsNullOrEmpty(name))
                    disconnect_FileName = name;
                return disconnect_FileName;
            }
        }
        /// <summary>
        /// Get WinApp_Settings_ServerClientStatus_FileName.
        /// </summary>
        /// <CreatedBy>Om Shakya</CreatedBy>
        /// <CreatedDate>Aug 2016</CreatedDate>
        /// <ModifyBy>...</ModifyBy>
        /// <ModifyDate>...</ModifyDate>
        public static string WinApp_Settings_ServerClientStatus_FileName
        {
            get
            {
                string serverClientStatus_FileName = "SFS.Server.Client.Status.sfs";
                string name = ConfigurationManager.AppSettings["WinApp_Settings_ServerClientStatus_FileName"];
                if (!string.IsNullOrEmpty(name))
                    serverClientStatus_FileName = name;
                return serverClientStatus_FileName;
            }
        }
        /// <summary>
        /// Get WinApp_Settings_PendingDataFiles_FolderName.
        /// </summary>
        /// <CreatedBy>Om Shakya</CreatedBy>
        /// <CreatedDate>Aug 2016</CreatedDate>
        /// <ModifyBy>...</ModifyBy>
        /// <ModifyDate>...</ModifyDate>
        public static string WinApp_Settings_PendingDataFiles_FolderName
        {
            get
            {
                string folderName = "SmartFlowSheet1";
                string name = ConfigurationManager.AppSettings["WinApp_Settings_PendingDataFiles_FolderName"];
                if (!string.IsNullOrEmpty(name))
                    folderName = name;
                return folderName;
            }
        }
        /// <summary>
        /// Get WinApp_Settings_SentDataFiles_FolderName.
        /// </summary>
        /// <CreatedBy>Om Shakya</CreatedBy>
        /// <CreatedDate>Aug 2016</CreatedDate>
        /// <ModifyBy>...</ModifyBy>
        /// <ModifyDate>...</ModifyDate>
        public static string WinApp_Settings_SentDataFiles_FolderName
        {
            get
            {
                string folderName = "SmartFlowSheet";
                string name = ConfigurationManager.AppSettings["WinApp_Settings_SentDataFiles_FolderName"];
                if (!string.IsNullOrEmpty(name))
                    folderName = name;
                return folderName;
            }
        }
        /// <summary>
        /// Get WinApp_Settings_FailedDataFiles_FolderName.
        /// </summary>
        /// <CreatedBy>Om Shakya</CreatedBy>
        /// <CreatedDate>Aug 2016</CreatedDate>
        /// <ModifyBy>...</ModifyBy>
        /// <ModifyDate>...</ModifyDate>
        public static string WinApp_Settings_FailedDataFiles_FolderName
        {
            get
            {
                string folderName = "SmartFlowSheet";
                string name = ConfigurationManager.AppSettings["WinApp_Settings_FailedDataFiles_FolderName"];
                if (!string.IsNullOrEmpty(name))
                    folderName = name;
                return folderName;
            }
        }
        /// <summary>
        /// Get WinApp_Settings_HistoryContainer_FolderName.
        /// </summary>
        /// <CreatedBy>Om Shakya</CreatedBy>
        /// <CreatedDate>Aug 2016</CreatedDate>
        /// <ModifyBy>...</ModifyBy>
        /// <ModifyDate>...</ModifyDate>
        public static string WinApp_Settings_HistoryContainer_FolderName
        {
            get
            {
                string folderName = "History";
                string name = ConfigurationManager.AppSettings["WinApp_Settings_HistoryContainer_FolderName"];
                if (!string.IsNullOrEmpty(name))
                    folderName = name;
                return folderName;
            }
        }
        /// <summary>
        /// Get WinApp_Settings_History_FileName.
        /// </summary>
        /// <CreatedBy>Om Shakya</CreatedBy>
        /// <CreatedDate>Aug 2016</CreatedDate>
        /// <ModifyBy>...</ModifyBy>
        /// <ModifyDate>...</ModifyDate>
        public static string WinApp_Settings_History_FileName
        {
            get
            {
                string serverClientStatus_FileName = "SFS.DataFiles.History.sfs";
                string name = ConfigurationManager.AppSettings["WinApp_Settings_History_FileName"];
                if (!string.IsNullOrEmpty(name))
                    serverClientStatus_FileName = name;
                return serverClientStatus_FileName;
            }
        }
        /// <summary>
        /// Get WinApp_Settings_DataContainer_FolderName.
        /// </summary>
        /// <CreatedBy>Om Shakya</CreatedBy>
        /// <CreatedDate>Aug 2016</CreatedDate>
        /// <ModifyBy>...</ModifyBy>
        /// <ModifyDate>...</ModifyDate>
        public static string WinApp_Settings_DataContainer_FolderName
        {
            get
            {
                string folderName = "Data";
                string name = ConfigurationManager.AppSettings["WinApp_Settings_DataContainer_FolderName"];
                if (!string.IsNullOrEmpty(name))
                    folderName = name;
                return folderName;
            }
        }
        /// <summary>
        /// Get WinApp_Settings_SettingsContainer_FolderName.
        /// </summary>
        /// <CreatedBy>Om Shakya</CreatedBy>
        /// <CreatedDate>Aug 2016</CreatedDate>
        /// <ModifyBy>...</ModifyBy>
        /// <ModifyDate>...</ModifyDate>
        public static string WinApp_Settings_SettingsContainer_FolderName
        {
            get
            {
                string folderName = "Settings";
                string name = ConfigurationManager.AppSettings["WinApp_Settings_SettingsContainer_FolderName"];
                if (!string.IsNullOrEmpty(name))
                    folderName = name;
                return folderName;
            }
        }
        /// <summary>
        /// Get WinApp_Settings_LiveData_FolderName.
        /// </summary>
        /// <CreatedBy>Om Shakya</CreatedBy>
        /// <CreatedDate>Aug 2016</CreatedDate>
        /// <ModifyBy>...</ModifyBy>
        /// <ModifyDate>...</ModifyDate>
        public static string WinApp_Settings_LiveData_FolderName
        {
            get
            {
                string folderName = "LiveData";
                string name = ConfigurationManager.AppSettings["WinApp_Settings_LiveData_FolderName"];
                if (!string.IsNullOrEmpty(name))
                    folderName = name;
                return folderName;
            }
        }
        /// <summary>
        /// Get WinApp_Settings_TimeFrequency_FileName.
        /// </summary>
        /// <CreatedBy>Om Shakya</CreatedBy>
        /// <CreatedDate>Aug 2016</CreatedDate>
        /// <ModifyBy>...</ModifyBy>
        /// <ModifyDate>...</ModifyDate>
        public static string WinApp_Settings_TimeFrequency_FileName
        {
            get
            {
                string serverClientStatus_FileName = "SFS.TimeFrequency.sfs";
                string name = ConfigurationManager.AppSettings["WinApp_Settings_TimeFrequency_FileName"];
                if (!string.IsNullOrEmpty(name))
                    serverClientStatus_FileName = name;
                return serverClientStatus_FileName;
            }
        }
        /// <summary>
        /// Get WinApp_Settings_ServerIPAddress_FileName.
        /// </summary>
        /// <CreatedBy>Om Shakya</CreatedBy>
        /// <CreatedDate>Aug 2016</CreatedDate>
        /// <ModifyBy>...</ModifyBy>
        /// <ModifyDate>...</ModifyDate>
        public static string WinApp_Settings_ServerIPAddress_FileName
        {
            get
            {
                string serverClientStatus_FileName = "SFS.ServerIPAddress.sfs";
                string name = ConfigurationManager.AppSettings["WinApp_Settings_ServerIPAddress_FileName"];
                if (!string.IsNullOrEmpty(name))
                    serverClientStatus_FileName = name;
                return serverClientStatus_FileName;
            }
        }
        /// <summary>
        /// Get WinApp_Settings_SurgeryStartDate_IntervalFrequency_FileName.
        /// </summary>
        /// <CreatedBy>Om Shakya</CreatedBy>
        /// <CreatedDate>Aug 2016</CreatedDate>
        /// <ModifyBy>...</ModifyBy>
        /// <ModifyDate>...</ModifyDate>
        public static string WinApp_Settings_SurgeryStartDate_IntervalFrequency_FileName
        {
            get
            {
                string serverClientStatus_FileName = "SFS.SurgeryStartDate_IntervalFrequency.sfs";
                string name = ConfigurationManager.AppSettings["WinApp_Settings_SurgeryStartDate_IntervalFrequency_FileName"];
                if (!string.IsNullOrEmpty(name))
                    serverClientStatus_FileName = name;
                return serverClientStatus_FileName;
            }
        }
        /// <summary>
        /// Get WinApp_Settings_FirstObservationReceived_FileName.
        /// </summary>
        /// <CreatedBy>Om Shakya</CreatedBy>
        /// <CreatedDate>Aug 2016</CreatedDate>
        /// <ModifyBy>...</ModifyBy>
        /// <ModifyDate>...</ModifyDate>
        public static string WinApp_Settings_FirstObservationReceived_FileName
        {
            get
            {
                string serverClientStatus_FileName = "SFS.FirstObservationReceived.sfs";
                string name = ConfigurationManager.AppSettings["WinApp_Settings_FirstObservationReceived_FileName"];
                if (!string.IsNullOrEmpty(name))
                    serverClientStatus_FileName = name;
                return serverClientStatus_FileName;
            }
        }
        /// <summary>
        /// Get WinApp_WindowService_Name.
        /// </summary>
        /// <CreatedBy>Om Shakya</CreatedBy>
        /// <CreatedDate>Aug 2016</CreatedDate>
        /// <ModifyBy>...</ModifyBy>
        /// <ModifyDate>...</ModifyDate>
        public static string WinApp_WindowService_Name
        {
            get
            {
                string serverName = "SFS.WinService.Listener.Server";
                string name = ConfigurationManager.AppSettings["WinApp_WindowService_Name"];
                if (!string.IsNullOrEmpty(name))
                    serverName = name;
                return serverName;
            }
        }

        /// <summary>
        /// Get WinApp_Help_Tooltip_Text.
        /// </summary>
        /// <CreatedBy>Om Shakya</CreatedBy>
        /// <CreatedDate>Aug 2016</CreatedDate>
        /// <ModifyBy>...</ModifyBy>
        /// <ModifyDate>...</ModifyDate>
        public static string WinApp_Help_Tooltip_Text
        {
            get
            {
                string helpText = "Help";
                string text = ConfigurationManager.AppSettings["WinApp_Help_Tooltip_Text"];
                if (!string.IsNullOrEmpty(text))
                    helpText = text;
                return helpText;
            }
        }

        /// <summary>
        /// Get SFSAPI_Production_URL.
        /// </summary>
        /// <CreatedBy>Om Shakya</CreatedBy>
        /// <CreatedDate>Aug 2016</CreatedDate>
        /// <ModifyBy>...</ModifyBy>
        /// <ModifyDate>...</ModifyDate>
        public static string SFSAPI_Production_URL
        {
            get
            {
                string url = "https://www.smartflowsheet.com/api/v3/surgery";
                string name = ConfigurationManager.AppSettings["SFSAPI_Production_URL"];
                if (!string.IsNullOrEmpty(name))
                    url = name;
                return url;
            }
        }

        #endregion

        #region Cardell
        /// <summary>
        /// Get Cardell_ServerPort
        /// </summary>
        /// <CreatedBy>Om Shakya</CreatedBy>
        /// <CreatedDate>Oct 2016</CreatedDate>
        /// <ModifyBy>...</ModifyBy>
        /// <ModifyDate>...</ModifyDate>
        public static int Cardell_ServerPort
        {
            get
            {
                int CardellServerPort = 5001;
                string configVal = ConfigurationManager.AppSettings["Cardell_ServerPort"];
                if (!string.IsNullOrEmpty(configVal))
                    int.TryParse(configVal, out CardellServerPort);
                return CardellServerPort;
            }
        }
        /// <summary>
        /// Get Cardell_Connect_Req_Length
        /// </summary>
        /// <CreatedBy>Om Shakya</CreatedBy>
        /// <CreatedDate>Oct 2016</CreatedDate>
        /// <ModifyBy>...</ModifyBy>
        /// <ModifyDate>...</ModifyDate>
        public static int Cardell_Connect_Req_Length
        {
            get
            {
                //It is fixed length
                int length = 16;
                string configVal = ConfigurationManager.AppSettings["Cardell_Connect_Req_Length"];
                if (!string.IsNullOrEmpty(configVal))
                    int.TryParse(configVal, out length);
                return length;
            }
        }
        /// <summary>
        /// Get Cardell_Connect_Accept_Length
        /// </summary>
        /// <CreatedBy>Om Shakya</CreatedBy>
        /// <CreatedDate>Oct 2016</CreatedDate>
        /// <ModifyBy>...</ModifyBy>
        /// <ModifyDate>...</ModifyDate>
        public static int Cardell_Connect_Accept_Length
        {
            get
            {
                //It is fixed length
                int length = 11;
                string configVal = ConfigurationManager.AppSettings["Cardell_Connect_Accept_Length"];
                if (!string.IsNullOrEmpty(configVal))
                    int.TryParse(configVal, out length);
                return length;
            }
        }
        /// <summary>
        /// Get Cardell_Connect_REQ_Length_heartbeat
        /// </summary>
        /// <CreatedBy>Om Shakya</CreatedBy>
        /// <CreatedDate>Oct 2016</CreatedDate>
        /// <ModifyBy>...</ModifyBy>
        /// <ModifyDate>...</ModifyDate>
        public static int Cardell_Connect_REQ_Length_heartbeat
        {
            get
            {
                //It is fixed length
                int length = 10;
                string configVal = ConfigurationManager.AppSettings["Cardell_Connect_REQ_Length_heartbeat"];
                if (!string.IsNullOrEmpty(configVal))
                    int.TryParse(configVal, out length);
                return length;
            }
        }
        /// <summary>
        /// Get Cardell_Connect_ACCEPT_Length_Receive_patient
        /// </summary>
        /// <CreatedBy>Om Shakya</CreatedBy>
        /// <CreatedDate>Oct 2016</CreatedDate>
        /// <ModifyBy>...</ModifyBy>
        /// <ModifyDate>...</ModifyDate>
        public static int Cardell_Connect_ACCEPT_Length_Receive_patient
        {
            get
            {
                //It is fixed length
                int length = 11;
                string configVal = ConfigurationManager.AppSettings["Cardell_Connect_ACCEPT_Length_Receive_patient"];
                if (!string.IsNullOrEmpty(configVal))
                    int.TryParse(configVal, out length);
                return length;
            }
        }
        /// <summary>
        /// Get Cardell_Disconnect_Req_Length
        /// </summary>
        /// <CreatedBy>Om Shakya</CreatedBy>
        /// <CreatedDate>Oct 2016</CreatedDate>
        /// <ModifyBy>...</ModifyBy>
        /// <ModifyDate>...</ModifyDate>
        public static int Cardell_Disconnect_Req_Length
        {
            get
            {
                //It is fixed length
                int length = 3;
                string configVal = ConfigurationManager.AppSettings["Cardell_Disconnect_Req_Length"];
                if (!string.IsNullOrEmpty(configVal))
                    int.TryParse(configVal, out length);
                return length;
            }
        }
        /// <summary>
        /// Get Cardell_Data_Ack_Length
        /// </summary>
        /// <CreatedBy>Om Shakya</CreatedBy>
        /// <CreatedDate>Oct 2016</CreatedDate>
        /// <ModifyBy>...</ModifyBy>
        /// <ModifyDate>...</ModifyDate>
        public static int Cardell_Data_Ack_Length
        {
            get
            {
                //It is fixed length
                int length = 3;
                string configVal = ConfigurationManager.AppSettings["Cardell_Data_Ack_Length"];
                if (!string.IsNullOrEmpty(configVal))
                    int.TryParse(configVal, out length);
                return length;
            }
        }
        /// <summary>
        /// Get Cardell_Admit_Info_Length
        /// </summary>
        /// <CreatedBy>Om Shakya</CreatedBy>
        /// <CreatedDate>Oct 2016</CreatedDate>
        /// <ModifyBy>...</ModifyBy>
        /// <ModifyDate>...</ModifyDate>
        public static int Cardell_Admit_Info_Length
        {
            get
            {
                //It is fixed length
                int length = 49;
                string configVal = ConfigurationManager.AppSettings["Cardell_Admit_Info_Length"];
                if (!string.IsNullOrEmpty(configVal))
                    int.TryParse(configVal, out length);
                return length;
            }
        }
        /// <summary>
        /// Get Cardell_Unit_Info_Length
        /// </summary>
        /// <CreatedBy>Om Shakya</CreatedBy>
        /// <CreatedDate>Oct 2016</CreatedDate>
        /// <ModifyBy>...</ModifyBy>
        /// <ModifyDate>...</ModifyDate>
        public static int Cardell_Unit_Info_Length
        {
            get
            {
                //It is fixed length
                int length = 14;
                string configVal = ConfigurationManager.AppSettings["Cardell_Unit_Info_Length"];
                if (!string.IsNullOrEmpty(configVal))
                    int.TryParse(configVal, out length);
                return length;
            }
        }
        /// <summary>
        /// Get Cardell_Observation_Data_Length
        /// </summary>
        /// <CreatedBy>Om Shakya</CreatedBy>
        /// <CreatedDate>Oct 2016</CreatedDate>
        /// <ModifyBy>...</ModifyBy>
        /// <ModifyDate>...</ModifyDate>
        public static int Cardell_Observation_Data_Length
        {
            get
            {
                //It is fixed length
                int length = 102;
                string configVal = ConfigurationManager.AppSettings["Cardell_Observation_Data_Length"];
                if (!string.IsNullOrEmpty(configVal))
                    int.TryParse(configVal, out length);
                return length;
            }
        }
        /// <summary>
        /// Get Cardell_FIRSTSEND_Req_Length
        /// </summary>
        /// <CreatedBy>Om Shakya</CreatedBy>
        /// <CreatedDate>Oct 2016</CreatedDate>
        /// <ModifyBy>...</ModifyBy>
        /// <ModifyDate>...</ModifyDate>
        public static int Cardell_FIRSTSEND_Req_Length
        {
            get
            {
                //It is fixed length
                int length = 64;
                string configVal = ConfigurationManager.AppSettings["Cardell_FIRSTSEND_Req_Length"];
                if (!string.IsNullOrEmpty(configVal))
                    int.TryParse(configVal, out length);
                return length;
            }
        }
        /// <summary>
        /// Get Cardell_HeartRate_Data_Length
        /// </summary>
        /// <CreatedBy>Om Shakya</CreatedBy>
        /// <CreatedDate>Oct 2016</CreatedDate>
        /// <ModifyBy>...</ModifyBy>
        /// <ModifyDate>...</ModifyDate>
        public static int Cardell_HeartRate_Data_Length
        {
            get
            {
                //It is fixed length
                int length = 270;
                string configVal = ConfigurationManager.AppSettings["Cardell_HeartRate_Data_Length"];
                if (!string.IsNullOrEmpty(configVal))
                    int.TryParse(configVal, out length);
                return length;
            }
        }
        /// <summary>
        /// Get Cardell_Spo2Value_Data_Length
        /// </summary>
        /// <CreatedBy>Om Shakya</CreatedBy>
        /// <CreatedDate>Oct 2016</CreatedDate>
        /// <ModifyBy>...</ModifyBy>
        /// <ModifyDate>...</ModifyDate>
        public static int Cardell_Spo2Value_Data_Length
        {
            get
            {
                //It is fixed length
                int length = 90;
                string configVal = ConfigurationManager.AppSettings["Cardell_Spo2Value_Data_Length"];
                if (!string.IsNullOrEmpty(configVal))
                    int.TryParse(configVal, out length);
                return length;
            }
        }
        /// <summary>
        /// Get Cardell_RespRate_Data_Length
        /// </summary>
        /// <CreatedBy>Om Shakya</CreatedBy>
        /// <CreatedDate>Oct 2016</CreatedDate>
        /// <ModifyBy>...</ModifyBy>
        /// <ModifyDate>...</ModifyDate>
        public static int Cardell_RespRate_Data_Length
        {
            get
            {
                //It is fixed length
                int length = 98;
                string configVal = ConfigurationManager.AppSettings["Cardell_RespRate_Data_Length"];
                if (!string.IsNullOrEmpty(configVal))
                    int.TryParse(configVal, out length);
                return length;
            }
        }
        /// <summary>
        /// Get Cardell_NIBPDataHigh_Data_Length
        /// </summary>
        /// <CreatedBy>Om Shakya</CreatedBy>
        /// <CreatedDate>Oct 2016</CreatedDate>
        /// <ModifyBy>...</ModifyBy>
        /// <ModifyDate>...</ModifyDate>
        public static int Cardell_NIBPDataHigh_Data_Length
        {
            get
            {
                //It is fixed length
                int length = 25;
                string configVal = ConfigurationManager.AppSettings["Cardell_NIBPDataHigh_Data_Length"];
                if (!string.IsNullOrEmpty(configVal))
                    int.TryParse(configVal, out length);
                return length;
            }
        }
        /// <summary>
        /// Get Cardell_pulseRate_Data_Length
        /// </summary>
        /// <CreatedBy>Om Shakya</CreatedBy>
        /// <CreatedDate>Oct 2016</CreatedDate>
        /// <ModifyBy>...</ModifyBy>
        /// <ModifyDate>...</ModifyDate>
        public static int Cardell_pulseRate_Data_Length
        {
            get
            {
                //It is fixed length
                int length = 12;
                string configVal = ConfigurationManager.AppSettings["Cardell_pulseRate_Data_Length"];
                if (!string.IsNullOrEmpty(configVal))
                    int.TryParse(configVal, out length);
                return length;
            }
        }
        /// <summary>
        /// Get Cardell_temp_Data_Length
        /// </summary>
        /// <CreatedBy>Om Shakya</CreatedBy>
        /// <CreatedDate>Oct 2016</CreatedDate>
        /// <ModifyBy>...</ModifyBy>
        /// <ModifyDate>...</ModifyDate>
        public static int Cardell_temp_Data_Length
        {
            get
            {
                //It is fixed length
                int length = 15;
                string configVal = ConfigurationManager.AppSettings["Cardell_temp_Data_Length"];
                if (!string.IsNullOrEmpty(configVal))
                    int.TryParse(configVal, out length);
                return length;
            }
        }
        /// <summary>
        /// Get Cardell_IsLittleEndian
        /// </summary>
        /// <CreatedBy>Om Shakya</CreatedBy>
        /// <CreatedDate>Oct 2016</CreatedDate>
        /// <ModifyBy>...</ModifyBy>
        /// <ModifyDate>...</ModifyDate>
        public static bool Cardell_IsLittleEndian
        {
            get
            {
                //It is fixed length
                bool result = true;
                string configVal = ConfigurationManager.AppSettings["Cardell_IsLittleEndian"];
                if (!string.IsNullOrEmpty(configVal))
                    bool.TryParse(configVal, out result);
                return result;
            }
        }
        #endregion

        #region Vetland

        public static int Vetland_Font_Data_Length
        {
            get
            {
                //It is fixed length
                int length = 15;
                string configVal = ConfigurationManager.AppSettings["Vetland_Font_Data_Length"];
                if (!string.IsNullOrEmpty(configVal))
                    int.TryParse(configVal, out length);
                return length;
            }
        }

        public static int Vetland_Connect_Req_Length
        {
            get
            {
                //It is fixed length
                int length = 5;
                string configVal = ConfigurationManager.AppSettings["Vetland_Connect_Req_Length"];
                if (!string.IsNullOrEmpty(configVal))
                    int.TryParse(configVal, out length);
                return length;
            }
        }

        public static int Vetland_Connect_Accept_Length
        {
            get
            {
                //It is fixed length
                int length = 7;
                string configVal = ConfigurationManager.AppSettings["Vetland_Connect_Accept_Length"];
                if (!string.IsNullOrEmpty(configVal))
                    int.TryParse(configVal, out length);
                return length;
            }
        }

        public static int Vetland_Bed_Number_Length
        {
            get
            {
                //It is fixed length
                int length = 2;
                string configVal = ConfigurationManager.AppSettings["Vetland_Bed_Number_Length"];
                if (!string.IsNullOrEmpty(configVal))
                    int.TryParse(configVal, out length);
                return length;
            }
        }

        public static int Vetland_ServerPort
        {
            get
            {
                int CardellServerPort = 9000;
                string configVal = ConfigurationManager.AppSettings["Vetland_ServerPort"];
                if (!string.IsNullOrEmpty(configVal))
                    int.TryParse(configVal, out CardellServerPort);
                return CardellServerPort;
            }
        }
        #region OtherSettings
        /// <summary>
        /// Get AllowDuplicateIP i.e Allow duplicate IP
        /// </summary>
        /// <CreatedBy>Om Shakya</CreatedBy>
        /// <CreatedDate>Aug 2016</CreatedDate>
        /// <ModifyBy>...</ModifyBy>
        /// <ModifyDate>...</ModifyDate>
        public static string AllowDuplicateIP
        {
            get
            {
                string msg = string.Empty;
                string configVal = ConfigurationManager.AppSettings["AllowDuplicateIP"];
                if (!string.IsNullOrEmpty(configVal))
                    msg = configVal;
                return msg;
            }
        }

        /// <summary>
        /// Get MonitorStatusMsg i.e message for Monitor Status 
        /// </summary>
        /// <CreatedBy>Om Shakya</CreatedBy>
        /// <CreatedDate>Aug 2016</CreatedDate>
        /// <ModifyBy>...</ModifyBy>
        /// <ModifyDate>...</ModifyDate>
        public static string MonitorStatusMsg
        {
            get
            {
                string msg = string.Empty;
                string configVal = ConfigurationManager.AppSettings["MonitorStatusMsg"];
                if (!string.IsNullOrEmpty(configVal))
                    msg = configVal;
                return msg;
            }
        }
        #endregion

        #endregion
    }
}
