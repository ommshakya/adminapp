﻿using System;

namespace SFS.ObjectSerializer
{
    [Serializable]
    public class InstallCode
    {
        public string installcode { get; set; }
    }
}
