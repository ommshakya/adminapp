﻿using smartflowsheet.surgery.api.model.objects;
using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Http;
using System.Web.Script.Serialization;

namespace SFS.HttpClientHelper
{
    /// <summary>
    /// Class for API Connector.
    /// </summary>
    /// <CreatedDate>Aug 2016</CreatedDate>
    /// <ModifyBy>...</ModifyBy>
    /// <ModifyDate>...</ModifyDate>
    public class APIConnector
    {
        private string Api_ServerUrl { get; set; }
        private string Surgery_ApiKey { get; set; }
        private HttpClient httpClient;

        /// <summary>
        /// Constructor of API Connector.
        /// </summary>
        /// <param name="serverurl"></param>
        /// <param name="surgeryApiKey"></param>
        /// <CreatedDate>Aug 2016</CreatedDate>
        /// <ModifyBy>...</ModifyBy>
        /// <ModifyDate>...</ModifyDate>
        public APIConnector(string serverurl, string surgeryApiKey)
        {
            Api_ServerUrl = serverurl;
            Surgery_ApiKey = surgeryApiKey;
            httpClient = new HttpClient();
        }
        /// <summary>
        /// Method to get SurgeryApiKey
        /// </summary>
        /// <param name="email"></param>
        /// <param name="password"></param>
        /// <returns></returns>
        public string GetSurgeryApiKey(string email, string password)
        {
            string surgeryApiKey = null;
            try
            {
                Clinic clinic = null;
                User user = new User()
                {
                    email = email,
                    password = password,
                };
                string url = Api_ServerUrl + "/account";
                var result = httpClient.PostAsJsonAsync<User>(url, user).Result;

                var responseBody = result.Content.ReadAsStringAsync().Result;
                var responseCode = (int)result.StatusCode;

                if (responseCode >= 200 && responseCode < 300)
                {
                    JavaScriptSerializer serializer = new JavaScriptSerializer();
                    clinic = serializer.Deserialize<Clinic>(result.Content.ReadAsStringAsync().Result);
                }
                else
                {
                    var error = Newtonsoft.Json.JsonConvert.DeserializeObject<Error>(responseBody);
                    throw new Exception(!string.IsNullOrEmpty(error.supportUrl) ? error.message + Environment.NewLine + error.supportUrl : error.message);
                }
                if (clinic != null)
                {
                    surgeryApiKey = clinic.surgeryApiKey;
                }
                return surgeryApiKey;
            }
            catch
            {
                throw;
            }
            finally
            {
                httpClient.Dispose();
            }
        }
        /// <summary>
        /// Method to register application.
        /// </summary>
        /// <returns></returns>
        public SurgeryMonitorEndpoint RegisterApplication()
        {
            SurgeryMonitorEndpoint endpointCredentials = null;
            try
            {
                httpClient.DefaultRequestHeaders.Add("surgeryApiKey", Surgery_ApiKey);

                var response = httpClient.PostAsync(Api_ServerUrl + "/account/install", null).Result;
                var responseBody = response.Content.ReadAsStringAsync().Result;
                var responseCode = (int)response.StatusCode;

                if (responseCode >= 200 && responseCode < 300)
                {
                    endpointCredentials = Newtonsoft.Json.JsonConvert.DeserializeObject<SurgeryMonitorEndpoint>(responseBody);
                }
                else
                {
                    var error = Newtonsoft.Json.JsonConvert.DeserializeObject<Error>(responseBody);
                    throw new Exception(!string.IsNullOrEmpty(error.supportUrl) ? error.message + Environment.NewLine + error.supportUrl : error.message);
                }
                return endpointCredentials;
            }
            catch
            {
                throw;
            }
            finally
            {
                httpClient.Dispose();
            }
        }
        /// <summary>
        /// Method to unregister allication.
        /// </summary>
        /// <param name="installationId"></param>
        public void UnregisterApplication(Guid installationId)
        {
            try
            {
                httpClient.DefaultRequestHeaders.Add("surgeryApiKey", Surgery_ApiKey);

                var response = httpClient.PostAsync(Api_ServerUrl + "/account/uninstall/" + installationId.ToString(), null).Result;
                var responseCode = (int)response.StatusCode;
                if (responseCode < 200 || responseCode >= 300)
                {
                    var responseBody = response.Content.ReadAsStringAsync().Result;
                    var error = Newtonsoft.Json.JsonConvert.DeserializeObject<Error>(responseBody);
                    throw new Exception(!string.IsNullOrEmpty(error.supportUrl) ? error.message + Environment.NewLine + error.supportUrl : error.message);
                }
            }
            catch
            {
                throw;
            }
            finally
            {
                httpClient.Dispose();
            }
        }
        /// <summary>
        /// Method to register monitor.
        /// </summary>
        /// <param name="monitorName"></param>
        /// <returns></returns>
        public SurgeryMonitor RegisterMonitor(SurgeryMonitor surgeryMonitor)
        {
            SurgeryMonitor monitor = null;
            try
            {
                httpClient.DefaultRequestHeaders.Add("surgeryApiKey", Surgery_ApiKey);

                var response = httpClient.PostAsJsonAsync(Api_ServerUrl + "/monitor/", surgeryMonitor).Result;
                var responseBody = response.Content.ReadAsStringAsync().Result;
                var responseCode = (int)response.StatusCode;

                if (responseCode >= 200 && responseCode < 300)
                {
                    monitor = Newtonsoft.Json.JsonConvert.DeserializeObject<SurgeryMonitor>(responseBody);
                }
                else
                {
                    var error = Newtonsoft.Json.JsonConvert.DeserializeObject<Error>(responseBody);
                    throw new Exception(!string.IsNullOrEmpty(error.supportUrl) ? error.message + Environment.NewLine + error.supportUrl : error.message);
                }
                return monitor;
            }
            catch
            {
                throw;
            }
            finally
            {
                httpClient.Dispose();
            }
        }
        /// <summary>
        /// Method to unregister monitor.
        /// </summary>
        /// <param name="monitorId"></param>
        public void UnregisterMonitor(Guid monitorId)
        {
            try
            {
                httpClient.DefaultRequestHeaders.Add("surgeryApiKey", Surgery_ApiKey);

                var response = httpClient.DeleteAsync(Api_ServerUrl + "/monitor/" + monitorId.ToString()).Result;
                var responseCode = (int)response.StatusCode;
                if (responseCode < 200 || responseCode >= 300)
                {
                    var responseBody = response.Content.ReadAsStringAsync().Result;
                    var error = Newtonsoft.Json.JsonConvert.DeserializeObject<Error>(responseBody);
                    throw new Exception(!string.IsNullOrEmpty(error.supportUrl) ? error.message + Environment.NewLine + error.supportUrl : error.message);
                }
            }
            catch
            {
                throw;
            }
            finally
            {
                httpClient.Dispose();
            }
        }
        /// <summary>
        /// Method to post SurgeryMonitorStatus
        /// </summary>
        /// <param name="surgeryMonitorStatus"></param>
        /// <returns></returns>
        public HttpStatusCode PostSurgeryMonitorStatus(SurgeryMonitorStatus surgeryMonitorStatus)
        {
            HttpStatusCode statusCode = new HttpStatusCode();
            try
            {
                httpClient.DefaultRequestHeaders.Add("surgeryApiKey", Surgery_ApiKey);

                string url = Api_ServerUrl + "/monitorstatus";
                var response = httpClient.PostAsJsonAsync<SurgeryMonitorStatus>(url, surgeryMonitorStatus).Result;
                statusCode = response.StatusCode;
                var responseBody = response.Content.ReadAsStringAsync().Result;
                var responseCode = (int)response.StatusCode;

                if (responseCode >= 200 && responseCode < 300)
                {
                }
                else
                {
                    var error = Newtonsoft.Json.JsonConvert.DeserializeObject<Error>(responseBody);
                    throw new Exception(!string.IsNullOrEmpty(error.supportUrl) ? error.message + Environment.NewLine + error.supportUrl : error.message);
                }
                return statusCode;

            }
            catch
            {
                throw;
            }
            finally
            {
                httpClient.Dispose();
            }
        }
        /// <summary>
        /// Method to post anesthetic values.
        /// </summary>
        /// <param name="anetheticValues"></param>
        /// <param name="deviceName"></param>
        /// <returns></returns>
        public HttpStatusCode PostAnestheticValues(List<AnestheticValues> anetheticValues, string deviceName)
        {
            HttpStatusCode statusCode = new HttpStatusCode();
            try
            {
                httpClient.DefaultRequestHeaders.Add("surgeryApiKey", Surgery_ApiKey);

                foreach (AnestheticValues av in anetheticValues)
                {
                    string url = Api_ServerUrl + "/anestheticvalues";
                    var result = httpClient.PostAsJsonAsync<AnestheticValues>(url, av).Result;
                    statusCode = result.StatusCode;
                }
                //This code is for debugging prupose, please do not delete
                //When using this code change the path accordingly
                //string path = @"C:\ProgramData\SmartFlowSheet\httpstatuscode.txt";
                //if (System.IO.File.Exists(path))
                //{
                //    string settingValue = System.IO.File.ReadAllText(path);
                //    if (settingValue.Equals("notfound"))
                //    {
                //        statusCode = HttpStatusCode.NotFound;
                //    }
                //    if (settingValue.Equals("notallowed"))
                //    {
                //        statusCode = HttpStatusCode.MethodNotAllowed;
                //    }
                //}
                return statusCode;
            }
            catch
            {
                throw;
            }
            finally
            {
                httpClient.Dispose();
            }
        }
        /// <summary>
        /// Method to fetch the list of monitors.
        /// </summary>
        /// <returns></returns>
        public IEnumerable<SurgeryMonitor> GetMonitorsList()
        {
            try
            {
                httpClient.DefaultRequestHeaders.Add("surgeryApiKey", Surgery_ApiKey);

                string url = Api_ServerUrl + "/monitors";

                var result = httpClient.GetAsync(url).Result;
                JavaScriptSerializer serializer = new JavaScriptSerializer();
                return serializer.Deserialize<IEnumerable<SurgeryMonitor>>(result.Content.ReadAsStringAsync().Result);
            }
            catch
            {
                throw;
            }
            finally
            {
                httpClient.Dispose();
            }
        }
    }
}

