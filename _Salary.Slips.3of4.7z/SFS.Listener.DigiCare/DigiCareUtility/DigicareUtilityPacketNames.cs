﻿namespace SFS.Listener.DigiCare.DigiCareUtility
{
    /// <summary>
    /// Digicare Utility Information Packets Class.
    /// </summary>
    /// <CreatedBy>Om Shakya</CreatedBy>
    /// <CreatedDate>Sep 2015</CreatedDate>
    /// <ModifyBy>...</ModifyBy>
    /// <ModifyDate>...</ModifyDate>
    public static class DigicareUtilityPacketNames
    {
        /// <summary>
        /// Get REQ_CONNECT.
        /// </summary>
        public static string REQ_CONNECT { get { return "REQ_CONNECT"; } }
        /// <summary>
        /// Get REQ_ACCEPT.
        /// </summary>
        public static string REQ_ACCEPT { get { return "REQ_ACCEPT"; } }
        /// <summary>
        /// Get REQ_DISCONNECT.
        /// </summary>
        public static string REQ_DISCONNECT { get { return "REQ_DISCONNECT"; } }
        /// <summary>
        /// Get INFO_ADMIT.
        /// </summary>
        public static string INFO_ADMIT { get { return "INFO_ADMIT"; } }
        /// <summary>
        /// Get INFO_UNITS.
        /// </summary>
        public static string INFO_UNITS { get { return "INFO_UNITS"; } }
        /// <summary>
        /// Get DATA_OBSERVATION.
        /// </summary>
        public static string DATA_OBSERVATION { get { return "DATA_OBSERVATION"; } }
        /// <summary>
        /// Get DATA_ACK.
        /// </summary>
        public static string DATA_ACK { get { return "DATA_ACK"; } }
    }
}
