﻿namespace SFS.Listener.BioNet.BioNetUtility
{
    /// <summary>
    /// BioNet Utility Primitives class.
    /// </summary>
    /// <CreatedBy>Om Shakya</CreatedBy>
    /// <CreatedDate>Sep 2015</CreatedDate>
    /// <ModifyBy>...</ModifyBy>
    /// <ModifyDate>...</ModifyDate>
    public static class BioNetUtilityPrimitives
    {
        /// <summary>
        /// Get CONNECT_REQ_Primitive, (It is fixed characters as per Bionet protocol documentation).
        /// </summary>
        /// <CreatedBy>Om Shakya</CreatedBy>
        /// <CreatedDate>Sep 2015</CreatedDate>
        /// <ModifyBy>...</ModifyBy>
        /// <ModifyDate>...</ModifyDate>
        public static string CONNECT_REQ_Primitive { get { return "01"; } }
        /// <summary>
        /// Get CONNECT_ACCEPT_Primitive, (It is fixed characters as per Bionet protocol documentation).
        /// </summary>
        /// <CreatedBy>Om Shakya</CreatedBy>
        /// <CreatedDate>Sep 2015</CreatedDate>
        /// <ModifyBy>...</ModifyBy>
        /// <ModifyDate>...</ModifyDate>
        public static string CONNECT_ACCEPT_Primitive { get { return "01"; } }
        /// <summary>
        /// Get DISCONNECT_REQ_Primitive, (It is fixed characters as per Bionet protocol documentation).
        /// </summary>
        /// <CreatedBy>Om Shakya</CreatedBy>
        /// <CreatedDate>Sep 2015</CreatedDate>
        /// <ModifyBy>...</ModifyBy>
        /// <ModifyDate>...</ModifyDate>
        public static string DISCONNECT_REQ_Primitive { get { return "00"; } }
        /// <summary>
        /// Get DATA_ACK_Primitive, (It is fixed characters as per Bionet protocol documentation).
        /// </summary>
        /// <CreatedBy>Om Shakya</CreatedBy>
        /// <CreatedDate>Sep 2015</CreatedDate>
        /// <ModifyBy>...</ModifyBy>
        /// <ModifyDate>...</ModifyDate>
        public static string DATA_ACK_Primitive { get { return "D1"; } }
    }
}
