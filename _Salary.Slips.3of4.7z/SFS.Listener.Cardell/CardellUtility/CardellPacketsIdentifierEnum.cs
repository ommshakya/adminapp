﻿namespace SFS.Listener.Cardell.CardellUtility
{
    /// <summary>
    /// Cardell Packets Identifier Enum
    /// </summary>
    /// <CreatedBy>Om Shakya</CreatedBy>
    /// <CreatedDate>Oct 2016</CreatedDate>
    /// <ModifyBy>...</ModifyBy>
    /// <ModifyDate>...</ModifyDate>
    public enum CardellPacketsIdentifierEnum
    {
        ComboPacket
    }
}
