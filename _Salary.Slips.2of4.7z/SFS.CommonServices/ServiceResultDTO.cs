﻿namespace SFS.CommonServices
{
    /// <summary>
    /// Class to object the service result.
    /// </summary>
    /// <CreatedBy>Om Shakya</CreatedBy>
    /// <CreatedDate>Aug 2016</CreatedDate>
    /// <ModifyBy>...</ModifyBy>
    /// <ModifyDate>...</ModifyDate>
    public class ServiceResultDTO
    {
        public string message { get; set; }
        public ServiceResultStatus status { get; set; }

    }
    /// <summary>
    /// Enum for service result status.
    /// </summary>
    /// <CreatedBy>Om Shakya</CreatedBy>
    /// <CreatedDate>Aug 2016</CreatedDate>
    /// <ModifyBy>...</ModifyBy>
    /// <ModifyDate>...</ModifyDate>
    public enum ServiceResultStatus
    {
        Success = 0,
        Failed = 1,
        Exception = 2
    }
}
