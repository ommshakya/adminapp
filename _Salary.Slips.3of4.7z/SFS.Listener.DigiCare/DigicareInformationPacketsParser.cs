﻿using SFS.CommonUtilities;
using System.Collections.Generic;

namespace SFS.Listener.DigiCare
{
    public static class DigicareInformationPacketsParser
    {
        /// <summary>
        /// Method to Parse USER_INFO packet.
        /// </summary>
        /// <param name="bytes_USER_INFO"></param>
        /// <returns></returns>
        /// <CreatedBy>Om Shakya</CreatedBy>
        /// <CreatedDate>Sep 2015</CreatedDate>
        /// <ModifyBy>...</ModifyBy>
        /// <ModifyDate>...</ModifyDate>
        public static Dictionary<string, string> Parse_USER_INFO(byte[] bytes_USER_INFO)
        {
            try
            {
                Dictionary<string, string> parsed_USER_INFO = new Dictionary<string, string>();

                if (bytes_USER_INFO != null && bytes_USER_INFO.Length > 0)
                {
                    ushort bed_number = GeneralMethodsUtility.ConvertOneByteToUShort(bytes_USER_INFO[53]); //22
                    parsed_USER_INFO.Add("bed_number", bed_number.ToString());
                }
                return parsed_USER_INFO;
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Method to Parse UNIT_INFO packet.
        /// </summary>
        /// <param name="bytes_UNIT_INFO"></param>
        /// <returns></returns>
        /// <CreatedBy>Om Shakya</CreatedBy>
        /// <CreatedDate>Sep 2015</CreatedDate>
        /// <ModifyBy>...</ModifyBy>
        /// <ModifyDate>...</ModifyDate>
        public static Dictionary<string, string> Parse_UNIT_INFO(byte[] bytes_UNIT_INFO)
        {
            try
            {
                Dictionary<string, string> parsed_UNIT_INFO = new Dictionary<string, string>();

                if (bytes_UNIT_INFO != null && bytes_UNIT_INFO.Length > 0)
                {
                    ushort temp1_unit = GeneralMethodsUtility.ConvertOneByteToUShort(bytes_UNIT_INFO[10]); //22
                    if (temp1_unit == 0)
                    {
                        parsed_UNIT_INFO.Add("temp1_unit", "Celsius");
                    }
                    else
                    {
                        parsed_UNIT_INFO.Add("temp1_unit", "Fahrenheit");
                    }
                }
                return parsed_UNIT_INFO;
            }
            catch
            {
                throw;
            }
        }
    }
}
