﻿namespace SFS.CommonUtilities
{
    /// <summary>
    /// Class for containing the constatnts used in project.
    /// </summary>
    /// <CreatedBy>Om Shakya</CreatedBy>
    /// <CreatedDate>Aug 2016</CreatedDate>
    /// <ModifyBy>...</ModifyBy>
    /// <ModifyDate>...</ModifyDate>
    public static class ConstantsUtility
    {
        /// <summary>
        /// Get Bed Number, for testing purpose used this constant, actually no need of this.
        /// </summary>
        /// <CreatedBy>Om Shakya</CreatedBy>
        /// <CreatedDate>Aug 2016</CreatedDate>
        /// <ModifyBy>...</ModifyBy>
        /// <ModifyDate>...</ModifyDate>
        public static byte BedNumer = 16;
    }
}
