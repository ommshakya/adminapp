﻿
using SFS.CommonUtilities;
using System.Collections.Generic;

namespace SFS.Listener.Vetland.VetlandUtility
{
    /// <summary>
    /// Vetland Utility Packets Slicer class.
    /// </summary>
    /// <CreatedBy>Om Shakya</CreatedBy>
    /// <CreatedDate>Sep 2015</CreatedDate>
    /// <ModifyBy>...</ModifyBy>
    /// <ModifyDate>...</ModifyDate>
    public static class VetlandUtilityPacketsSlicer
    {
        public static Dictionary<string, byte[]> SlicePackets(byte[] bytes, VetlandPacketsComboIdentifier identifier)
        {
            Dictionary<string, byte[]> slices = new Dictionary<string, byte[]>();
            try
            {
                if (bytes != null)
                {
                    switch (identifier)
                    {
                        case VetlandPacketsComboIdentifier.FONT_DATA_Packet:
                            slices.Add(VetlandUtilityPacketNames.FONT_DATA,
                                        GeneralMethodsUtility.ExtractBytes(bytes, 0
                                                                                , VetlandUtilityInformationPackets.Font_Data_Length));
                            break;

                    }
                }
                return slices;
            }
            catch
            {
                throw;
            }
        }
    }
}
