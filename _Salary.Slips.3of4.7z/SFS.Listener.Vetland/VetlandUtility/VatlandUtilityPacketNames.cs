﻿namespace SFS.Listener.Vetland.VetlandUtility
{
    /// <summary>
    /// Vetland Utility Information Packets Class.
    /// </summary>
    /// <CreatedBy>Om Shakya</CreatedBy>
    /// <CreatedDate>Sep 2015</CreatedDate>
    /// <ModifyBy>...</ModifyBy>
    /// <ModifyDate>...</ModifyDate>
    public static class VetlandUtilityPacketNames
    {
        public static string REQ_CONNECT { get { return "REQ_CONNECT"; } }
        public static string REQ_ACCEPT { get { return "REQ_ACCEPT"; } }
        public static string REQ_DISCONNECT { get { return "REQ_DISCONNECT"; } }
        public static string FONT_DATA { get { return "FONT_DATA"; } }
        public static string INFO_UNITS { get { return "INFO_UNITS"; } }
        public static string DATA_OBSERVATION { get { return "DATA_OBSERVATION"; } }
        public static string DATA_ACK { get { return "DATA_ACK"; } }
    }
}
