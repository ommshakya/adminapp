﻿namespace SFS.CommonUtilities.Enums
{
    /// <summary>
    /// Enum for device names.
    /// </summary>
    /// <CreatedBy>Om Shakya</CreatedBy>
    /// <CreatedDate>Aug 2016</CreatedDate>
    /// <ModifyBy>...</ModifyBy>
    /// <ModifyDate>...</ModifyDate>
    public enum DeviceNames
    {
        BioNet,
        Cardell,
        DigiCare,
        VetLand
    }
    
}
