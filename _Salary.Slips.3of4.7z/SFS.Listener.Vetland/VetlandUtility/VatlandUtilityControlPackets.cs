﻿using SFS.ConfigManager;

namespace SFS.Listener.Vetland.VetlandUtility
{
    /// <summary>
    /// Vetland Utility Control Packets Class.
    /// </summary>
    /// <CreatedBy>Om Shakya</CreatedBy>
    /// <CreatedDate>Sep 2015</CreatedDate>
    /// <ModifyBy>...</ModifyBy>
    /// <ModifyDate>...</ModifyDate>
    public static class VetlandUtilityControlPackets
    {
        public static int Connect_Req_Length
        {
            get { return AppConfigurations.Vetland_Connect_Req_Length; }
        }
        public static int Connect_Accept_Length
        {
            get { return AppConfigurations.Vetland_Connect_Accept_Length; }
        }
        public static int Bed_Number_Length
        {
            get { return AppConfigurations.Vetland_Bed_Number_Length; }
        }
    }
}








































