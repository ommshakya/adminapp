﻿namespace SFS.Listener.Cardell.CardellUtility
{
    /// <summary>
    /// Constants used for Cardell
    /// </summary>
    /// <CreatedBy>Om Shakya</CreatedBy>
    /// <CreatedDate>Oct 2016</CreatedDate>
    /// <ModifyBy>...</ModifyBy>
    /// <ModifyDate>...</ModifyDate>
    public static class CardellConstants
    {
        public const string BBBB0D = "BBBB0D";
        public const string BBBB1A = "BBBB1A";
        public const string BBBB13 = "BBBB13";
        public const string BBBB1D = "BBBB1D";
        public const string BBBB17 = "BBBB17";
        public const string BBBB18 = "BBBB18";
        public const string PacketSeparatorEEEE00 = "EEEE00";
        public const string ComboPacket = "ComboPacket";
    }
}
