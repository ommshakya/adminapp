﻿namespace SFS.Listener.DigiCare.DigiCareUtility
{
    /// <summary>
    /// Digicare Utility Primitives class.
    /// </summary>
    /// <CreatedBy>Om Shakya</CreatedBy>
    /// <CreatedDate>Sep 2015</CreatedDate>
    /// <ModifyBy>...</ModifyBy>
    /// <ModifyDate>...</ModifyDate>
    public static class DigicareUtilityPrimitives
    {
        /// <summary>
        /// Get REQ_CONNECT_Primitive.
        /// </summary>
        public static string REQ_CONNECT_Primitive { get { return "01"; } }
        /// <summary>
        /// Get REQ_ACCEPT_Primitive.
        /// </summary>
        public static string REQ_ACCEPT_Primitive { get { return "02"; } }
        /// <summary>
        /// Get REQ_DISCONNECT_Primitive.
        /// </summary>
        public static string REQ_DISCONNECT_Primitive { get { return "03"; } }
        /// <summary>
        /// Get DATA_ACK_Primitive.
        /// </summary>
        public static string DATA_ACK_Primitive { get { return "01"; } }
    }
}
