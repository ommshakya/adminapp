﻿namespace SFS.CommonUtilities.Enums
{
    /// <summary>
    /// Enum for data reuired for transfering to cloud server.
    /// </summary>
    public enum MonitorStatus
    {
        Active = 0,
        Stopped = 1,
        ConnectionToMonitorFailed = 2,
        Requesting = 3,
    }
}
