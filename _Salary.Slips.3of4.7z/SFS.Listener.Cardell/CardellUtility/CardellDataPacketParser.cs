﻿using SFS.CommonUtilities;
using SFS.ConfigManager;
using System;
using System.Collections.Generic;

namespace SFS.Listener.Cardell.CardellUtility
{
    public static class CardellDataPacketsParser
    {
        /// <summary>
        /// Method to parse all data
        /// </summary>
        /// <param name="bytesComboPacket"></param>
        /// <returns></returns>
        /// <CreatedBy>Om Shakya</CreatedBy>
        /// <CreatedDate>Oct 2016</CreatedDate>
        /// <ModifyBy>...</ModifyBy>
        /// <ModifyDate>...</ModifyDate>
        public static Dictionary<string, string> Parse_ALL_DATA(byte[] bytesComboPacket)
        {
            try
            {
                Dictionary<string, string> dictParsedDataValues = new Dictionary<string, string>();

                string hex = GeneralMethodsUtility.ConvertBytesArrayIntoHexadecimal(bytesComboPacket, bytesComboPacket.Length, false);
                string[] splittedHexStrings = hex.Split(new string[] { CardellConstants.PacketSeparatorEEEE00 }, StringSplitOptions.None);
                List<byte[]> listSeparatedPackets = new List<byte[]>();
                if (splittedHexStrings.Length > 2) 
                {
                    foreach (string hexString in splittedHexStrings)
                    {
                        if (hexString.Trim().Length > 0)
                        {
                            string individualPacketHexstring = string.Concat(hexString, CardellConstants.PacketSeparatorEEEE00);
                            listSeparatedPackets.Add(GeneralMethodsUtility.HexStringToByteArray(individualPacketHexstring));
                        }
                    }
                }
                if (listSeparatedPackets != null && listSeparatedPackets.Count > 0)
                {
                    foreach (byte[] bytesIndividualPacket in listSeparatedPackets)
                    {
                        if (bytesIndividualPacket != null && bytesIndividualPacket.Length > 0)
                        {
                            byte[] first3Bytes = GeneralMethodsUtility.ExtractBytes(bytesIndividualPacket, 0, 3);

                            string first3BytesHex = GeneralMethodsUtility.ConvertBytesArrayIntoHexadecimal(first3Bytes, first3Bytes.Length, false);

                            switch (first3BytesHex)
                            {
                                case CardellConstants.BBBB0D:
                                    if (!(dictParsedDataValues.ContainsKey("HR_HeartRate"))) //Condition Added to check key already exists or not
                                    {
                                        byte[] bytesHR = GeneralMethodsUtility.ExtractBytes(bytesIndividualPacket, 8, 2);
                                        if (!AppConfigurations.Cardell_IsLittleEndian)
                                            Array.Reverse(bytesHR);

                                        int HR = GeneralMethodsUtility.ConvertTwoBytesToInt16(bytesHR);
                                        dictParsedDataValues.Add("HR_HeartRate", HR.ToString());
                                    }
                                    break;
                                case CardellConstants.BBBB1A:
                                    if (!(dictParsedDataValues.ContainsKey("SpO2Value"))) //Condition Added to check key already exists or not
                                    {
                                        byte[] bytesSpO2 = GeneralMethodsUtility.ExtractBytes(bytesIndividualPacket, 7, 2);
                                        if (!AppConfigurations.Cardell_IsLittleEndian)
                                            Array.Reverse(bytesSpO2);

                                        int SpO2Value = GeneralMethodsUtility.ConvertTwoBytesToInt16(bytesSpO2);
                                        dictParsedDataValues.Add("SpO2Value", SpO2Value.ToString());
                                    }
                                    break;
                                case CardellConstants.BBBB13:
                                    if (!(dictParsedDataValues.ContainsKey("Pulse Rate"))) //Condition Added to check key already exists or not
                                    {
                                        byte[] bytesPR = GeneralMethodsUtility.ExtractBytes(bytesIndividualPacket, 6, 2);
                                        if (!AppConfigurations.Cardell_IsLittleEndian)
                                            Array.Reverse(bytesPR);

                                        int PulseRate = GeneralMethodsUtility.ConvertTwoBytesToInt16(bytesPR);
                                        dictParsedDataValues.Add("Pulse Rate", PulseRate.ToString());
                                    }
                                    break;
                                case CardellConstants.BBBB1D:
                                    if (!(dictParsedDataValues.ContainsKey("RespRate"))) //Condition Added to check key already exists or not
                                    {
                                        byte[] bytesRR = GeneralMethodsUtility.ExtractBytes(bytesIndividualPacket, 8, 2);
                                        if (!AppConfigurations.Cardell_IsLittleEndian)
                                            Array.Reverse(bytesRR);

                                        int RespRate = GeneralMethodsUtility.ConvertTwoBytesToInt16(bytesRR);
                                        dictParsedDataValues.Add("RespRate", RespRate.ToString());
                                    }
                                    if (!(dictParsedDataValues.ContainsKey("EtCO2"))) //Condition Added to check key already exists or not
                                    {
                                        byte[] bytesCo2 = GeneralMethodsUtility.ExtractBytes(bytesIndividualPacket, 10, 2);
                                        if (!AppConfigurations.Cardell_IsLittleEndian)
                                            Array.Reverse(bytesCo2);

                                        int CO2Value = GeneralMethodsUtility.ConvertTwoBytesToInt16(bytesCo2);
                                        dictParsedDataValues.Add("EtCO2 ", CO2Value.ToString());
                                    }
                                    break;
                                case CardellConstants.BBBB17:
                                    if (!(dictParsedDataValues.ContainsKey("NiBpSysDataHigh"))) //Condition Added to check key already exists or not
                                    {
                                        byte[] bytesNiBpSysDataHigh = GeneralMethodsUtility.ExtractBytes(bytesIndividualPacket, 13, 2);
                                        if (!AppConfigurations.Cardell_IsLittleEndian)
                                            Array.Reverse(bytesNiBpSysDataHigh);

                                        int NiBpSysDataHigh = GeneralMethodsUtility.ConvertTwoBytesToInt16(bytesNiBpSysDataHigh);
                                        dictParsedDataValues.Add("NiBpSysDataHigh", NiBpSysDataHigh.ToString());
                                    }
                                    if (!(dictParsedDataValues.ContainsKey("NiBpMeanDataHigh"))) //Condition Added to check key already exists or not
                                    {
                                        byte[] bytesNiBpMeanDataHigh = GeneralMethodsUtility.ExtractBytes(bytesIndividualPacket, 15, 2);
                                        if (!AppConfigurations.Cardell_IsLittleEndian)
                                            Array.Reverse(bytesNiBpMeanDataHigh);

                                        int NiBpMeanDataHigh = GeneralMethodsUtility.ConvertTwoBytesToInt16(bytesNiBpMeanDataHigh);
                                        dictParsedDataValues.Add("NiBpMeanDataHigh", NiBpMeanDataHigh.ToString());
                                    }
                                    if (!(dictParsedDataValues.ContainsKey("NiBpDiaDataHigh"))) //Condition Added to check key already exists or not
                                    {
                                        byte[] bytesNiBpDiaDataHigh = GeneralMethodsUtility.ExtractBytes(bytesIndividualPacket, 17, 2);
                                        if (!AppConfigurations.Cardell_IsLittleEndian)
                                            Array.Reverse(bytesNiBpDiaDataHigh);

                                        int NiBpDiaDataHigh = GeneralMethodsUtility.ConvertTwoBytesToInt16(bytesNiBpDiaDataHigh);
                                        dictParsedDataValues.Add("NiBpDiaDataHigh", NiBpDiaDataHigh.ToString());
                                    }
                                    break;
                                case CardellConstants.BBBB18:
                                    byte[] bytesTemp = GeneralMethodsUtility.ExtractBytes(bytesIndividualPacket, 7, 2);
                                    if (!(dictParsedDataValues.ContainsKey("Temp1"))) //Condition Added to check key already exists or not
                                    {
                                        if (!AppConfigurations.Cardell_IsLittleEndian)
                                            Array.Reverse(bytesTemp);

                                        int TempDataT1 = GeneralMethodsUtility.ConvertTwoBytesToInt16(bytesTemp);
                                        dictParsedDataValues.Add("Temp1", (TempDataT1 / 10.0).ToString());
                                    }
                                    if (!(dictParsedDataValues.ContainsKey("Temp2"))) //Condition Added to check key already exists or not
                                    {
                                        bytesTemp = GeneralMethodsUtility.ExtractBytes(bytesIndividualPacket, 9, 2);
                                        if (!AppConfigurations.Cardell_IsLittleEndian)
                                            Array.Reverse(bytesTemp);

                                        int TempDataRT2 = GeneralMethodsUtility.ConvertTwoBytesToInt16(bytesTemp);
                                        dictParsedDataValues.Add("Temp2", (TempDataRT2 / 10.0).ToString());
                                    }
                                    break;
                            }
                        }
                    }
                }
                return dictParsedDataValues;
            }
            catch
            {
                throw;
            }
        }
    }
}
