﻿using SFS.CommonUtilities;
using SFS.CommonUtilities.Enums;
using SFS.ConfigManager;
using SFS.FileWritter;
using SFS.Helper;
using SFS.Listener.DigiCare.DigiCareDTO;
using SFS.Listener.DigiCare.DigiCareUtility;
using SFS.ObjectSerializer;
using smartflowsheet.surgery.api.model.events;
using smartflowsheet.surgery.api.model.objects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Timers;

namespace SFS.Listener.DigiCare
{
    public static class DigicareServer
    {
        /// <summary>
        /// This is the common tcp listener object for the DigiCare.
        /// </summary>
        private static TcpListener _tcpListener = null;
        /// <summary>
        /// Stop the DigiCare Server.
        /// </summary>
        /// <param name="stopSurgeryMonitor"></param>
        public static void StopServer(StopSurgeryMonitor stopSurgeryMonitor)
        {
            StringBuilder msg = new StringBuilder();
            try
            {
                //Handle DigiCare Connected Client TcpClient
                if (DigiCareMultiSupportDTO.DigiCareConnectedClientTcpClient != null)
                {
                    if (DigiCareMultiSupportDTO.DigiCareConnectedClientTcpClient.ContainsKey(stopSurgeryMonitor.monitorId))
                    {
                        TcpClient client = DigiCareMultiSupportDTO.DigiCareConnectedClientTcpClient[stopSurgeryMonitor.monitorId];

                        if (client != null)
                        {
                            if (client.Connected)
                            {
                                client.Client.Shutdown(SocketShutdown.Both);
                                client.Client.Close();
                                client.Close();
                                msg.AppendLine("DigiCareConnectedClientTcpClient closed!");
                            }
                        }
                        DigiCareMultiSupportDTO.DigiCareConnectedClientTcpClient.Remove(stopSurgeryMonitor.monitorId);
                        msg.AppendLine("DigiCareConnectedClientTcpClient removed!");
                    }
                }
            }
            catch (Exception ex)
            {
                msg.AppendLine("DigiCareConnectedClientTcpClient Exception: " + ex.ToString());
            }
            try
            {
                //Handle DigiCare Connected Clients
                if (DigiCareMultiSupportDTO.DigiCareConnectedClients != null)
                {
                    if (DigiCareMultiSupportDTO.DigiCareConnectedClients.ContainsKey(stopSurgeryMonitor.monitorId))/////
                    {
                        DigiCareMultiSupportDTO.DigiCareConnectedClients.Remove(stopSurgeryMonitor.monitorId);
                        msg.AppendLine("DigiCareConnectedClients removed!");
                    }
                }
            }
            catch (Exception ex)
            {
                msg.AppendLine("DigiCareConnectedClients Exception: " + ex.ToString());
            }
            try
            {
                //Handle DigiCare Connected Client DataTransferThreads
                if (DigiCareMultiSupportDTO.DigiCareConnectedClientDataTransferThreads != null)
                {
                    if (DigiCareMultiSupportDTO.DigiCareConnectedClientDataTransferThreads.ContainsKey(stopSurgeryMonitor.monitorId))
                    {
                        Thread thread = DigiCareMultiSupportDTO.DigiCareConnectedClientDataTransferThreads[stopSurgeryMonitor.monitorId];

                        if (thread != null)
                        {
                            thread.Abort();
                            msg.AppendLine("DigiCareConnectedClientDataTransferThreads aborted!");
                        }
                        DigiCareMultiSupportDTO.DigiCareConnectedClientDataTransferThreads.Remove(stopSurgeryMonitor.monitorId);
                        msg.AppendLine("DigiCareConnectedClientDataTransferThreads removed!");
                    }
                }
            }
            catch (Exception ex)
            {
                msg.AppendLine("DigiCareConnectedClientDataTransferThreads Exception: " + ex.ToString());
            }
            try
            {
                //Handle DigiCare Connected Client DataTransferThread Timers
                if (DigiCareMultiSupportDTO.DigiCareConnectedClientDataTransferThreadTimers != null)
                {
                    msg.AppendLine("DigiCareConnectedClientDataTransferThreadTimers count!" + DigiCareMultiSupportDTO.DigiCareConnectedClientDataTransferThreadTimers.Count.ToString());

                    if (DigiCareMultiSupportDTO.DigiCareConnectedClientDataTransferThreadTimers.ContainsKey(stopSurgeryMonitor.monitorId))
                    {
                        System.Timers.Timer timer = DigiCareMultiSupportDTO.DigiCareConnectedClientDataTransferThreadTimers[stopSurgeryMonitor.monitorId];

                        if (timer != null)
                        {
                            timer.Stop();
                            timer.Dispose();
                            msg.AppendLine("DigiCareConnectedClientDataTransferThreadTimers stoped!");
                        }
                        DigiCareMultiSupportDTO.DigiCareConnectedClientDataTransferThreadTimers.Remove(stopSurgeryMonitor.monitorId);
                        msg.AppendLine("DigiCareConnectedClientDataTransferThreadTimers removed!");
                    }
                }
            }
            catch (Exception ex)
            {
                msg.AppendLine("DigiCareConnectedClientDataTransferThreadTimers Exception: " + "(" + stopSurgeryMonitor.monitorId.ToString() + ")" + ex.ToString());
            }

            try
            {
                //Finally stop Digicare listener completely if there is no active connection
                if (DigiCareMultiSupportDTO.isDigiCareListenerRunning)
                {
                    if (DigiCareMultiSupportDTO.DigiCareConnectedClients != null &&
                        DigiCareMultiSupportDTO.DigiCareConnectedClientTcpClient != null &&
                        DigiCareMultiSupportDTO.DigiCareConnectedClients.Count.Equals(0) &&
                        DigiCareMultiSupportDTO.DigiCareConnectedClientTcpClient.Count.Equals(0))
                    {
                        if (_tcpListener != null)
                        {
                            _tcpListener.Server.Close();
                            _tcpListener.Stop();
                            DigiCareMultiSupportDTO.isDigiCareListenerRunning = false;
                            DigiCareMultiSupportDTO.DigiCareConnectedClients = null;
                            DigiCareMultiSupportDTO.DigiCareConnectedClientTcpClient = null;
                            DigiCareMultiSupportDTO.DigiCareConnectedClientDataTransferThreads = null;
                            DigiCareMultiSupportDTO.DigiCareConnectedClientDataTransferThreadTimers = null;
                            msg.AppendLine("_tcpListener closed stoped!");
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                msg.AppendLine("_tcpListener Exception: " + ex.ToString());
            }

            try
            {
                //Remove the corresponding Live Data File to avoid posting the anesthetic values in case if monitor is not connected
                RemoveLiveFile(stopSurgeryMonitor.monitorId);
                RemoveTemperatureFile(stopSurgeryMonitor.monitorId);
            }
            catch (Exception ex)
            {
                msg.AppendLine("RemoveLiveFile Exception: " + ex.ToString());
            }
            try
            {
                SettingsUtility.SetDisconnectSetting(DisconnectSetting.False, DeviceIdentifier.DigiCare, stopSurgeryMonitor.monitorId.ToString());
            }
            catch (Exception ex)
            {
                msg.AppendLine("SettingsUtility.SetDisconnectSetting Exception: " + ex.ToString());
            }
            LogWriter.WriteToFile(msg.ToString(), LogHelperUtility.GetLogFileNameForCommonTraceing(DeviceIdentifier.DigiCare,
                                                                            stopSurgeryMonitor.monitorId.ToString()));

            LogWriter.WriteToLog(msg.ToString(), LogHelperUtility.GetLogFileNameForListener(DeviceIdentifier.DigiCare,
                                                                            stopSurgeryMonitor.monitorId.ToString()));
        }
        private static void RemoveLiveFile(Guid monitorId)
        {
            try
            {
                //Remove the corresponding Live Data File to avoid posting the anesthetic values in case if monitor is not connected
                string directory = SettingsUtility.GetCommonDataPath(CommonDataSettingTypes.LiveDataFile_Folder, DeviceIdentifier.DigiCare);
                if (FileProcessorUtility.DoesExistsDirectory(directory))
                {
                    string[] allFiles = FileProcessorUtility.GetAllFilesFromDirectory(directory).Where(x => x.Contains(monitorId.ToString())).ToArray();
                    if (allFiles != null && allFiles.Length > 0)
                    {
                        string file = allFiles[allFiles.Length - 1];
                        System.IO.File.Delete(file);
                    }
                }
            }
            catch
            {
                throw;
            }
        }
        /// <summary>
        /// Remove temperature unit setting file
        /// </summary>
        /// <param name="monitorId"></param>
        private static void RemoveTemperatureFile(Guid monitorId)
        {
            try
            {
                //Remove the corresponding Live Data File to avoid posting the anesthetic values in case if monitor is not connected
                string file = SettingsUtility.GetCommonDataPath(CommonDataSettingTypes.TemperatureUnitSetting_File, DeviceIdentifier.DigiCare);
                if (System.IO.File.Exists(file))
                {
                    System.IO.File.Delete(file);
                }
            }
            catch
            {
                throw;
            }
        }
        /// <summary>
        /// Start the DigiCare Server.
        /// </summary>
        /// <param name="startSurgeryMonitor"></param>
        public static void StartServer(StartSurgeryMonitor startSurgeryMonitor)
        {
            try
            {
                //Detect the IP Address and get port# of the DigiCare Server to run
                IPAddress ipAddress = GeneralMethodsUtility.AutoDetectIPAddress();
                int port = AppConfigurations.Digicare_ServerPort;

                LogWriter.WriteToFile(string.Format(@"DigiCare Server IP Address: {0} Port#: {1} Running Status: {2}",
                                        ipAddress.ToString(),
                                        port.ToString(),
                                        DigiCareMultiSupportDTO.isDigiCareListenerRunning),
                                        LogHelperUtility.GetLogFileNameForCommonTraceing(DeviceIdentifier.DigiCare,
                                                                                            startSurgeryMonitor.monitorId.ToString()));

                //Check if DigiCare Server is not running then run and start it
                if (!DigiCareMultiSupportDTO.isDigiCareListenerRunning)
                {
                    //Start the tcp listener
                    _tcpListener = new TcpListener(ipAddress, port);
                    _tcpListener.Start();

                    //Instantiate the required collections
                    DigiCareMultiSupportDTO.isDigiCareListenerRunning = true;
                    DigiCareMultiSupportDTO.DigiCareConnectedClients = new Dictionary<Guid, IPAddress>();
                    DigiCareMultiSupportDTO.DigiCareConnectedClientTcpClient = new Dictionary<Guid, TcpClient>();
                    DigiCareMultiSupportDTO.DigiCareConnectedClientDataTransferThreads = new Dictionary<Guid, Thread>();
                    DigiCareMultiSupportDTO.DigiCareConnectedClientDataTransferThreadTimers = new Dictionary<Guid, System.Timers.Timer>();


                    string msg = string.Format(@"Started Digicare PM Server. Waiting for a client...MonitorId: {0} Running Status: {1}",
                                                    startSurgeryMonitor.monitorId, DigiCareMultiSupportDTO.isDigiCareListenerRunning);

                    LogWriter.WriteToFile(msg, LogHelperUtility.GetLogFileNameForCommonTraceing(DeviceIdentifier.DigiCare,
                                                                                    startSurgeryMonitor.monitorId.ToString()));

                    //Loop to accept the tcp client/monitor
                    WaitForClients(startSurgeryMonitor);
                }
                //If the DigiCare Server is already running then start accepting the tcp client/monitor
                else
                {
                    string msg = string.Format(@"Started to listen MonitorId: {0} Running Status: {1}",
                                                    startSurgeryMonitor.monitorId, DigiCareMultiSupportDTO.isDigiCareListenerRunning);

                    LogWriter.WriteToFile(msg, LogHelperUtility.GetLogFileNameForCommonTraceing(DeviceIdentifier.DigiCare,
                                                                                    startSurgeryMonitor.monitorId.ToString()));

                    //Loop to accept the tcp client/monitor
                    WaitForClients(startSurgeryMonitor);
                }
            }
            catch (SocketException)
            {
                //Need to check whether it is appropriate or not to log
            }
            catch (Exception)
            {
                //Need to check whether it is appropriate or not to log
            }
        }
        /// <summary>
        /// Wait for tcp client request, if it is allowed and not listeneting then start listening the monitor.
        /// </summary>
        /// <param name="startSurgeryMonitor"></param>
        private static void WaitForClients(StartSurgeryMonitor startSurgeryMonitor)
        {
            try
            {
                int clientsCount = 1;

                #region CheckandWaitForConnection

                //check  client is connected or not and wait for 10 seconds.
                bool IsListenerConnected = CheckandWaitForConnection();
                if (!IsListenerConnected)
                {
                    //WORKING ON THIS POINT 14 TO IMPLEMENT
                    //#Evg.14 - Power failure
                    //Action: Listener sends error message to Status-API (/monitorstatus);
                    string msgCanNotConnectMonitor = CommonMessages.CanNotConnectTheMonitor;
                    SurgeryMonitorStatusHelper.PostSurgeryMonitorStatusWithLogInListenerTrace(
                                                                        startSurgeryMonitor.monitorId
                                                                        , msgCanNotConnectMonitor
                                                                        , DeviceIdentifier.DigiCare
                                                                        , SurgeryMonitorStatus.Status.ConnectionToMonitorFailed);

                    //Action: Listener adds log message
                    LogWriter.WriteToFile(msgCanNotConnectMonitor
                                            , LogHelperUtility.GetLogFileNameForCommonTraceing(DeviceIdentifier.DigiCare
                                            , startSurgeryMonitor.monitorId.ToString()));
                }

                #endregion

                while (DigiCareMultiSupportDTO.isDigiCareListenerRunning)
                {
                    TcpClient newClient = null;
                    try
                    {
                        //Accept the client temporarily
                        newClient = _tcpListener.AcceptTcpClient();
                        LogWriter.WriteToFile("Client Accepted!", LogHelperUtility.GetLogFileNameForCommonTraceing(DeviceIdentifier.DigiCare,
                                                                                                startSurgeryMonitor.monitorId.ToString()));

                        //24th Feb 2017, Urgent fix - Send status to the server when connected to the monitor
                        string msgMonitorConnected = CommonMessages.MonitorConnectedSuccessfully;
                        SurgeryMonitorStatusHelper.PostSurgeryMonitorStatusWithLogInListenerTrace(
                                                                            startSurgeryMonitor.monitorId
                                                                            , msgMonitorConnected
                                                                            , DeviceIdentifier.DigiCare
                                                                            , SurgeryMonitorStatus.Status.Active);

                        //Get RemoteEndPoint of current client
                        IPEndPoint remoteEndPoint = (IPEndPoint)newClient.Client.RemoteEndPoint;

                        if (remoteEndPoint != null)
                        {
                            string msg = string.Format(@"Temporarily accepted the client. Remote IP Address: {0} Remote port#: {1}",
                                                        remoteEndPoint.Address, remoteEndPoint.Port);
                            LogWriter.WriteToFile(msg, LogHelperUtility.GetLogFileNameForCommonTraceing(DeviceIdentifier.DigiCare,
                                                                                            startSurgeryMonitor.monitorId.ToString()));
                        }

                        //Check whether the ip address of this MonitorId is registered/allowed
                        //Look up the remote ip address in serialized registered monitors
                        bool isAllowed = false;
                        if (SerializedObjects.MonitorsList.Where(x => x.monitorId.Equals(startSurgeryMonitor.monitorId)).FirstOrDefault().monitorIPAddress.Equals(remoteEndPoint.Address))
                        {
                            isAllowed = true;
                        }

                        //Check whether the client/monitor with this remote ip address is already running
                        //Look up the remote ip address in DigiCareMultiSupportDTO.DigiCareConnectedClients
                        bool isListening = false;
                        if (DigiCareMultiSupportDTO.DigiCareConnectedClients != null && DigiCareMultiSupportDTO.DigiCareConnectedClients.Count > 0)
                        {
                            isListening = DigiCareMultiSupportDTO.DigiCareConnectedClients.ContainsValue(remoteEndPoint.Address);
                        }

                        LogWriter.WriteToFile("isListening - isAllowed!" + isListening + isAllowed, LogHelperUtility.GetLogFileNameForCommonTraceing(DeviceIdentifier.DigiCare,
                                                                                                startSurgeryMonitor.monitorId.ToString()));

                        //Check if this client/monitor is registered/allowed and is not running then start listening it by HandleClient
                        if (isAllowed & !isListening)
                        {
                            //Add it to the connected clients list
                            DigiCareMultiSupportDTO.DigiCareConnectedClients.Add(startSurgeryMonitor.monitorId, remoteEndPoint.Address);

                            //Prepare a list of startSurgeryMonitor and client itself to pass to HandleClient
                            List<object> list = new List<object>();
                            list.Add(startSurgeryMonitor);
                            list.Add(newClient);

                            string msg = string.Format(@"Client/Monitor is connected. Monitor Id: {0} Remote IP Address: {1}",
                                                        startSurgeryMonitor.monitorId.ToString(), remoteEndPoint.Address);

                            LogWriter.WriteToFile(msg, LogHelperUtility.GetLogFileNameForCommonTraceing(DeviceIdentifier.DigiCare,
                                                                                            startSurgeryMonitor.monitorId.ToString()));
                            clientsCount++;

                            //IMPORTANT: No need to create a dedicated thread, current instance is itself a thread from SurgeryMonitorManager

                            //So just call HandleClient
                            HandleClientCommunication(list);
                        }
                        //If it is nor registered/allowed, close the connection
                        else
                        {
                            try
                            {
                                //Close the client that is yet accepted temporarily
                                newClient.Close();
                            }
                            catch
                            {
                                //No need to log this exception, it will increase the file size
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        LogWriter.WriteToFile(ex.ToString(), LogHelperUtility.GetLogFileNameForCommonTraceing(DeviceIdentifier.DigiCare,
                                                                                                startSurgeryMonitor.monitorId.ToString()));
                    }
                }
            }
            catch (Exception ex)
            {
                LogWriter.WriteToFile(ex.ToString(), LogHelperUtility.GetLogFileNameForCommonTraceing(DeviceIdentifier.DigiCare,
                                                                                        startSurgeryMonitor.monitorId.ToString()));
            }
        }
        /// <summary>
        /// Method to check that client is connected or not and wait for 10 seconds.
        /// </summary>
        /// <returns></returns>
        private static bool CheckandWaitForConnection()
        {
            bool IsListenerConnected = true;
            int count = 1;
            while (!_tcpListener.Pending())
            {
                if (count == 2)
                {
                    IsListenerConnected = false;
                    break;
                }
                Thread.Sleep(10000);

                count++;
                continue;

            }
            return IsListenerConnected;
        }
        /// <summary>
        /// Handle the client communication for the connected monitor/tcpclient.
        /// </summary>
        /// <param name="obj"></param>
        private static void HandleClientCommunication(object obj)
        {
            string monitorId = string.Empty;
            try
            {
                if (obj != null)
                {
                    //Unbox the obj received and extract the StartSurgeryMonitor & TcpClient objects
                    List<object> list = (List<object>)obj;
                    StartSurgeryMonitor startSurgeryMonitor = (StartSurgeryMonitor)list[0];
                    TcpClient client = (TcpClient)list[1];

                    monitorId = startSurgeryMonitor.monitorId.ToString();

                    //Add this tcp client to the collection
                    DigiCareMultiSupportDTO.DigiCareConnectedClientTcpClient.Add(startSurgeryMonitor.monitorId, client);

                    if (client != null && startSurgeryMonitor != null)
                    {
                        string msg = string.Format(@"Handle client! Starting communication! Monitor Id: {0}",
                                                    startSurgeryMonitor.monitorId.ToString());

                        LogWriter.WriteToFile(msg, LogHelperUtility.GetLogFileNameForCommonTraceing(DeviceIdentifier.DigiCare,
                                                                                        startSurgeryMonitor.monitorId.ToString()));

                        NetworkStream networkStream = null;
                        int veryFirstObservationDataCounter = 0;

                        ushort BedNumber_UShort = 0;
                        byte BedNumber;
                        networkStream = client.GetStream();

                        //Set it to disconnect false at start, on StopMonitor() it will be set to TRUE
                        SettingsUtility.SetDisconnectSetting(DisconnectSetting.False, DeviceIdentifier.DigiCare,
                                                                startSurgeryMonitor.monitorId.ToString());

                        //
                        //Additional logging, Feb 2017
                        LogWriter.WriteToLog("DisconnectSetting set : " + DisconnectSetting.False.ToString(), LogHelperUtility.GetLogFileNameForListener(DeviceIdentifier.DigiCare,
                                                            startSurgeryMonitor.monitorId.ToString()));

                        networkStream.ReadTimeout = 1000;

                        int counterRequests = 0;
                        bool doesListen = true;

                        #region Inner loop to do data communication
                        while (doesListen)
                        {
                            try
                            {
                                //Receive all the bytes from device
                                int noOfBytesReceived = 0;
                                byte[] bytes_request = new byte[1024];

                                noOfBytesReceived = networkStream.Read(bytes_request, 0, bytes_request.Length);

                                if (noOfBytesReceived == 0)
                                    break;

                                //Convert all bytes, first byte and first two bytes into hexadecimal string 
                                string full_request_hex = GeneralMethodsUtility.ConvertBytesArrayIntoHexadecimal(bytes_request, noOfBytesReceived, true);
                                string first_byte_string = GeneralMethodsUtility.ConvertBytesArrayIntoHexadecimal(bytes_request, 1, false);
                                string first_two_bytes_string = GeneralMethodsUtility.ConvertBytesArrayIntoHexadecimal(bytes_request, 2, false);

                                //Additional logging, Feb 2017
                                LogWriter.WriteToLog("Complete packet received : " + full_request_hex, LogHelperUtility.GetLogFileNameForListener(DeviceIdentifier.DigiCare,
                                                                    startSurgeryMonitor.monitorId.ToString()));

                                //Check if the request is CONNECT_REQ - C001 is the CONNECT_REQ Header and Primitive bytes
                                if (noOfBytesReceived.Equals(DigicareUtilityControlPackets.Connect_Req_Length) && first_two_bytes_string.ToUpper().Equals(DigicareUtilityRequests.CONNECT_REQ_HeaderPrimitive))//"C001"))
                                {
                                    LogWriter.WriteToLog(string.Format(@"Received CONNECT_REQ ({0} bytes)!", noOfBytesReceived), LogHelperUtility.GetLogFileNameForListener(DeviceIdentifier.DigiCare, startSurgeryMonitor.monitorId.ToString()));
                                    LogWriter.WriteToLog(full_request_hex, LogHelperUtility.GetLogFileNameForListener(DeviceIdentifier.DigiCare, startSurgeryMonitor.monitorId.ToString()));

                                    //Fetch the 3rd byte as Bed Number, convert to integer(ushort)
                                    BedNumber = bytes_request[2];
                                    BedNumber_UShort = Convert.ToUInt16(BedNumber);

                                    //Get the CONNECT_ACCEPT request and send to device as connection acceptance
                                    byte[] bytes_CONNECT_ACCEPT = DigicareUtilityControlPackets.CONNECT_ACCEPT(BedNumber_UShort);
                                    networkStream.Write(bytes_CONNECT_ACCEPT, 0, DigicareUtilityControlPackets.Connect_Accept_Length);

                                    //Convert sent CONNECT_ACCEPT request into hexadecimal string
                                    string CONNECT_ACCEPT_hex = GeneralMethodsUtility.ConvertBytesArrayIntoHexadecimal(bytes_request, DigicareUtilityControlPackets.Connect_Accept_Length, false);

                                    LogWriter.WriteToLog(string.Format(@"CONNECT_ACCEPT ({0} bytes) sent!", bytes_CONNECT_ACCEPT.Length), LogHelperUtility.GetLogFileNameForListener(DeviceIdentifier.DigiCare, startSurgeryMonitor.monitorId.ToString()));
                                    LogWriter.WriteToLog(CONNECT_ACCEPT_hex, LogHelperUtility.GetLogFileNameForListener(DeviceIdentifier.DigiCare, startSurgeryMonitor.monitorId.ToString()));
                                }
                                else
                                {
                                    //Check if the request is USER_ADMIT_ALAM_SETTING_PACKATES(189 bytes) -- first byte C1 is the Header byte
                                    if (noOfBytesReceived.Equals(DigicareUtilityInformationPackets.Info_Admit_Length + DigicareUtilityInformationPackets.Info_Units_Length)
                                        && first_byte_string.ToUpper().Equals(DigicareUtilityHeaders.INFO_ADMIT_Header))//"C1"))
                                    {
                                        LogWriter.WriteToLog(string.Format(@"Received INFO_ADMIT_UNITS_PACKATES ({0} bytes)!", noOfBytesReceived), LogHelperUtility.GetLogFileNameForListener(DeviceIdentifier.DigiCare, startSurgeryMonitor.monitorId.ToString()));
                                        LogWriter.WriteToLog(full_request_hex, LogHelperUtility.GetLogFileNameForListener(DeviceIdentifier.DigiCare, startSurgeryMonitor.monitorId.ToString()));

                                        ProcessPackets(bytes_request, DigicarePacketsComboIdentifier.ADMIT_UNITS_PacketsCombo, startSurgeryMonitor);
                                    }
                                    //Check if the request is SETTING_PARAM_PACKETS(75 bytes) -- first byte C4 is the Header byte
                                    if (noOfBytesReceived.Equals(DigicareUtilityDataPackets.Data_Observation_Length)
                                        && first_byte_string.ToUpper().Equals(DigicareUtilityHeaders.DATA_OBSERVATION_Header))
                                    {
                                        LogWriter.WriteToLog(string.Format(@"Received DATA_OBSERVATION_PACKET ({0} bytes)!", noOfBytesReceived), LogHelperUtility.GetLogFileNameForListener(DeviceIdentifier.DigiCare, startSurgeryMonitor.monitorId.ToString()));
                                        LogWriter.WriteToLog(full_request_hex, LogHelperUtility.GetLogFileNameForListener(DeviceIdentifier.DigiCare, startSurgeryMonitor.monitorId.ToString()));

                                        ProcessPackets(bytes_request, DigicarePacketsComboIdentifier.OBSERVATION_Packet, startSurgeryMonitor);

                                        if (veryFirstObservationDataCounter.Equals(0))
                                        {
                                            //Additional logging, Feb 2017
                                            LogWriter.WriteToLog("Started first dataset posting.", LogHelperUtility.GetLogFileNameForListener(DeviceIdentifier.DigiCare,
                                                                                startSurgeryMonitor.monitorId.ToString()));

                                            Thread threadDataTransfer = new Thread(new ParameterizedThreadStart(StartDataTransfer));
                                            threadDataTransfer.Name = "DataTransferThread";
                                            DigiCareMultiSupportDTO.DigiCareConnectedClientDataTransferThreads.Add(startSurgeryMonitor.monitorId, threadDataTransfer);
                                            veryFirstObservationDataCounter = 1;
                                            threadDataTransfer.Start(startSurgeryMonitor);

                                            //Additional logging, Feb 2017
                                            LogWriter.WriteToLog("First dataset posting called successfuly.", LogHelperUtility.GetLogFileNameForListener(DeviceIdentifier.DigiCare,
                                                                                startSurgeryMonitor.monitorId.ToString()));
                                        }

                                        counterRequests++;
                                        if ((counterRequests + 1).Equals(int.MaxValue))
                                            counterRequests = 0;

                                        //Retreive the disconnect flag
                                        DisconnectSetting doesDisconnect = SettingsUtility.ReadDisconnectSetting(DeviceIdentifier.DigiCare,
                                                                                                startSurgeryMonitor.monitorId.ToString());


                                        //Additional logging, Feb 2017
                                        LogWriter.WriteToLog("DisconnectSetting read: " + doesDisconnect.ToString(), LogHelperUtility.GetLogFileNameForListener(DeviceIdentifier.DigiCare,
                                                                            startSurgeryMonitor.monitorId.ToString()));

                                        LogWriter.WriteToLog(string.Format(@"Step: {0} - {1}", counterRequests, doesDisconnect),
                                                                    LogHelperUtility.GetLogFileNameForListener(DeviceIdentifier.DigiCare, startSurgeryMonitor.monitorId.ToString()));

                                        byte[] bytes_DATA_ACK;
                                        if (doesDisconnect.Equals(DisconnectSetting.True))
                                        {
                                            bytes_DATA_ACK = new byte[0];
                                            networkStream.Write(bytes_DATA_ACK, 0, bytes_DATA_ACK.Length);
                                            client.Client.Shutdown(SocketShutdown.Send);
                                        }
                                        else
                                        {
                                            bytes_DATA_ACK = DigicareUtilityDataPackets.DATA_ACK(BedNumber_UShort);
                                            networkStream.Write(bytes_DATA_ACK, 0, bytes_DATA_ACK.Length);
                                        }

                                        string DATA_ACK_hex = GeneralMethodsUtility.ConvertBytesArrayIntoHexadecimal(bytes_DATA_ACK, bytes_DATA_ACK.Length, false);

                                        LogWriter.WriteToLog(string.Format(@"DATA_ACK ({0} bytes) sent!", bytes_DATA_ACK.Length), LogHelperUtility.GetLogFileNameForListener(DeviceIdentifier.DigiCare, startSurgeryMonitor.monitorId.ToString()));
                                        LogWriter.WriteToLog(DATA_ACK_hex, LogHelperUtility.GetLogFileNameForListener(DeviceIdentifier.DigiCare, startSurgeryMonitor.monitorId.ToString()));
                                    }
                                    //Check if the request is DISCONNECT_REQ(3 bytes) - C000 is the DISCONNECT_REQ Header and Primitive bytes
                                    if (noOfBytesReceived.Equals(DigicareUtilityControlPackets.Disconnect_Req_Length) && first_two_bytes_string.ToUpper().Equals(DigicareUtilityRequests.DISCONNECT_REQ_HeaderPrimitive))
                                    {
                                        LogWriter.WriteToLog(string.Format(@"Received DISCONNECT_REQ ({0} bytes)!", noOfBytesReceived), LogHelperUtility.GetLogFileNameForListener(DeviceIdentifier.DigiCare, startSurgeryMonitor.monitorId.ToString()));
                                        LogWriter.WriteToLog(full_request_hex, LogHelperUtility.GetLogFileNameForListener(DeviceIdentifier.DigiCare, startSurgeryMonitor.monitorId.ToString()));

                                        networkStream.Close();
                                        networkStream.Dispose();
                                        client.Client.Close();
                                        client.Close();

                                        LogWriter.WriteToLog("Client disconnected!", LogHelperUtility.GetLogFileNameForListener(DeviceIdentifier.DigiCare,
                                                                                                            startSurgeryMonitor.monitorId.ToString()));
                                        LogWriter.WriteToFile("Client disconnected!", LogHelperUtility.GetLogFileNameForCommonTraceing(DeviceIdentifier.DigiCare,
                                                                                                            startSurgeryMonitor.monitorId.ToString()));
                                        doesListen = false;
                                    }
                                }
                            }
                            catch
                            {
                                //No need to log this exeception
                                ////Additional logging, Feb 2017
                                //LogWriter.WriteToFile(ex.ToString(), LogHelperUtility.GetLogFileNameForCommonTraceing(DeviceIdentifier.DigiCare,
                                //                                               startSurgeryMonitor.monitorId.ToString()));
                            }
                        }
                        #endregion innerloop
                    }
                }
            }
            catch (Exception ex)
            {
                //Additional logging, Feb 2017
                LogWriter.WriteToFile(ex.ToString(), LogHelperUtility.GetLogFileNameForCommonTraceing(DeviceIdentifier.DigiCare,
                                                                               monitorId));
            }
        }
        /// <summary>
        /// Process the packet.
        /// </summary>
        /// <param name="bytes"></param>
        /// <param name="identifier"></param>
        /// <param name="startSurgeryMonitor"></param>
        private static void ProcessPackets(byte[] bytes, DigicarePacketsComboIdentifier identifier, StartSurgeryMonitor startSurgeryMonitor)
        {
            try
            {
                Dictionary<string, byte[]> slicedPackets = null;
                slicedPackets = DigicareUtilityPacketsSlicer.SlicePackets(bytes, identifier);

                if (slicedPackets != null && slicedPackets.Count > 0)
                {
                    foreach (KeyValuePair<string, byte[]> pair in slicedPackets)
                    {
                        string hex = GeneralMethodsUtility.ConvertBytesArrayIntoHexadecimal(pair.Value, pair.Value.Length, true);
                        LogWriter.WriteToLog(string.Format(@"Received {1} packet ({0} bytes)!", pair.Value.Length, pair.Key),
                                                    LogHelperUtility.GetLogFileNameForListener(DeviceIdentifier.DigiCare, startSurgeryMonitor.monitorId.ToString()));
                        LogWriter.WriteToLog(hex, LogHelperUtility.GetLogFileNameForListener(DeviceIdentifier.DigiCare, startSurgeryMonitor.monitorId.ToString()));
                        ParsePacket(pair, startSurgeryMonitor);
                    }
                }
            }
            catch (Exception ex)
            {
                LogWriter.WriteToFile(ex.ToString(), LogHelperUtility.GetLogFileNameForCommonTraceing(DeviceIdentifier.DigiCare,
                                                                                startSurgeryMonitor.monitorId.ToString()));
            }
        }
        /// <summary>
        /// Parse the packet.
        /// </summary>
        /// <param name="pair"></param>
        /// <param name="startSurgeryMonitor"></param>
        private static void ParsePacket(KeyValuePair<string, byte[]> pair, StartSurgeryMonitor startSurgeryMonitor)
        {
            try
            {
                if (pair.Key.Equals(DigicareUtilityPacketNames.INFO_ADMIT))
                {
                    Dictionary<string, string> parsedData = DigicareInformationPacketsParser.Parse_USER_INFO(pair.Value);
                    LogWriter.WriteToLog(string.Format(@"Parsed {0} data!", pair.Key), LogHelperUtility.GetLogFileNameForListener(DeviceIdentifier.DigiCare, startSurgeryMonitor.monitorId.ToString()));
                    LogWriter.WriteToLiveFile("\t" + GeneralMethodsUtility.ConvertParsedPacketToString(parsedData, ':'),
                                                LogHelperUtility.GetLogFileNameForListener(DeviceIdentifier.DigiCare, startSurgeryMonitor.monitorId.ToString()));

                }
                //-------------Added to parse Unit Information packet to extract tempertaure unit-----------------------
                //----------- To identify tempertaure setting on monitor is either 'Celsius' or 'Fahrenheit'------------ 
                if (pair.Key.Equals(DigicareUtilityPacketNames.INFO_UNITS))
                {
                    Dictionary<string, string> parsedData = DigicareInformationPacketsParser.Parse_UNIT_INFO(pair.Value);
                    LogWriter.WriteToLog(string.Format(@"Parsed {0} data!", pair.Key), LogHelperUtility.GetLogFileNameForListener(DeviceIdentifier.DigiCare, startSurgeryMonitor.monitorId.ToString()));
                    LogWriter.WriteToLiveFile("\t" + GeneralMethodsUtility.ConvertParsedPacketToString(parsedData, ':'),
                                                LogHelperUtility.GetLogFileNameForListener(DeviceIdentifier.DigiCare, startSurgeryMonitor.monitorId.ToString()));

                    //Record temperature unit that is set on monitor to file.
                    SettingsUtility.SetMonitorTemperatureUnitSetting(parsedData["temp1_unit"], DeviceIdentifier.DigiCare,
                                                            startSurgeryMonitor.monitorId.ToString());
                }
                if (pair.Key.Equals(DigicareUtilityPacketNames.DATA_OBSERVATION))
                {
                    Dictionary<string, string> parsedData = DigicareDataPacketParser.Parse_OBSERVATION_DATA(pair.Value);
                    LogWriter.WriteToLog(string.Format(@"Parsed {0} data!", pair.Key),
                                            LogHelperUtility.GetLogFileNameForListener(DeviceIdentifier.DigiCare, startSurgeryMonitor.monitorId.ToString()));
                    LogWriter.WriteToLog("\t" + GeneralMethodsUtility.ConvertParsedPacketToString(parsedData, ':'),
                                            LogHelperUtility.GetLogFileNameForListener(DeviceIdentifier.DigiCare, startSurgeryMonitor.monitorId.ToString()));
                    LogWriter.WriteToLiveFile("\t" + GeneralMethodsUtility.ConvertParsedPacketToString(parsedData, ':', '|'),
                                            LogHelperUtility.GetLogFileNameForCommonLiveData(DeviceIdentifier.DigiCare, startSurgeryMonitor.monitorId.ToString()));
                }
            }
            catch (Exception ex)
            {
                LogWriter.WriteToFile(ex.ToString(), LogHelperUtility.GetLogFileNameForCommonTraceing(DeviceIdentifier.DigiCare,
                                                                                startSurgeryMonitor.monitorId.ToString()));
            }
        }
        /// <summary>
        /// Start data transfer handler for data transfer thread.
        /// </summary>
        /// <param name="obj"></param>
        private static void StartDataTransfer(object obj)
        {
            StartSurgeryMonitor startSurgeryMonitor = null;
            try
            {
                if (obj != null)
                {
                    //Note: This object can not be disposed, if it is disposed application will break.
                    System.Timers.Timer timerDataTransfer = new System.Timers.Timer();
                    startSurgeryMonitor = (StartSurgeryMonitor)obj;

                    LogWriter.WriteToFile(string.Format("<SDT-1> StartDataTransfer method called. | SurgeryStartDate : {0} | Frequency : {1}  | CurrentTime : {2}"
                                            , startSurgeryMonitor.surgeryStartDate.ToString()
                                            , startSurgeryMonitor.surgeryIntervalFrequency.ToString()
                                            , DateTime.Now.ToString())
                                            , LogHelperUtility.GetLogFileNameForCommonTraceing(DeviceIdentifier.DigiCare,
                                                                                startSurgeryMonitor.monitorId.ToString()));
                    //Calculate the next schedule
                    DateTime nextSchedule = TimeIntervalUtility.GetNextSchedule(startSurgeryMonitor.surgeryStartDate, startSurgeryMonitor.surgeryIntervalFrequency);
                    double interval = TimeIntervalUtility.GetCurrentIntervalInMilliseconds(nextSchedule);

                    LogWriter.WriteToFile(string.Format("<SDT-2> Very first data transfer schedule : {0} | Starting timer at: {1} | Interval(Calculated): {2}", nextSchedule, DateTime.Now.ToString(), interval.ToString()),
                                            LogHelperUtility.GetLogFileNameForCommonTraceing(DeviceIdentifier.DigiCare,
                                                                            startSurgeryMonitor.monitorId.ToString()));
                    if (interval.Equals(0)) interval = 100;

                    //Handle data transfer elapsed event
                    timerDataTransfer.Elapsed += (sender, e) => OnDataTransferElapsed(sender, e, startSurgeryMonitor);
                    timerDataTransfer.Interval = Convert.ToInt32(interval);
                    timerDataTransfer.Enabled = true;
                    timerDataTransfer.Start();
                    DigiCareMultiSupportDTO.DigiCareConnectedClientDataTransferThreadTimers.Add(startSurgeryMonitor.monitorId, timerDataTransfer);

                    LogWriter.WriteToFile(string.Format("<SDT-3.1> Timer started at : {0} | InitiateDataTransfer method called.", DateTime.Now.ToString()),
                                            LogHelperUtility.GetLogFileNameForCommonTraceing(DeviceIdentifier.DigiCare,
                                                                            startSurgeryMonitor.monitorId.ToString()));

                    HttpStatusCode statusCode = HttpStatusCode.Unused;
                    bool b = false;
                    try
                    {
                        statusCode = DataTransferUtility.InitiateDataTransfer(startSurgeryMonitor, CommonDataSettingTypes.LiveDataFile_Folder,
                                                                          DeviceIdentifier.DigiCare,
                                                                          startSurgeryMonitor.monitorId.ToString(),
                                                                          SerializedObjects.SurgeryApiKey);
                        b = !b;
                    }
                    catch (Exception ex)
                    {
                        LogWriter.WriteToFile("<SDT-3.1.1> Could not post the anesthetic values. Trying again in 10 seconds. " + ex.Message
                                        , LogHelperUtility.GetLogFileNameForCommonTraceing(DeviceIdentifier.DigiCare
                                        , startSurgeryMonitor.monitorId.ToString()));
                    }
                    if (!b)
                    {
                        try
                        {
                            Thread.Sleep(10 * 1000);
                            LogWriter.WriteToFile("<SDT-3.1.2> Trying to post the anesthetic values agin after 10 seconds."
                                            , LogHelperUtility.GetLogFileNameForCommonTraceing(DeviceIdentifier.DigiCare
                                            , startSurgeryMonitor.monitorId.ToString()));
                            statusCode = DataTransferUtility.InitiateDataTransfer(startSurgeryMonitor, CommonDataSettingTypes.LiveDataFile_Folder,
                                                                              DeviceIdentifier.DigiCare,
                                                                              startSurgeryMonitor.monitorId.ToString(),
                                                                              SerializedObjects.SurgeryApiKey);
                        }
                        catch (Exception ex)
                        {
                            LogWriter.WriteToFile("<SDT-3.1.3> Could not post the anesthetic values. Trying again in 10 seconds. " + ex.Message
                                            , LogHelperUtility.GetLogFileNameForCommonTraceing(DeviceIdentifier.DigiCare
                                            , startSurgeryMonitor.monitorId.ToString()));
                        }
                    }

                    LogWriter.WriteToFile(string.Format("<SDT-3.2> InitiateDataTransfer method ended at : {0}", DateTime.Now.ToString()),
                                            LogHelperUtility.GetLogFileNameForCommonTraceing(DeviceIdentifier.DigiCare,
                                                                            startSurgeryMonitor.monitorId.ToString()));

                    if (SerializedObjects.SaveMonitorToStopBasedOnStatusCode(startSurgeryMonitor, statusCode, DeviceIdentifier.DigiCare))
                    {

                        string msgSaveMonitor = "<SDT-4> Saved Monitor Id : " + startSurgeryMonitor.monitorId.ToString()
                                                 + " StatusCode : " + statusCode.ToString()
                                                 + " Set From : First data transfer.";

                        LogWriter.WriteToFile(msgSaveMonitor, LogHelperUtility.GetLogFileNameForCommonTraceing(DeviceIdentifier.DigiCare,
                                                                                startSurgeryMonitor.monitorId.ToString()));
                    }

                    string msg = string.Empty;
                    if (statusCode.Equals(HttpStatusCode.Created) || statusCode.Equals(HttpStatusCode.OK))
                    {
                        msg = string.Format("<SDT-5> First dataset sent, anesthetic values posted at : {0}", DateTime.Now.ToString());
                    }
                    else
                    {
                        //#Evg.15 - Internet connection failure (between Listener and SFS Server) or Anesthetic values could not be posted
                        //Action: Listener will not post anesthetic values to SFS server. 
                        //Action: Listener logs the error message locally. (Logging error in catch block)
                        msg = string.Format("<SDT-5> First dataset sent, anesthetic values could not be posted at : {0}", DateTime.Now.ToString());
                    }
                    LogWriter.WriteToFile(msg, LogHelperUtility.GetLogFileNameForCommonTraceing(DeviceIdentifier.DigiCare,
                                                                            startSurgeryMonitor.monitorId.ToString()));

                    //Just ping the monitor here without any timer
                    string pingStatus = "<SDT-6.1> PingMonitor method called at : " + DateTime.Now.ToString();
                    PingMonitor(startSurgeryMonitor);
                    pingStatus += Environment.NewLine + "<SDT-6.2> PingMonitor method ended at : " + DateTime.Now.ToString();
                    LogWriter.WriteToFile(pingStatus, LogHelperUtility.GetLogFileNameForCommonTraceing(DeviceIdentifier.DigiCare
                                                        , startSurgeryMonitor.monitorId.ToString()));
                }
                else
                {
                    //Additional logging, Feb 2017
                    LogWriter.WriteToFile("<SDT-7> StartDataTransfer argument is null.", LogHelperUtility.GetErrorFileNameForAdminApp());
                }

                LogWriter.WriteToFile("<SDT-8> StartDataTransfer method ended at : " + DateTime.Now.ToString()
                                        , LogHelperUtility.GetLogFileNameForCommonTraceing(DeviceIdentifier.DigiCare
                                        , startSurgeryMonitor.monitorId.ToString()));
            }
            catch (Exception ex)
            {
                //Additional logging, Feb 2017
                LogWriter.WriteToFile(DeviceIdentifier.DigiCare.ToString() + " : " + ex.ToString(), LogHelperUtility.GetErrorFileNameForAdminApp());
            }
        }
        /// <summary>
        /// Data transfer elapsed handler of the data transfer timer.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// <param name="startSurgeryMonitor"></param>
        private static void OnDataTransferElapsed(object sender, ElapsedEventArgs e, StartSurgeryMonitor startSurgeryMonitor)
        {
            try
            {
                //Additional logging, Feb 2017
                LogWriter.WriteToFile("<ODTE-1> OnDataTransferElapsed event started at : " + DateTime.Now.ToString() + " | SignalTime : " + e.SignalTime.ToString(),
                    LogHelperUtility.GetLogFileNameForCommonTraceing(DeviceIdentifier.DigiCare, startSurgeryMonitor.monitorId.ToString()));

                //Just ping the monitor here without any timer
                string pingStatus = "<ODTE-2.1> PingMonitor method called at : " + DateTime.Now.ToString();
                PingMonitor(startSurgeryMonitor);
                pingStatus += Environment.NewLine + "<ODTE-2.2> PingMonitor method ended at : " + DateTime.Now.ToString();
                LogWriter.WriteToFile(pingStatus, LogHelperUtility.GetLogFileNameForCommonTraceing(DeviceIdentifier.DigiCare
                                                    , startSurgeryMonitor.monitorId.ToString()));

                System.Timers.Timer timerDataTransfer = (System.Timers.Timer)sender;

                int numberOfIntervalSet = 0;

                if (numberOfIntervalSet.Equals(0))
                {
                    if (startSurgeryMonitor.surgeryIntervalFrequency > 0)
                    {
                        double frequencyInSeconds = 0;
                        double.TryParse((startSurgeryMonitor.surgeryIntervalFrequency).ToString(), out frequencyInSeconds);
                        double.TryParse((frequencyInSeconds).ToString(), out frequencyInSeconds);

                        int freqMinutes = Convert.ToInt16(frequencyInSeconds / 60.0);

                        DateTime onspotTime = DateTime.Now;
                        DateTime repeatitiveSchedule = onspotTime.AddMinutes(freqMinutes);
                        DateTime repeatitiveScheduleRounded = DateTime.Parse(String.Format("{0:g}", repeatitiveSchedule));

                        //Add 10 seconds more to avoid lag in elapsing the event
                        repeatitiveScheduleRounded = repeatitiveScheduleRounded.AddSeconds(5);//May be 10 seconds
                        string txt = "<ODTE-3> On spot time : " + onspotTime.ToString() + " | Next continuous data transfer schedule : " + repeatitiveScheduleRounded.ToString();

                        double intervalMilliseconds = TimeIntervalUtility.GetCurrentIntervalInMilliseconds(repeatitiveScheduleRounded);

                        timerDataTransfer.Interval = Convert.ToInt32(intervalMilliseconds);
                        timerDataTransfer.Enabled = true;

                        txt += " | Timer interval updated.";

                        LogWriter.WriteToFile(txt, LogHelperUtility.GetLogFileNameForCommonTraceing(DeviceIdentifier.DigiCare,
                                                                                    startSurgeryMonitor.monitorId.ToString()));
                        numberOfIntervalSet++;
                    }
                }

                LogWriter.WriteToFile(string.Format("<ODTE-4.1> InitiateDataTransfer method started at : {0}", DateTime.Now.ToString()),
                                        LogHelperUtility.GetLogFileNameForCommonTraceing(DeviceIdentifier.DigiCare,
                                                                        startSurgeryMonitor.monitorId.ToString()));
                HttpStatusCode statusCode = DataTransferUtility.InitiateDataTransfer(startSurgeryMonitor,
                                                                CommonDataSettingTypes.LiveDataFile_Folder,
                                                                DeviceIdentifier.DigiCare,
                                                                startSurgeryMonitor.monitorId.ToString(),
                                                                SerializedObjects.SurgeryApiKey);


                LogWriter.WriteToFile(string.Format("<ODTE-4.2> InitiateDataTransfer method ended at : {0}", DateTime.Now.ToString()),
                                        LogHelperUtility.GetLogFileNameForCommonTraceing(DeviceIdentifier.DigiCare,
                                                                        startSurgeryMonitor.monitorId.ToString()));

                if (SerializedObjects.SaveMonitorToStopBasedOnStatusCode(startSurgeryMonitor, statusCode, DeviceIdentifier.DigiCare))
                {

                    string msgSaveMonitor = "<ODTE-5> Saved Monitor Id : " + startSurgeryMonitor.monitorId.ToString() + " StatusCode : " + statusCode.ToString() + " Set From : on elapsed data transfer";

                    LogWriter.WriteToFile(msgSaveMonitor, LogHelperUtility.GetLogFileNameForCommonTraceing(DeviceIdentifier.DigiCare,
                                                                            startSurgeryMonitor.monitorId.ToString()));
                }

                string msg = string.Empty;
                if (statusCode.Equals(HttpStatusCode.Created) || statusCode.Equals(HttpStatusCode.OK))
                {
                    msg = string.Format("<ODTE-6> DataTransfer executed, anesthetic values posted at (SignalTime) : {0}", e.SignalTime.ToString());
                }
                else
                {
                    //#Evg.15 - Internet connection failure (between Listener and SFS Server) or Anesthetic values could not be posted
                    //Action: Listener will not post anesthetic values to SFS server. 
                    //Action: Listener logs the error message locally. (Logging error in catch block)
                    msg = string.Format("<ODTE-6> DataTransfer executed, anesthetic values could not be posted at (SignalTime) : {0}", e.SignalTime.ToString());
                }

                msg += Environment.NewLine + "<ODTE-7> OnDataTransferElapsed event ended at : " + DateTime.Now.ToString();

                LogWriter.WriteToFile(msg, LogHelperUtility.GetLogFileNameForCommonTraceing(DeviceIdentifier.DigiCare,
                                                                        startSurgeryMonitor.monitorId.ToString()));
            }
            catch (Exception ex)
            {
                LogWriter.WriteToFile(ex.ToString(), LogHelperUtility.GetLogFileNameForCommonTraceing(DeviceIdentifier.DigiCare,
                                                                                            startSurgeryMonitor.monitorId.ToString()));
            }
        }
        public static void PostAnestheticValuesOnDemand(StartSurgeryMonitor startSurgeryMonitor)
        {
            try
            {
                if (startSurgeryMonitor != null)
                {
                    //Just ping the monitor here without any timer
                    string pingStatus = "<ODAVP-1> PingMonitor method called at : " + DateTime.Now.ToString();
                    PingMonitor(startSurgeryMonitor);
                    pingStatus += Environment.NewLine + "<ODAVP-2> PingMonitor method ended at : " + DateTime.Now.ToString();

                    LogWriter.WriteToFile(pingStatus, LogHelperUtility.GetLogFileNameForCommonTraceing(DeviceIdentifier.DigiCare
                                                        , startSurgeryMonitor.monitorId.ToString()));

                    HttpStatusCode statusCode = DataTransferUtility.InitiateDataTransfer(startSurgeryMonitor, CommonDataSettingTypes.LiveDataFile_Folder,
                                                                    DeviceIdentifier.DigiCare,
                                                                    startSurgeryMonitor.monitorId.ToString(),
                                                                    SerializedObjects.SurgeryApiKey);

                    if (SerializedObjects.SaveMonitorToStopBasedOnStatusCode(startSurgeryMonitor, statusCode, DeviceIdentifier.DigiCare))
                    {

                        string msgSaveMonitor = "<ODAVP-3> Saved Monitor Id: " + startSurgeryMonitor.monitorId.ToString() + " StatusCode: " + statusCode.ToString() + " Set From : on demand data transfer";

                        LogWriter.WriteToFile(msgSaveMonitor, LogHelperUtility.GetLogFileNameForCommonTraceing(DeviceIdentifier.DigiCare,
                                                                                startSurgeryMonitor.monitorId.ToString()));
                    }

                    string msg = string.Empty;
                    if (statusCode.Equals(HttpStatusCode.Created) || statusCode.Equals(HttpStatusCode.OK))
                    {
                        msg = string.Format("<ODAVP-4> On demand anesthetic values posted at : {0}", DateTime.Now.ToString());
                    }
                    else
                    {
                        //#Evg.15 - Internet connection failure (between Listener and SFS Server) or Anesthetic values could not be posted
                        //Action: Listener will not post anesthetic values to SFS server. 
                        //Action: Listener logs the error message locally. (Logging error in catch block)
                        msg = string.Format("<ODAVP-5> On demand anesthetic values could not be posted at : {0}", DateTime.Now.ToString());
                    }
                    LogWriter.WriteToFile(msg, LogHelperUtility.GetLogFileNameForCommonTraceing(DeviceIdentifier.DigiCare,
                                                                            startSurgeryMonitor.monitorId.ToString()));

                }
            }
            catch (Exception ex)
            {
                LogWriter.WriteToFile(ex.ToString(), LogHelperUtility.GetLogFileNameForCommonTraceing(DeviceIdentifier.DigiCare,
                                                                            startSurgeryMonitor.monitorId.ToString()));
            }
        }
        /// <summary>
        /// Method to ping the device at the frequency of posting the anesthetic values.
        /// </summary>
        /// <param name="startSurgeryMonitor"></param>
        /// <CreatedBy>Om Shakya</CreatedBy>
        /// <CreatedDate>Dec 2016</CreatedDate>
        /// <ModifyBy>...</ModifyBy>
        /// <ModifyDate>...</ModifyDate>
        private static void PingMonitor(StartSurgeryMonitor startSurgeryMonitor)
        {
            try
            {
                ObjectSerializer.SurgeryMonitor monitor = SerializedObjects.GetSurgeryMonitorDevice(startSurgeryMonitor.monitorId);
                if (monitor != null)
                {
                    bool isPinged = false;
                    PingDeviceHelper.PingMonitorPostSurgeryMonitorStatus(startSurgeryMonitor.monitorId, DeviceIdentifier.DigiCare, out isPinged);

                    string msgMonitorPingStatus = string.Empty;
                    SurgeryMonitorStatus.Status status = SurgeryMonitorStatus.Status.ConnectionToMonitorFailed;

                    if (isPinged)
                    {
                        msgMonitorPingStatus = CommonMessages.MonitorConnectedSuccessfully;
                        status = SurgeryMonitorStatus.Status.Active;
                    }
                    else
                    {
                        msgMonitorPingStatus = CommonMessages.MonitorConnectionFailedMsg;
                        status = SurgeryMonitorStatus.Status.ConnectionToMonitorFailed;

                        if (SerializedObjects.SaveMonitorToStopBasedOnStatusCode(startSurgeryMonitor, HttpStatusCode.NotFound, DeviceIdentifier.DigiCare))
                        {

                            string msgSaveMonitor = "<PingMonitor-0> Saved Monitor Id : " + startSurgeryMonitor.monitorId.ToString() + " StatusCode : " + "Could not ping" + " Set From : PingMonitor method.";

                            LogWriter.WriteToFile(msgSaveMonitor, LogHelperUtility.GetLogFileNameForCommonTraceing(DeviceIdentifier.DigiCare,
                                                                                    startSurgeryMonitor.monitorId.ToString()));
                        }
                    }

                    SurgeryMonitorStatusHelper.PostSurgeryMonitorStatusWithLogInListenerTrace(
                                                                        startSurgeryMonitor.monitorId
                                                                        , msgMonitorPingStatus
                                                                        , DeviceIdentifier.DigiCare
                                                                        , status);

                    //Adds log message
                    LogWriter.WriteToFile("<PingMonitor-1> Ping status: " + isPinged.ToString() + " message: " + msgMonitorPingStatus
                                            , LogHelperUtility.GetLogFileNameForCommonTraceing(DeviceIdentifier.DigiCare
                                            , startSurgeryMonitor.monitorId.ToString()));

                }
                else
                {
                    LogWriter.WriteToFile("<PingMonitor-2> Ping Monitor - Monitor could not be retrived to ping.",
                                            LogHelperUtility.GetLogFileNameForCommonTraceing(DeviceIdentifier.DigiCare, startSurgeryMonitor.monitorId.ToString()));
                }
            }
            catch (Exception ex)
            {
                LogWriter.WriteToFile("<PingMonitor-3> Ping Monitor - Exception : " + ex.ToString(),
                                        LogHelperUtility.GetLogFileNameForCommonTraceing(DeviceIdentifier.DigiCare, startSurgeryMonitor.monitorId.ToString()));
            }
        }
    }
}
