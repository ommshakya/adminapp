﻿using SFS.CommonUtilities;
using System.Collections.Generic;

namespace SFS.Listener.BioNet.BioNetUtility
{
    /// <summary>
    /// BioNet Utility Packets Slicer class.
    /// </summary>
    /// <CreatedBy>Om Shakya</CreatedBy>
    /// <CreatedDate>Sep 2015</CreatedDate>
    /// <ModifyBy>...</ModifyBy>
    /// <ModifyDate>...</ModifyDate>
    public static class BioNetUtilityPacketsSlicer
    {
        /// <summary>
        /// Method to Slice Packets into individual packets.
        /// </summary>
        /// <param name="bytes"></param>
        /// <param name="identifier"></param>
        /// <returns></returns>
        /// <CreatedBy>Om Shakya</CreatedBy>
        /// <CreatedDate>Sep 2015</CreatedDate>
        /// <ModifyBy>...</ModifyBy>
        /// <ModifyDate>...</ModifyDate>
        public static Dictionary<string, byte[]> SlicePackets(byte[] bytes, BioNetPacketsComboIdentifier identifier)
        {
            Dictionary<string, byte[]> slices = new Dictionary<string, byte[]>();
            try
            {
                if (bytes != null)
                {
                    switch (identifier)
                    {
                        case BioNetPacketsComboIdentifier.SETTING_PARAM_PacketsCombo:
                            slices.Add(BioNetUtilityPacketNames.SETTING_INFO,
                                        GeneralMethodsUtility.ExtractBytes(bytes, 0
                                                                                , BioNetUtilityInformationPackets.Setting_Info_Length));
                            slices.Add(BioNetUtilityPacketNames.PARAMETER_DATA,
                                        GeneralMethodsUtility.ExtractBytes(bytes, BioNetUtilityInformationPackets.Setting_Info_Length
                                                                                , BioNetUtilityDataPackets.Parameter_Data_Length));
                            break;

                        case BioNetPacketsComboIdentifier.USER_ADMIT_ALARM_SETTING_PacketsCombo:
                            slices.Add(BioNetUtilityPacketNames.USER_INFO,
                                        GeneralMethodsUtility.ExtractBytes(bytes, 0
                                                                                , BioNetUtilityInformationPackets.User_Info_Length));
                            slices.Add(BioNetUtilityPacketNames.ADMIT_INFO,
                                        GeneralMethodsUtility.ExtractBytes(bytes, BioNetUtilityInformationPackets.User_Info_Length
                                                                                , BioNetUtilityInformationPackets.Admit_Info_Length));
                            slices.Add(BioNetUtilityPacketNames.ALARM_INFO,
                                        GeneralMethodsUtility.ExtractBytes(bytes, BioNetUtilityInformationPackets.User_Info_Length
                                                                                + BioNetUtilityInformationPackets.Admit_Info_Length
                                                                                , BioNetUtilityInformationPackets.Alarm_Info_Length));
                            slices.Add(BioNetUtilityPacketNames.SETTING_INFO,
                                        GeneralMethodsUtility.ExtractBytes(bytes, BioNetUtilityInformationPackets.User_Info_Length
                                                                                + BioNetUtilityInformationPackets.Admit_Info_Length
                                                                                + BioNetUtilityInformationPackets.Alarm_Info_Length
                                                                                , BioNetUtilityInformationPackets.Setting_Info_Length));
                            break;
                    }
                }
                return slices;
            }
            catch
            {
                throw;
            }
        }
    }
}
