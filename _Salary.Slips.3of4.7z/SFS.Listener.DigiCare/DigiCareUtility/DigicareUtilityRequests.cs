﻿namespace SFS.Listener.DigiCare.DigiCareUtility
{
    /// <summary>
    /// Digicare Utility Requests class.
    /// </summary>
    /// <CreatedBy>Om Shakya</CreatedBy>
    /// <CreatedDate>Sep 2015</CreatedDate>
    /// <ModifyBy>...</ModifyBy>
    /// <ModifyDate>...</ModifyDate>
    public static class DigicareUtilityRequests
    {
        /// <summary>
        /// Get CONNECT_REQ_HeaderPrimitive.
        /// </summary>
        public static string CONNECT_REQ_HeaderPrimitive
        {
            get
            {
                return string.Concat(DigicareUtilityHeaders.REQ_CONNECT_Header, DigicareUtilityPrimitives.REQ_CONNECT_Primitive);
            }
        }
        /// <summary>
        /// Get CONNECT_ACCEPT_HeaderPrimitive.
        /// </summary>
        public static string CONNECT_ACCEPT_HeaderPrimitive
        {
            get
            {
                return string.Concat(DigicareUtilityHeaders.REQ_ACCEPT_Header, DigicareUtilityPrimitives.REQ_ACCEPT_Primitive);
            }
        }
        /// <summary>
        /// Get DISCONNECT_REQ_HeaderPrimitive.
        /// </summary>
        public static string DISCONNECT_REQ_HeaderPrimitive
        {
            get
            {
                return string.Concat(DigicareUtilityHeaders.REQ_DISCONNECT_Header, DigicareUtilityPrimitives.REQ_DISCONNECT_Primitive);
            }
        }
        /// <summary>
        /// Get DATA_ACK_HeaderPrimitive.
        /// </summary>
        public static string DATA_ACK_HeaderPrimitive
        {
            get
            {
                return string.Concat(DigicareUtilityHeaders.DATA_ACK_Header, DigicareUtilityPrimitives.DATA_ACK_Primitive);
            }
        }
    }
}
