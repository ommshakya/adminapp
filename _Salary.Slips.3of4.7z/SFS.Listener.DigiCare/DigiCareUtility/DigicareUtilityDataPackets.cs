﻿using SFS.ConfigManager;
using System;

namespace SFS.Listener.DigiCare.DigiCareUtility
{
    /// <summary>
    /// Digicare Utility DataPackets Class.
    /// </summary>
    /// <CreatedBy>Om Shakya</CreatedBy>
    /// <CreatedDate>Sep 2015</CreatedDate>
    /// <ModifyBy>...</ModifyBy>
    /// <ModifyDate>...</ModifyDate>
    public static class DigicareUtilityDataPackets
    {
        /// <summary>
        /// Get Data_Observation_Length.
        /// </summary>
        /// <CreatedDate>Aug 2016</CreatedDate>
        /// <ModifyBy>...</ModifyBy>
        /// <ModifyDate>...</ModifyDate>
        public static int Data_Observation_Length
        {
            get { return AppConfigurations.Digicare_Observation_Data_Length; }
        }
        /// <summary>
        /// Get Data_Ack_Length.
        /// </summary>
        /// <CreatedDate>Aug 2016</CreatedDate>
        /// <ModifyBy>...</ModifyBy>
        /// <ModifyDate>...</ModifyDate>
        public static int Data_Ack_Length
        {
            get { return AppConfigurations.Digicare_Data_Ack_Length; }
        }
        /// <summary>
        /// Method DATA_ACK.
        /// </summary>
        /// <param name="bedNum"></param>
        /// <returns></returns>
        /// <CreatedDate>Aug 2016</CreatedDate>
        /// <ModifyBy>...</ModifyBy>
        /// <ModifyDate>...</ModifyDate>
        public static byte[] DATA_ACK(ushort bedNum)
        {
            byte[] bytes = null;
            try
            {
                bytes = new byte[Data_Ack_Length];
                bytes[0] = 0xD2;
                bytes[1] = 0x01;
                bytes[2] = (byte)bedNum;
                return bytes;
            }
            catch
            {
                throw;
            }
        }
        /// <summary>
        /// Method DATA_OBSERVATION.
        /// </summary>
        /// <returns></returns>
        /// <CreatedDate>Aug 2016</CreatedDate>
        /// <ModifyBy>...</ModifyBy>
        /// <ModifyDate>...</ModifyDate>
        public static byte[] DATA_OBSERVATION()
        {
            byte[] bytes_Parameter_Data = null;
            try
            {
                bytes_Parameter_Data = new byte[Data_Observation_Length];
                bytes_Parameter_Data[0] = 0xD1;

                bool isLittleEndian = BitConverter.IsLittleEndian;

                UInt16 ecgHR = AppConfigurations.Simulator_Value_HR;
                byte[] bytes_ecgHR = BitConverter.GetBytes(ecgHR);
                if (isLittleEndian)
                    Array.Reverse(bytes_ecgHR);
                bytes_ecgHR.CopyTo(bytes_Parameter_Data, 1);

                byte sop2sat = AppConfigurations.Simulator_Value_SPO2;
                bytes_Parameter_Data[3] = sop2sat;

                UInt16 spo2pulse = 180;
                byte[] bytes_spo2pulse = BitConverter.GetBytes(spo2pulse);
                if (isLittleEndian)
                    Array.Reverse(bytes_spo2pulse);
                bytes_spo2pulse.CopyTo(bytes_Parameter_Data, 4);

                UInt16 Systolic_BP = AppConfigurations.Simulator_Value_SBP;
                byte[] bytes_Systolic_BP = BitConverter.GetBytes(Systolic_BP);
                if (isLittleEndian)
                    Array.Reverse(bytes_Systolic_BP);
                bytes_Systolic_BP.CopyTo(bytes_Parameter_Data, 6);

                UInt16 DIA_BP = AppConfigurations.Simulator_Value_DBP;
                byte[] bytes_DIA_BP = BitConverter.GetBytes(DIA_BP);
                if (isLittleEndian)
                    Array.Reverse(bytes_DIA_BP);
                bytes_DIA_BP.CopyTo(bytes_Parameter_Data, 8);

                UInt16 Mean_BP = AppConfigurations.Simulator_Value_MAP;
                byte[] bytes_Mean_BP = BitConverter.GetBytes(Mean_BP);
                if (isLittleEndian)
                    Array.Reverse(bytes_Mean_BP);
                bytes_Mean_BP.CopyTo(bytes_Parameter_Data, 10);

                UInt16 nibp_pulse = 297;
                byte[] bytes_nibp_pulse = BitConverter.GetBytes(nibp_pulse);
                if (isLittleEndian)
                    Array.Reverse(bytes_nibp_pulse);
                bytes_nibp_pulse.CopyTo(bytes_Parameter_Data, 12);

                UInt16 ibp2_sys = 99;
                byte[] bytes_ibp2_sys = BitConverter.GetBytes(ibp2_sys);
                if (isLittleEndian)
                    Array.Reverse(bytes_ibp2_sys);
                bytes_ibp2_sys.CopyTo(bytes_Parameter_Data, 14);

                UInt16 ibp2_dia = 98;
                byte[] bytes_ibp2_dia = BitConverter.GetBytes(ibp2_dia);
                if (isLittleEndian)
                    Array.Reverse(bytes_ibp2_dia);
                bytes_ibp2_dia.CopyTo(bytes_Parameter_Data, 16);

                UInt16 ibp2_mean = 97;
                byte[] bytes_ibp2_mean = BitConverter.GetBytes(ibp2_mean);
                if (isLittleEndian)
                    Array.Reverse(bytes_ibp2_mean);
                bytes_ibp2_mean.CopyTo(bytes_Parameter_Data, 18);

                byte co2etco2 = AppConfigurations.Simulator_Value_ETCO2;
                bytes_Parameter_Data[20] = co2etco2;

                byte co2insco2 = AppConfigurations.Simulator_Value_ETCO2;
                bytes_Parameter_Data[21] = co2insco2;

                byte co2resp = AppConfigurations.Simulator_Value_RR;
                bytes_Parameter_Data[22] = co2resp;

                UInt16 temp1 = AppConfigurations.Simulator_Value_Temp;
                byte[] bytes_temp1 = BitConverter.GetBytes(temp1);
                if (isLittleEndian)
                    Array.Reverse(bytes_temp1);
                bytes_temp1.CopyTo(bytes_Parameter_Data, 23);

                UInt16 temp2 = AppConfigurations.Simulator_Value_Temp;
                byte[] bytes_temp2 = BitConverter.GetBytes(temp2);
                if (isLittleEndian)
                    Array.Reverse(bytes_temp2);
                bytes_temp2.CopyTo(bytes_Parameter_Data, 25);

                UInt16 tempdelta = AppConfigurations.Simulator_Value_Temp;
                byte[] bytes_tempdelta = BitConverter.GetBytes(tempdelta);
                if (isLittleEndian)
                    Array.Reverse(bytes_tempdelta);
                bytes_tempdelta.CopyTo(bytes_Parameter_Data, 27);

                byte fio2 = 99;
                bytes_Parameter_Data[29] = fio2;
                return bytes_Parameter_Data;
            }
            catch
            {
                throw;
            }
        }
    }
}
