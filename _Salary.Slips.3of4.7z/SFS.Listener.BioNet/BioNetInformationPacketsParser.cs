﻿using SFS.CommonUtilities;
using System.Collections.Generic;

namespace SFS.Listener.BioNet
{
    /// <summary>
    /// BioNet Information Packets Parser Class.
    /// </summary>
    /// <CreatedBy>Om Shakya</CreatedBy>
    /// <CreatedDate>Sep 2015</CreatedDate>
    /// <ModifyBy>...</ModifyBy>
    /// <ModifyDate>...</ModifyDate>
    public static class BioNetInformationPacketsParser
    {
        /// <summary>
        /// Method to Parse USER_INFO packet.
        /// </summary>
        /// <param name="bytes_USER_INFO"></param>
        /// <returns></returns>
        /// <CreatedBy>Om Shakya</CreatedBy>
        /// <CreatedDate>Sep 2015</CreatedDate>
        /// <ModifyBy>...</ModifyBy>
        /// <ModifyDate>...</ModifyDate>
        public static Dictionary<string, string> Parse_USER_INFO(byte[] bytes_USER_INFO)
        {
            try
            {
                Dictionary<string, string> parsed_USER_INFO = new Dictionary<string, string>();

                if (bytes_USER_INFO != null && bytes_USER_INFO.Length > 0)
                {
                    ushort bed_number = GeneralMethodsUtility.ConvertOneByteToUShort(bytes_USER_INFO[22]);
                    parsed_USER_INFO.Add("bed_number", bed_number.ToString());
                }
                return parsed_USER_INFO;
            }
            catch
            {
                throw;
            }
        }
    }
}
