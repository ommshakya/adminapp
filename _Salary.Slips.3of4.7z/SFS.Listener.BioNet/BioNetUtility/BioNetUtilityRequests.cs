﻿namespace SFS.Listener.BioNet.BioNetUtility
{
    /// <summary>
    /// BioNet Utility Requests class.
    /// </summary>
    /// <CreatedBy>Om Shakya</CreatedBy>
    /// <CreatedDate>Sep 2015</CreatedDate>
    /// <ModifyBy>...</ModifyBy>
    /// <ModifyDate>...</ModifyDate>
    public static class BioNetUtilityRequests
    {
        /// <summary>
        /// Get CONNECT_REQ_HeaderPrimitive, (It is combination of header and primitive as per Bionet protocol documentation).
        /// </summary>
        /// <CreatedBy>Om Shakya</CreatedBy>
        /// <CreatedDate>Sep 2015</CreatedDate>
        /// <ModifyBy>...</ModifyBy>
        /// <ModifyDate>...</ModifyDate>
        public static string CONNECT_REQ_HeaderPrimitive
        {
            get
            {
                return string.Concat(BioNetUtilityHeaders.CONNECT_REQ_Header, BioNetUtilityPrimitives.CONNECT_REQ_Primitive);
            }
        }
        /// <summary>
        /// Get CONNECT_ACCEPT_HeaderPrimitive, (It is combination of header and primitive as per Bionet protocol documentation).
        /// </summary>
        /// <CreatedBy>Om Shakya</CreatedBy>
        /// <CreatedDate>Sep 2015</CreatedDate>
        /// <ModifyBy>...</ModifyBy>
        /// <ModifyDate>...</ModifyDate>
        public static string CONNECT_ACCEPT_HeaderPrimitive
        {
            get
            {
                return string.Concat(BioNetUtilityHeaders.CONNECT_ACCEPT_Header, BioNetUtilityPrimitives.CONNECT_ACCEPT_Primitive);
            }
        }
        /// <summary>
        /// Get DISCONNECT_REQ_HeaderPrimitive, (It is combination of header and primitive as per Bionet protocol documentation).
        /// </summary>
        /// <CreatedBy>Om Shakya</CreatedBy>
        /// <CreatedDate>Sep 2015</CreatedDate>
        /// <ModifyBy>...</ModifyBy>
        /// <ModifyDate>...</ModifyDate>
        public static string DISCONNECT_REQ_HeaderPrimitive
        {
            get
            {
                return string.Concat(BioNetUtilityHeaders.DISCONNECT_REQ_Header, BioNetUtilityPrimitives.DISCONNECT_REQ_Primitive);
            }
        }
        /// <summary>
        /// Get DATA_ACK_HeaderPrimitive, (It is combination of header and primitive as per Bionet protocol documentation).
        /// </summary>
        /// <CreatedBy>Om Shakya</CreatedBy>
        /// <CreatedDate>Sep 2015</CreatedDate>
        /// <ModifyBy>...</ModifyBy>
        /// <ModifyDate>...</ModifyDate>
        public static string DATA_ACK_HeaderPrimitive
        {
            get
            {
                return string.Concat(BioNetUtilityHeaders.DATA_ACK_Header, BioNetUtilityPrimitives.DATA_ACK_Primitive);
            }
        }
    }
}
