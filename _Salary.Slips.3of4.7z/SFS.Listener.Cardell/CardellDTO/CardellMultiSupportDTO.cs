﻿using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Sockets;
using System.Threading;

namespace SFS.Listener.Cardell.CardellDTO
{

    public static class CardellMultiSupportDTO
    {
        /// <summary>
        /// Property to check whether Cardell listener is running or not.
        /// </summary>
        public static bool isCardellListenerRunning;
        /// <summary>
        /// Collection of Cardell connected clients/monitors.
        /// </summary>
        public static Dictionary<Guid, IPAddress> CardellConnectedClients;
        /// <summary>
        /// Collection of Cardell connected tcp clients.
        /// </summary>
        public static Dictionary<Guid, TcpClient> CardellConnectedClientTcpClient;
        /// <summary>
        /// Collection of Cardell data transfer threads of connected client/monitor.
        /// </summary>
        public static Dictionary<Guid, Thread> CardellConnectedClientDataTransferThreads;
        /// <summary>
        /// Collection of Cardell data transfer timers if thread of connected client/monitor.
        /// </summary>
        public static Dictionary<Guid, System.Timers.Timer> CardellConnectedClientDataTransferThreadTimers;
    }
}
