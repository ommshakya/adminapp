﻿
using SFS.CommonUtilities;
using SFS.CommonUtilities.Enums;
using SFS.ConfigManager;
using SFS.FileWritter;
using SFS.Helper;
using SFS.Listener.Vetland.VetlandDTO;
using SFS.Listener.Vetland.VetlandUtility;
using SFS.ObjectSerializer;
using smartflowsheet.surgery.api.model.events;
using smartflowsheet.surgery.api.model.objects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Timers;

namespace SFS.Listener.Vetland
{
    public static class VetlandServer
    {
        public static UdpClient udpListener = null;
        public static int veryFirstObservationDataCounter = 0;
        public static int numberOfIntervalSet = 0;
        public static List<Thread> listOfThreads = new List<Thread>();
        static string ip = string.Empty;
        static IPAddress monitorIP = null;
        static IPEndPoint serverIpEndPoint = null;
        static EndPoint serverEndPoint = null;
        static EndPoint RemoteEndPoint = null;
        static int portNo;
        static StartSurgeryMonitor startSurgeryMonitorObj = null;
        static bool doesListen;
        /// <summary>
        /// Stop Server method stops server process.
        /// </summary>
        /// <param name="stopSurgeryMonitor"></param>
        public static void StopServer(StopSurgeryMonitor stopSurgeryMonitor)
        {
            StringBuilder msg = new StringBuilder();
            try
            {
                //Handle Vetland Connected Client DataReceiveThread Timers
                if (VetlandMultiSupportDTO.VetlandConnectedClientDataReceiveThreadTimers != null)
                {
                    msg.AppendLine("VetlandConnectedClientDataReceiveThreadTimers count!" + VetlandMultiSupportDTO.VetlandConnectedClientDataReceiveThreadTimers.Count.ToString());

                    if (VetlandMultiSupportDTO.VetlandConnectedClientDataReceiveThreadTimers.ContainsKey(stopSurgeryMonitor.monitorId))
                    {
                        System.Timers.Timer timer = VetlandMultiSupportDTO.VetlandConnectedClientDataReceiveThreadTimers[stopSurgeryMonitor.monitorId];

                        if (timer != null)
                        {
                            timer.Stop();
                            timer.Dispose();
                            msg.AppendLine("VetlandConnectedClientDataReceiveThreadTimers stoped!");
                        }
                        VetlandMultiSupportDTO.VetlandConnectedClientDataReceiveThreadTimers.Remove(stopSurgeryMonitor.monitorId);
                        msg.AppendLine("VetlandConnectedClientDataReceiveThreadTimers removed!");
                    }
                }

            }
            catch (Exception ex)
            {
                msg.AppendLine("VetlandConnectedClientDataReceiveThreadTimers Exception: " + "(" + stopSurgeryMonitor.monitorId.ToString() + ")" + ex.ToString());
            }

            try
            {
                //Handle Vetland Connected Client TcpClient
                if (VetlandMultiSupportDTO.VetlandConnectedClientUdpClient != null)
                {
                    if (VetlandMultiSupportDTO.VetlandConnectedClientUdpClient.ContainsKey(stopSurgeryMonitor.monitorId))
                    {
                        UdpClient client = VetlandMultiSupportDTO.VetlandConnectedClientUdpClient[stopSurgeryMonitor.monitorId];

                        doesListen = false;
                        msg.AppendLine("Vetland connection request timer stoped!");

                        if (client != null && client.Client != null)
                        {
                            client.Client.Shutdown(SocketShutdown.Both);
                            client.Client.Close();
                            client.Close();
                            msg.AppendLine("VetlandConnectedClientUdpClient closed!");
                        }
                        VetlandMultiSupportDTO.VetlandConnectedClientUdpClient.Remove(stopSurgeryMonitor.monitorId);
                        msg.AppendLine("VetlandConnectedClientUdpClient removed!");
                    }
                }
            }
            catch (Exception ex)
            {
                msg.AppendLine("VetlandConnectedClientUdpClient Exception: " + ex.ToString());
            }

            try
            {
                //Handle Vetland Connected Clients
                if (VetlandMultiSupportDTO.VetlandConnectedClients != null)
                {
                    if (VetlandMultiSupportDTO.VetlandConnectedClients.ContainsKey(stopSurgeryMonitor.monitorId))/////
                    {
                        VetlandMultiSupportDTO.VetlandConnectedClients.Remove(stopSurgeryMonitor.monitorId);
                        msg.AppendLine("VetlandConnectedClients removed!");
                    }
                }
            }
            catch (Exception ex)
            {
                msg.AppendLine("VetlandConnectedClients Exception: " + ex.ToString());
            }
            try
            {
                //Handle Vetland Connected Client DataTransferThreads
                if (VetlandMultiSupportDTO.VetlandConnectedClientDataTransferThreads != null)
                {
                    if (VetlandMultiSupportDTO.VetlandConnectedClientDataTransferThreads.ContainsKey(stopSurgeryMonitor.monitorId))
                    {
                        Thread thread = VetlandMultiSupportDTO.VetlandConnectedClientDataTransferThreads[stopSurgeryMonitor.monitorId];

                        if (thread != null)
                        {
                            thread.Abort();
                            msg.AppendLine("VetlandConnectedClientDataTransferThreads aborted!");
                        }
                        VetlandMultiSupportDTO.VetlandConnectedClientDataTransferThreads.Remove(stopSurgeryMonitor.monitorId);
                        msg.AppendLine("VetlandConnectedClientDataTransferThreads removed!");
                    }
                }
            }
            catch (Exception ex)
            {
                msg.AppendLine("VetlandConnectedClientDataTransferThreads Exception: " + ex.ToString());
            }
            try
            {
                //Handle Vetland Connected Client DataTransferThread Timers
                if (VetlandMultiSupportDTO.VetlandConnectedClientDataTransferThreadTimers != null)
                {
                    msg.AppendLine("VetlandConnectedClientDataTransferThreadTimers count!" + VetlandMultiSupportDTO.VetlandConnectedClientDataTransferThreadTimers.Count.ToString());

                    if (VetlandMultiSupportDTO.VetlandConnectedClientDataTransferThreadTimers.ContainsKey(stopSurgeryMonitor.monitorId))
                    {
                        System.Timers.Timer timer = VetlandMultiSupportDTO.VetlandConnectedClientDataTransferThreadTimers[stopSurgeryMonitor.monitorId];

                        if (timer != null)
                        {
                            timer.Stop();
                            timer.Dispose();
                            msg.AppendLine("VetlandConnectedClientDataTransferThreadTimers stoped!");
                        }
                        VetlandMultiSupportDTO.VetlandConnectedClientDataTransferThreadTimers.Remove(stopSurgeryMonitor.monitorId);
                        msg.AppendLine("VetlandConnectedClientDataTransferThreadTimers removed!");
                    }
                }

            }
            catch (Exception ex)
            {
                msg.AppendLine("VetlandConnectedClientDataTransferThreadTimers Exception: " + "(" + stopSurgeryMonitor.monitorId.ToString() + ")" + ex.ToString());
            }

            try
            {
                //Finally stop Vetland listener completely if there is no active connection
                if (VetlandMultiSupportDTO.isVetlandListenerRunning)
                {
                    if (VetlandMultiSupportDTO.VetlandConnectedClients != null &&
                        VetlandMultiSupportDTO.VetlandConnectedClientUdpClient != null &&
                        VetlandMultiSupportDTO.VetlandConnectedClients.Count.Equals(0) &&
                        VetlandMultiSupportDTO.VetlandConnectedClientUdpClient.Count.Equals(0))
                    {
                        if (udpListener != null)
                        {
                            udpListener.Close();
                            VetlandMultiSupportDTO.isVetlandListenerRunning = false;
                            VetlandMultiSupportDTO.VetlandConnectedClients = null;
                            VetlandMultiSupportDTO.VetlandConnectedClientUdpClient = null;
                            VetlandMultiSupportDTO.VetlandConnectedClientDataReceiveThreadTimers = null;
                            VetlandMultiSupportDTO.VetlandConnectedClientDataTransferThreads = null;
                            VetlandMultiSupportDTO.VetlandConnectedClientDataTransferThreadTimers = null;
                            msg.AppendLine("udpListener closed stoped!");
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                msg.AppendLine("udpListener Exception: " + ex.ToString());
            }
            try
            {
                //Remove the corresponding Live Data File to avoid posting the anesthetic values in case if monitor is not connected
                RemoveLiveFile(stopSurgeryMonitor.monitorId);
            }
            catch (Exception ex)
            {
                msg.AppendLine("RemoveLiveFile Exception: " + ex.ToString());
            }
            try
            {
                SettingsUtility.SetDisconnectSetting(DisconnectSetting.False, DeviceIdentifier.VetLand, stopSurgeryMonitor.monitorId.ToString());
            }
            catch (Exception ex)
            {
                msg.AppendLine("SettingsUtility.SetDisconnectSetting Exception: " + ex.ToString());
            }

            LogWriter.WriteToFile(msg.ToString(), LogHelperUtility.GetLogFileNameForCommonTraceing(DeviceIdentifier.VetLand,
                                                                           stopSurgeryMonitor.monitorId.ToString()));

            LogWriter.WriteToLog(msg.ToString(), LogHelperUtility.GetLogFileNameForListener(DeviceIdentifier.VetLand,
                                                                            stopSurgeryMonitor.monitorId.ToString()));

        }
        private static void RemoveLiveFile(Guid monitorId)
        {
            try
            {
                //Remove the corresponding Live Data File to avoid posting the anesthetic values in case if monitor is not connected
                string directory = SettingsUtility.GetCommonDataPath(CommonDataSettingTypes.LiveDataFile_Folder, DeviceIdentifier.VetLand);
                if (FileProcessorUtility.DoesExistsDirectory(directory))
                {
                    string[] allFiles = FileProcessorUtility.GetAllFilesFromDirectory(directory).Where(x => x.Contains(monitorId.ToString())).ToArray();
                    if (allFiles != null && allFiles.Length > 0)
                    {
                        string file = allFiles[allFiles.Length - 1];
                        System.IO.File.Delete(file);
                    }
                }
            }
            catch
            {
                throw;
            }
        }
        /// <summary>
        /// Start Server method starts server process.
        /// </summary>
        /// <param name="ipAddress"></param>
        /// <param name="port"></param>
        public static void StartServer(StartSurgeryMonitor startSurgeryMonitor)
        {
            IPAddress ipAddress = GeneralMethodsUtility.AutoDetectIPAddress();
            try
            {
                if (udpListener != null)
                {
                    udpListener.Close();
                }

                portNo = AppConfigurations.Vetland_ServerPort;
                ip = SerializedObjects.MonitorsList.Where(x => x.monitorId.Equals(startSurgeryMonitor.monitorId)).FirstOrDefault().monitorIPAddress.ToString();
                monitorIP = IPAddress.Parse(ip);
                startSurgeryMonitorObj = startSurgeryMonitor;
                LogWriter.WriteToFile(string.Format(@"Vetland Server IP Address: {0} Port#: {1} Running Status: {2}",
                                       ipAddress.ToString(),
                                       portNo.ToString(),
                                       VetlandMultiSupportDTO.isVetlandListenerRunning),
                                       LogHelperUtility.GetLogFileNameForCommonTraceing(DeviceIdentifier.VetLand,
                                                                                           startSurgeryMonitor.monitorId.ToString()));
                if (!VetlandMultiSupportDTO.isVetlandListenerRunning)
                {

                    if (udpListener == null || udpListener.Client == null)
                    {
                        udpListener = new UdpClient(portNo);
                    }
                    udpListener.Client.SetSocketOption(SocketOptionLevel.Socket, SocketOptionName.ReuseAddress, 1);
                    //Instantiate the required collections
                    VetlandMultiSupportDTO.isVetlandListenerRunning = true;
                    VetlandMultiSupportDTO.VetlandConnectedClients = new Dictionary<Guid, IPAddress>();
                    VetlandMultiSupportDTO.VetlandConnectedClientUdpClient = new Dictionary<Guid, UdpClient>();
                    VetlandMultiSupportDTO.VetlandConnectedClientDataTransferThreads = new Dictionary<Guid, Thread>();
                    VetlandMultiSupportDTO.VetlandConnectedClientDataTransferThreadTimers = new Dictionary<Guid, System.Timers.Timer>();
                    VetlandMultiSupportDTO.VetlandConnectedClientDataReceiveThreadTimers = new Dictionary<Guid, System.Timers.Timer>();

                    string msg = string.Format(@"Started Vetland PM Server. Waiting for a client...MonitorId: {0} Running Status: {1}",
                                                                       startSurgeryMonitorObj.monitorId, VetlandMultiSupportDTO.isVetlandListenerRunning);

                    LogWriter.WriteToFile(msg, LogHelperUtility.GetLogFileNameForCommonTraceing(DeviceIdentifier.VetLand,
                                                                                    startSurgeryMonitorObj.monitorId.ToString()));

                    //Loop to accept the tcp client/monitor
                    WaitForClients(startSurgeryMonitorObj);
                }
                else
                {
                    string msg = string.Format(@"Started to listen MonitorId: {0} Running Status: {1}",
                                                    startSurgeryMonitorObj.monitorId, VetlandMultiSupportDTO.isVetlandListenerRunning);

                    LogWriter.WriteToFile(msg, LogHelperUtility.GetLogFileNameForCommonTraceing(DeviceIdentifier.VetLand,
                                                                                    startSurgeryMonitorObj.monitorId.ToString()));

                    //Loop to accept the tcp client/monitor
                    WaitForClients(startSurgeryMonitorObj);
                }

            }
            catch (SocketException ex)
            {
                //Need to check whether it is appropriate or not to log
                LogWriter.WriteToFile("(3)SocketException ex :" + ex.ToString(),
                     LogHelperUtility.GetLogFileNameForCommonTraceing(DeviceIdentifier.VetLand,
                                                                            startSurgeryMonitor.monitorId.ToString()));
            }
            catch (Exception ex)
            {
                //Need to check whether it is appropriate or not to log
                LogWriter.WriteToFile("(4)Exception ex :" + ex.ToString(),
                     LogHelperUtility.GetLogFileNameForCommonTraceing(DeviceIdentifier.VetLand,
                                                                            startSurgeryMonitor.monitorId.ToString()));
            }
            finally
            {
                if (udpListener != null)
                {
                    udpListener.Close();
                }
            }
        }
        /// <summary>
        /// Parsing received packet.
        /// </summary>
        /// <param name="packet"></param>
        private static void ParsePacket(byte[] packet, StartSurgeryMonitor startSurgeryMonitor)
        {
            try
            {
                Dictionary<string, string> parsedData = new VetlandDataPacketParser().Parse_FONT_DATA(packet);

                LogWriter.WriteToLog(string.Format(@"Parsed {0} data!", VetlandUtilityPacketNames.FONT_DATA),
                                           LogHelperUtility.GetLogFileNameForListener(DeviceIdentifier.VetLand, startSurgeryMonitor.monitorId.ToString()));
                LogWriter.WriteToLog("\t" + GeneralMethodsUtility.ConvertParsedPacketToString(parsedData, ':'),
                                        LogHelperUtility.GetLogFileNameForListener(DeviceIdentifier.VetLand, startSurgeryMonitor.monitorId.ToString()));
                LogWriter.WriteToLiveFile("\t" + GeneralMethodsUtility.ConvertParsedPacketToString(parsedData, ':', '|'),
                                        LogHelperUtility.GetLogFileNameForCommonLiveData(DeviceIdentifier.VetLand, startSurgeryMonitor.monitorId.ToString()));
            }
            catch (Exception ex)
            {
                LogWriter.WriteToFile(ex.ToString(), LogHelperUtility.GetLogFileNameForCommonTraceing(DeviceIdentifier.VetLand,
                                                                                startSurgeryMonitor.monitorId.ToString()));
            }
        }
        /// <summary>
        /// Sending connection request every 4 seconds.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private static void OnDataReceiveElapsed(object sender, ElapsedEventArgs e, StartSurgeryMonitor startSurgeryMonitor)
        {
            try
            {
                LogWriter.WriteToLog("Sending connection request to client", LogHelperUtility.GetLogFileNameForListener(DeviceIdentifier.VetLand,
                                                                                               startSurgeryMonitor.monitorId.ToString()));
                IPEndPoint MonitorIpEndPoint = new IPEndPoint(monitorIP, portNo);
                RemoteEndPoint = MonitorIpEndPoint as EndPoint;

                string connect_req = "Broad";
                byte[] request_bytes = Encoding.ASCII.GetBytes(connect_req);
                string request_bytes_hex = GeneralMethodsUtility.ConvertBytesArrayIntoHexadecimal(request_bytes, VetlandUtilityControlPackets.Connect_Req_Length, true);
                LogWriter.WriteToLog(string.Format(@"Sent CONNECT_REQ ({0} bytes)!", VetlandUtilityControlPackets.Connect_Req_Length), LogHelperUtility.GetLogFileNameForListener(DeviceIdentifier.VetLand,
                                                                                        startSurgeryMonitor.monitorId.ToString()));
                LogWriter.WriteToLog(string.Format(@"{0} ({1})", request_bytes_hex, connect_req), LogHelperUtility.GetLogFileNameForListener(DeviceIdentifier.VetLand,
                                                                                        startSurgeryMonitor.monitorId.ToString()));

                udpListener.Client.SendTo(request_bytes, RemoteEndPoint);

                if (serverEndPoint != null)
                {
                    string msg = string.Format(@"Temporarily accepted the client. Remote IP Address: {0} Remote port#: {1}",
                                                serverIpEndPoint.Address, serverIpEndPoint.Port);
                    LogWriter.WriteToLog(msg, LogHelperUtility.GetLogFileNameForListener(DeviceIdentifier.VetLand,
                                                                                    startSurgeryMonitor.monitorId.ToString()));
                }
            }
            catch (Exception ex)
            {
                LogWriter.WriteToFile(ex.ToString(), LogHelperUtility.GetLogFileNameForCommonTraceing(DeviceIdentifier.VetLand,
                                                                                            startSurgeryMonitor.monitorId.ToString()));
            }

        }
        /// <summary>
        /// Wait for tcp client request, if it is allowed and not listeneting then start listening the monitor.
        /// </summary>
        /// <param name="startSurgeryMonitor"></param>portNo
        private static void WaitForClients(StartSurgeryMonitor startSurgeryMonitor)
        {
            int clientsCount = 1;

            if (VetlandMultiSupportDTO.isVetlandListenerRunning)
            {
                try
                {

                    LogWriter.WriteToFile("I am Vetland PM Server. Waiting for a client...", LogHelperUtility.GetLogFileNameForCommonTraceing(DeviceIdentifier.VetLand,
                                                                                            startSurgeryMonitor.monitorId.ToString()));

                    LogWriter.WriteToFile("Sending connection request to client", LogHelperUtility.GetLogFileNameForCommonTraceing(DeviceIdentifier.VetLand,
                                                                                            startSurgeryMonitor.monitorId.ToString()));

                    IPEndPoint MonitorIpEndPoint = new IPEndPoint(monitorIP, portNo);
                    RemoteEndPoint = MonitorIpEndPoint as EndPoint;
                    serverIpEndPoint = new IPEndPoint(IPAddress.Any, portNo);
                    serverEndPoint = serverIpEndPoint as EndPoint;

                    string connect_req = "Broad";
                    byte[] request_bytes = Encoding.ASCII.GetBytes(connect_req);
                    string request_bytes_hex = GeneralMethodsUtility.ConvertBytesArrayIntoHexadecimal(request_bytes, VetlandUtilityControlPackets.Connect_Req_Length, true);
                    LogWriter.WriteToFile(string.Format(@"Sent CONNECT_REQ ({0} bytes)!", VetlandUtilityControlPackets.Connect_Req_Length), LogHelperUtility.GetLogFileNameForCommonTraceing(DeviceIdentifier.VetLand,
                                                                                            startSurgeryMonitor.monitorId.ToString()));
                    LogWriter.WriteToFile(string.Format(@"{0} ({1})", request_bytes_hex, connect_req), LogHelperUtility.GetLogFileNameForCommonTraceing(DeviceIdentifier.VetLand,
                                                                                            startSurgeryMonitor.monitorId.ToString()));

                    udpListener.Client.SendTo(request_bytes, RemoteEndPoint);

                    #region CheckandWaitForConnection

                    //check  client is connected or not and wait for 10 seconds.
                    bool IsListenerConnected = CheckandWaitForConnection(request_bytes, RemoteEndPoint);

                    if (!IsListenerConnected)
                    {
                        //WORKING ON THIS POINT 14 TO IMPLEMENT
                        //#Evg.14 - Power failure
                        //Action: Listener sends error message to Status-API (/monitorstatus);
                        string msgCanNotConnectMonitor = CommonMessages.CanNotConnectTheMonitor;
                        SurgeryMonitorStatusHelper.PostSurgeryMonitorStatusWithLogInListenerTrace(
                                                                startSurgeryMonitor.monitorId
                                                                , msgCanNotConnectMonitor
                                                                , DeviceIdentifier.VetLand
                                                                , SurgeryMonitorStatus.Status.ConnectionToMonitorFailed);

                        //Action: Listener adds log message
                        LogWriter.WriteToFile(msgCanNotConnectMonitor
                                                , LogHelperUtility.GetLogFileNameForCommonTraceing(DeviceIdentifier.VetLand
                                                , startSurgeryMonitor.monitorId.ToString()));
                    }


                    #endregion

                    if (serverEndPoint != null)
                    {
                        string msg = string.Format(@"Temporarily accepted the client. Remote IP Address: {0} Remote port#: {1}",
                                                    MonitorIpEndPoint.Address, MonitorIpEndPoint.Port);
                        LogWriter.WriteToFile(msg, LogHelperUtility.GetLogFileNameForCommonTraceing(DeviceIdentifier.VetLand,
                                                                                        startSurgeryMonitor.monitorId.ToString()));

                        //24th Feb 2017, Urgent fix - Send status to the server when connected to the monitor
                        string msgMonitorConnected = CommonMessages.MonitorConnectedSuccessfully;
                        SurgeryMonitorStatusHelper.PostSurgeryMonitorStatusWithLogInListenerTrace(
                                                                            startSurgeryMonitor.monitorId
                                                                            , msgMonitorConnected
                                                                            , DeviceIdentifier.Cardell
                                                                            , SurgeryMonitorStatus.Status.Active);
                    }

                    //Check whether the ip address of this MonitorId is registered/allowed
                    //Look up the remote ip address in serialized registered monitors
                    bool isAllowed = false;
                    if (SerializedObjects.MonitorsList.Where(x => x.monitorId.Equals(startSurgeryMonitor.monitorId)).FirstOrDefault().monitorIPAddress.Equals(MonitorIpEndPoint.Address))
                    {
                        isAllowed = true;
                    }

                    //Check whether the client/monitor with this remote ip address is already running
                    //Look up the remote ip address in VetlandMultiSupportDTO.VetlandConnectedClients
                    bool isListening = false;
                    if (VetlandMultiSupportDTO.VetlandConnectedClients != null && VetlandMultiSupportDTO.VetlandConnectedClients.Count > 0)
                    {
                        isListening = VetlandMultiSupportDTO.VetlandConnectedClients.ContainsValue(serverIpEndPoint.Address);
                    }

                    LogWriter.WriteToFile("isListening - isAllowed!" + isListening + isAllowed, LogHelperUtility.GetLogFileNameForCommonTraceing(DeviceIdentifier.VetLand,
                                                                                            startSurgeryMonitor.monitorId.ToString()));

                    //Check if this client/monitor is registered/allowed and is not running then start listening it by HandleClient
                    if (isAllowed & !isListening)
                    {
                        List<object> list = new List<object>();

                        //Add it to the connected clients list
                        VetlandMultiSupportDTO.VetlandConnectedClients.Add(startSurgeryMonitor.monitorId, MonitorIpEndPoint.Address);

                        //Prepare a list of startSurgeryMonitor and client itself to pass to HandleClient
                        list.Add(startSurgeryMonitor);
                        list.Add(udpListener);

                        string msg = string.Format(@"Client/Monitor is connected. Monitor Id: {0} Remote IP Address: {1}",
                                                    startSurgeryMonitor.monitorId.ToString(), MonitorIpEndPoint.Address);

                        LogWriter.WriteToFile(msg, LogHelperUtility.GetLogFileNameForCommonTraceing(DeviceIdentifier.VetLand,
                                                                                        startSurgeryMonitor.monitorId.ToString()));
                        clientsCount++;

                        //So just call HandleClient
                        HandleClientCommunication(list);
                    }
                    //If it is nor registered/allowed, close the connection
                    else
                    {
                        try
                        {
                            //Close the client that is yet accepted temporarily
                            udpListener.Close();
                        }
                        catch
                        {
                            //No need to log this exception, it will increase the file size
                        }
                    }
                }
                catch (Exception ex)
                {
                    LogWriter.WriteToFile(ex.ToString(), LogHelperUtility.GetLogFileNameForCommonTraceing(DeviceIdentifier.VetLand,
                                                                                            startSurgeryMonitor.monitorId.ToString()));
                }
            }
        }
        /// <summary>
        /// Method to check that client is connected or not and wait for 10 seconds.
        /// </summary>
        /// <param name="request_bytes"></param>
        /// <param name="RemoteEndPoint"></param>
        /// <returns></returns>
        private static bool CheckandWaitForConnection(byte[] request_bytes, EndPoint RemoteEndPoint)
        {
            bool IsListenerConnected = true;
            int count = 1;
            while (!(udpListener.Available > 0))
            {
                if (count == 2)
                {
                    IsListenerConnected = false;
                    break;
                }
                Thread.Sleep(10000);
                udpListener.Client.SendTo(request_bytes, RemoteEndPoint);
                count++;
                continue;

            }
            return IsListenerConnected;
        }
        /// <summary>
        /// Handle the client communication for the connected monitor/tcpclient.
        /// </summary>
        /// <param name="obj"></param>
        private static void HandleClientCommunication(object obj)
        {
            string monitorId = string.Empty;
            try
            {
                if (obj != null)
                {
                    //Unbox the obj received and extract the StartSurgeryMonitor & TcpClient objects
                    List<object> list = (List<object>)obj;
                    StartSurgeryMonitor startSurgeryMonitor = (StartSurgeryMonitor)list[0];
                    UdpClient client = (UdpClient)list[1];

                    monitorId = startSurgeryMonitor.monitorId.ToString();

                    //Add this tcp client to the collection
                    VetlandMultiSupportDTO.VetlandConnectedClientUdpClient.Add(startSurgeryMonitor.monitorId, client);

                    if (client != null && startSurgeryMonitor != null)
                    {
                        string msg = string.Format(@"Handle client! Starting communication! Monitor Id: {0}",
                                                    startSurgeryMonitor.monitorId.ToString());

                        LogWriter.WriteToFile(msg, LogHelperUtility.GetLogFileNameForCommonTraceing(DeviceIdentifier.VetLand,
                                                                                        startSurgeryMonitor.monitorId.ToString()));

                        //Set it to disconnect false at start, on StopMonitor() it will be set to TRUE
                        SettingsUtility.SetDisconnectSetting(DisconnectSetting.False, DeviceIdentifier.VetLand,
                                                                startSurgeryMonitor.monitorId.ToString());

                        //Additional logging, Feb 2017
                        LogWriter.WriteToLog("DisconnectSetting set : " + DisconnectSetting.False.ToString(), LogHelperUtility.GetLogFileNameForListener(DeviceIdentifier.VetLand,
                                                            startSurgeryMonitor.monitorId.ToString()));

                        //Note: This object can not be disposed, if it is disposed application will break.
                        System.Timers.Timer timerDataReceive = new System.Timers.Timer();
                        timerDataReceive.Elapsed += (sender, e) => OnDataReceiveElapsed(sender, e, startSurgeryMonitor);
                        timerDataReceive.Interval = Convert.ToInt32(4000);
                        timerDataReceive.Enabled = true;
                        timerDataReceive.Start();
                        VetlandMultiSupportDTO.VetlandConnectedClientDataReceiveThreadTimers.Add(startSurgeryMonitor.monitorId, timerDataReceive);
                        doesListen = true;
                        GetandProcessPakcets(startSurgeryMonitor);
                    }
                }
            }
            catch (Exception ex)
            {
                LogWriter.WriteToFile(ex.ToString(), LogHelperUtility.GetLogFileNameForCommonTraceing(DeviceIdentifier.VetLand, monitorId));
            }
        }
        /// <summary>
        /// This method gets packets from device and parse. and initiate data trasfer request.
        /// </summary>
        /// <param name="startSurgeryMonitor"></param>
        private static void GetandProcessPakcets(StartSurgeryMonitor startSurgeryMonitor)
        {
            try
            {
                int veryFirstObservationDataCounter = 0;
                int counterRequests = 0;

                #region innerloop
                while (doesListen)
                {
                    try
                    {
                        //Receive all the bytes from device
                        if (udpListener != null && udpListener.Available > 0 && udpListener.Client != null)
                        {
                            int noOfBytesReceived = 0;
                            byte[] bytes_request = new byte[1024];
                            noOfBytesReceived = (udpListener != null && udpListener.Client != null) ? udpListener.Client.ReceiveFrom(bytes_request, ref serverEndPoint) : 0;

                            if (noOfBytesReceived == 0 || !doesListen)
                                break;

                            //Convert all bytes, first byte and first two bytes into hexadecimal string 
                            string full_request_hex = GeneralMethodsUtility.ConvertBytesArrayIntoHexadecimal(bytes_request, noOfBytesReceived, true);
                            string first_two_bytes_string = GeneralMethodsUtility.ConvertBytesArrayIntoHexadecimal(bytes_request, 2, false);

                            //Additional logging, Feb 2017
                            LogWriter.WriteToLog("Complete packet received : " + full_request_hex, LogHelperUtility.GetLogFileNameForListener(DeviceIdentifier.VetLand,
                                                                startSurgeryMonitor.monitorId.ToString()));

                            ////Check if the request is CONNECT_REQ - C001 is the CONNECT_REQ Header and Primitive bytes
                            if (noOfBytesReceived.Equals(VetlandUtilityControlPackets.Connect_Accept_Length) && first_two_bytes_string.ToUpper().Equals(VetlandUtilityPrimitives.REQ_CONNECT_Primitive))//"4272"))
                            {
                                //Convert sent CONNECT_ACCEPT request into hexadecimal string
                                LogWriter.WriteToLog("Connected client!", LogHelperUtility.GetLogFileNameForListener(DeviceIdentifier.VetLand,
                                                                                    startSurgeryMonitor.monitorId.ToString()));
                                string CONNECT_ACCEPT_hex = GeneralMethodsUtility.ConvertBytesArrayIntoHexadecimal(bytes_request, VetlandUtilityControlPackets.Connect_Accept_Length, true);
                                string CONNECT_ACCEPT = Encoding.ASCII.GetString(bytes_request, 0, noOfBytesReceived);
                                string Bed_Number = CONNECT_ACCEPT.Substring(5, VetlandUtilityControlPackets.Bed_Number_Length);

                                LogWriter.WriteToLog(string.Format(@"Received CONNECT_REQ ({0} bytes)!", VetlandUtilityControlPackets.Connect_Accept_Length), LogHelperUtility.GetLogFileNameForListener(DeviceIdentifier.VetLand,
                                                                                    startSurgeryMonitor.monitorId.ToString()));
                                LogWriter.WriteToLog(string.Format(@"{0} ({1})", CONNECT_ACCEPT_hex, CONNECT_ACCEPT), LogHelperUtility.GetLogFileNameForListener(DeviceIdentifier.VetLand,
                                                                                    startSurgeryMonitor.monitorId.ToString()));
                                LogWriter.WriteToLog(string.Format(@"Received Bed No: {0}", Bed_Number), LogHelperUtility.GetLogFileNameForListener(DeviceIdentifier.VetLand,
                                                                                    startSurgeryMonitor.monitorId.ToString()));
                            }
                            else
                            {
                                if (!doesListen) break;
                                //Check if the request is USER_ADMIT_ALAM_SETTING_PACKATES(189 bytes) -- first byte C1 is the Header byte
                                if (noOfBytesReceived.Equals(VetlandUtilityInformationPackets.Font_Data_Length)
                                && first_two_bytes_string.ToUpper().Equals(VetlandUtilityPrimitives.FONT_DATA_Primitive))//"4046"))
                                {
                                    LogWriter.WriteToLog(string.Format(@"Received FONT_DATA_PACKATES ({0} bytes)!", noOfBytesReceived), LogHelperUtility.GetLogFileNameForListener(DeviceIdentifier.VetLand,
                                                                                    startSurgeryMonitor.monitorId.ToString()));
                                    full_request_hex = GeneralMethodsUtility.ConvertBytesArrayIntoHexadecimal(bytes_request, noOfBytesReceived, true);
                                    LogWriter.WriteToLog(full_request_hex, LogHelperUtility.GetLogFileNameForListener(DeviceIdentifier.VetLand,
                                                                                    startSurgeryMonitor.monitorId.ToString()));

                                    ParsePacket(bytes_request, startSurgeryMonitor);
                                    if (veryFirstObservationDataCounter.Equals(0))
                                    {
                                        //Additional logging, Feb 2017
                                        LogWriter.WriteToLog("Started first dataset posting.", LogHelperUtility.GetLogFileNameForListener(DeviceIdentifier.VetLand,
                                                                            startSurgeryMonitor.monitorId.ToString()));

                                        Thread threadDataTransfer = new Thread(new ParameterizedThreadStart(StartDataTransfer));
                                        threadDataTransfer.Name = "DataTransferThread";
                                        VetlandMultiSupportDTO.VetlandConnectedClientDataTransferThreads.Add(startSurgeryMonitor.monitorId, threadDataTransfer);
                                        veryFirstObservationDataCounter = 1;
                                        threadDataTransfer.Start(startSurgeryMonitor);

                                        //Additional logging, Feb 2017
                                        LogWriter.WriteToLog("First dataset posting called successfuly.", LogHelperUtility.GetLogFileNameForListener(DeviceIdentifier.VetLand,
                                                                            startSurgeryMonitor.monitorId.ToString()));
                                    }

                                    counterRequests++;
                                    if ((counterRequests + 1).Equals(int.MaxValue))
                                        counterRequests = 0;

                                    System.Threading.Thread.Sleep(300);
                                    DisconnectSetting doesDisconnect = SettingsUtility.ReadDisconnectSetting(DeviceIdentifier.VetLand,
                                                                                             startSurgeryMonitor.monitorId.ToString());

                                    //Additional logging, Feb 2017
                                    LogWriter.WriteToLog("DisconnectSetting read: " + doesDisconnect.ToString(), LogHelperUtility.GetLogFileNameForListener(DeviceIdentifier.VetLand,
                                                                        startSurgeryMonitor.monitorId.ToString()));
                                }
                            }
                        }
                    }
                    catch //(Exception ex) //(SocketException e)
                    {
                        //No need to log this exeception
                        ////Additional logging, Feb 2017
                        //LogWriter.WriteToFile(ex.ToString(), LogHelperUtility.GetLogFileNameForCommonTraceing(DeviceIdentifier.VetLand,
                        //                                               startSurgeryMonitor.monitorId.ToString()));
                    }
                }
                #endregion innerloop
            }
            catch
            {
                throw;
            }

        }
        /// <summary>
        /// Initiate data transfer process.
        /// </summary>
        private static void StartDataTransfer(object obj)
        {
            StartSurgeryMonitor startSurgeryMonitor = null;
            try
            {
                if (obj != null)
                {
                    System.Timers.Timer timerDataTransfer = new System.Timers.Timer();
                    startSurgeryMonitor = (StartSurgeryMonitor)obj;

                    LogWriter.WriteToFile(string.Format("<SDT-1> StartDataTransfer method called. | SurgeryStartDate : {0} | Frequency : {1}  | CurrentTime : {2}"
                                            , startSurgeryMonitor.surgeryStartDate.ToString()
                                            , startSurgeryMonitor.surgeryIntervalFrequency.ToString()
                                            , DateTime.Now.ToString())
                                            , LogHelperUtility.GetLogFileNameForCommonTraceing(DeviceIdentifier.VetLand,
                                                                                startSurgeryMonitor.monitorId.ToString()));
                    //Calculate the next schedule
                    DateTime nextSchedule = TimeIntervalUtility.GetNextSchedule(startSurgeryMonitor.surgeryStartDate, startSurgeryMonitor.surgeryIntervalFrequency);
                    double interval = TimeIntervalUtility.GetCurrentIntervalInMilliseconds(nextSchedule);

                    LogWriter.WriteToFile(string.Format("<SDT-2> Very first data transfer schedule : {0} | Starting timer at: {1} | Interval(Calculated): {2}", nextSchedule, DateTime.Now.ToString(), interval.ToString()),
                                            LogHelperUtility.GetLogFileNameForCommonTraceing(DeviceIdentifier.VetLand,
                                                                            startSurgeryMonitor.monitorId.ToString()));
                    if (interval.Equals(0)) interval = 100;

                    //Handle data transfer elapsed event
                    timerDataTransfer.Elapsed += (sender, e) => OnDataTransferElapsed(sender, e, startSurgeryMonitor);
                    timerDataTransfer.Interval = Convert.ToInt32(interval);
                    timerDataTransfer.Enabled = true;
                    timerDataTransfer.Start();
                    VetlandMultiSupportDTO.VetlandConnectedClientDataTransferThreadTimers.Add(startSurgeryMonitor.monitorId, timerDataTransfer);

                    LogWriter.WriteToFile(string.Format("<SDT-3.1> Timer started at : {0} | InitiateDataTransfer method called.", DateTime.Now.ToString()),
                                            LogHelperUtility.GetLogFileNameForCommonTraceing(DeviceIdentifier.VetLand,
                                                                            startSurgeryMonitor.monitorId.ToString()));

                    HttpStatusCode statusCode = HttpStatusCode.Unused;
                    bool b = false;
                    try
                    {
                        statusCode = DataTransferUtility.InitiateDataTransfer(startSurgeryMonitor, CommonDataSettingTypes.LiveDataFile_Folder,
                                                                          DeviceIdentifier.VetLand,
                                                                          startSurgeryMonitor.monitorId.ToString(),
                                                                          SerializedObjects.SurgeryApiKey);
                        b = !b;
                    }
                    catch (Exception ex)
                    {
                        LogWriter.WriteToFile("<SDT-3.1.1> Could not post the anesthetic values. Trying again in 10 seconds. " + ex.Message
                                        , LogHelperUtility.GetLogFileNameForCommonTraceing(DeviceIdentifier.VetLand
                                        , startSurgeryMonitor.monitorId.ToString()));
                    }
                    if (!b)
                    {
                        try
                        {
                            System.Threading.Thread.Sleep(10 * 1000);
                            LogWriter.WriteToFile("<SDT-3.1.2> Trying to post the anesthetic values agin after 10 seconds."
                                            , LogHelperUtility.GetLogFileNameForCommonTraceing(DeviceIdentifier.VetLand
                                            , startSurgeryMonitor.monitorId.ToString()));
                            statusCode = DataTransferUtility.InitiateDataTransfer(startSurgeryMonitor, CommonDataSettingTypes.LiveDataFile_Folder,
                                                                              DeviceIdentifier.VetLand,
                                                                              startSurgeryMonitor.monitorId.ToString(),
                                                                              SerializedObjects.SurgeryApiKey);
                        }
                        catch (Exception ex)
                        {
                            LogWriter.WriteToFile("<SDT-3.1.3> Could not post the anesthetic values. Trying again in 10 seconds. " + ex.Message
                                            , LogHelperUtility.GetLogFileNameForCommonTraceing(DeviceIdentifier.VetLand
                                            , startSurgeryMonitor.monitorId.ToString()));
                        }
                    }

                    LogWriter.WriteToFile(string.Format("<SDT-3.2> InitiateDataTransfer method ended at : {0}", DateTime.Now.ToString()),
                                            LogHelperUtility.GetLogFileNameForCommonTraceing(DeviceIdentifier.VetLand,
                                                                            startSurgeryMonitor.monitorId.ToString()));

                    if (SerializedObjects.SaveMonitorToStopBasedOnStatusCode(startSurgeryMonitor, statusCode, DeviceIdentifier.VetLand))
                    {

                        string msgSaveMonitor = "<SDT-4> Saved Monitor Id : " + startSurgeryMonitor.monitorId.ToString()
                                                 + " StatusCode : " + statusCode.ToString()
                                                 + " Set From : First data transfer.";

                        LogWriter.WriteToFile(msgSaveMonitor, LogHelperUtility.GetLogFileNameForCommonTraceing(DeviceIdentifier.VetLand,
                                                                                startSurgeryMonitor.monitorId.ToString()));
                    }

                    string msg = string.Empty;
                    if (statusCode.Equals(HttpStatusCode.Created) || statusCode.Equals(HttpStatusCode.OK))
                    {
                        msg = string.Format("<SDT-5> First dataset sent, anesthetic values posted at : {0}", DateTime.Now.ToString());
                    }
                    else
                    {
                        //#Evg.15 - Internet connection failure (between Listener and SFS Server) or Anesthetic values could not be posted
                        //Action: Listener will not post anesthetic values to SFS server. 
                        //Action: Listener logs the error message locally. (Logging error in catch block)
                        msg = string.Format("<SDT-5> First dataset sent, anesthetic values could not be posted at : {0}", DateTime.Now.ToString());
                    }
                    LogWriter.WriteToFile(msg, LogHelperUtility.GetLogFileNameForCommonTraceing(DeviceIdentifier.VetLand,
                                                                            startSurgeryMonitor.monitorId.ToString()));

                    //Just ping the monitor here without any timer
                    string pingStatus = "<SDT-6.1> PingMonitor method called at : " + DateTime.Now.ToString();
                    PingMonitor(startSurgeryMonitor);
                    pingStatus += Environment.NewLine + "<SDT-6.2> PingMonitor method ended at : " + DateTime.Now.ToString();
                    LogWriter.WriteToFile(pingStatus, LogHelperUtility.GetLogFileNameForCommonTraceing(DeviceIdentifier.VetLand
                                                        , startSurgeryMonitor.monitorId.ToString()));
                }
                else
                {
                    //Additional logging, Feb 2017
                    LogWriter.WriteToFile("<SDT-7> StartDataTransfer argument is null.", LogHelperUtility.GetErrorFileNameForAdminApp());
                }

                LogWriter.WriteToFile("<SDT-8> StartDataTransfer method ended at : " + DateTime.Now.ToString()
                                        , LogHelperUtility.GetLogFileNameForCommonTraceing(DeviceIdentifier.VetLand
                                        , startSurgeryMonitor.monitorId.ToString()));
            }
            catch (Exception ex)
            {
                //Additional logging, Feb 2017
                LogWriter.WriteToFile(DeviceIdentifier.VetLand.ToString() + " : " + ex.ToString(), LogHelperUtility.GetErrorFileNameForAdminApp());
            }
        }
        /// <summary>
        /// Transfering Data
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private static void OnDataTransferElapsed(object sender, ElapsedEventArgs e, StartSurgeryMonitor startSurgeryMonitor)
        {
            try
            {
                //Additional logging, Feb 2017
                LogWriter.WriteToFile("<ODTE-1> OnDataTransferElapsed event started at : " + DateTime.Now.ToString() + " | SignalTime : " + e.SignalTime.ToString(),
                    LogHelperUtility.GetLogFileNameForCommonTraceing(DeviceIdentifier.VetLand, startSurgeryMonitor.monitorId.ToString()));

                //Just ping the monitor here without any timer
                string pingStatus = "<ODTE-2.1> PingMonitor method called at : " + DateTime.Now.ToString();
                PingMonitor(startSurgeryMonitor);
                pingStatus += Environment.NewLine + "<ODTE-2.2> PingMonitor method ended at : " + DateTime.Now.ToString();
                LogWriter.WriteToFile(pingStatus, LogHelperUtility.GetLogFileNameForCommonTraceing(DeviceIdentifier.VetLand
                                                    , startSurgeryMonitor.monitorId.ToString()));

                System.Timers.Timer timerDataTransfer = (System.Timers.Timer)sender;

                int numberOfIntervalSet = 0;

                if (numberOfIntervalSet.Equals(0))
                {
                    if (startSurgeryMonitor.surgeryIntervalFrequency > 0)
                    {
                        double frequencyInSeconds = 0;
                        double.TryParse((startSurgeryMonitor.surgeryIntervalFrequency).ToString(), out frequencyInSeconds);
                        double.TryParse((frequencyInSeconds).ToString(), out frequencyInSeconds);

                        int freqMinutes = Convert.ToInt16(frequencyInSeconds / 60.0);

                        DateTime onspotTime = DateTime.Now;
                        DateTime repeatitiveSchedule = onspotTime.AddMinutes(freqMinutes);
                        DateTime repeatitiveScheduleRounded = DateTime.Parse(String.Format("{0:g}", repeatitiveSchedule));

                        //Add 10 seconds more to avoid lag in elapsing the event
                        repeatitiveScheduleRounded = repeatitiveScheduleRounded.AddSeconds(5);//May be 10 seconds
                        string txt = "<ODTE-3> On spot time : " + onspotTime.ToString() + " | Next continuous data transfer schedule : " + repeatitiveScheduleRounded.ToString();

                        double intervalMilliseconds = TimeIntervalUtility.GetCurrentIntervalInMilliseconds(repeatitiveScheduleRounded);

                        timerDataTransfer.Interval = Convert.ToInt32(intervalMilliseconds);
                        timerDataTransfer.Enabled = true;

                        txt += " | Timer interval updated.";

                        LogWriter.WriteToFile(txt, LogHelperUtility.GetLogFileNameForCommonTraceing(DeviceIdentifier.VetLand,
                                                                                    startSurgeryMonitor.monitorId.ToString()));
                        numberOfIntervalSet++;
                    }
                }

                LogWriter.WriteToFile(string.Format("<ODTE-4.1> InitiateDataTransfer method started at : {0}", DateTime.Now.ToString()),
                                        LogHelperUtility.GetLogFileNameForCommonTraceing(DeviceIdentifier.VetLand,
                                                                        startSurgeryMonitor.monitorId.ToString()));
                HttpStatusCode statusCode = DataTransferUtility.InitiateDataTransfer(startSurgeryMonitor,
                                                                CommonDataSettingTypes.LiveDataFile_Folder,
                                                                DeviceIdentifier.VetLand,
                                                                startSurgeryMonitor.monitorId.ToString(),
                                                                SerializedObjects.SurgeryApiKey);


                LogWriter.WriteToFile(string.Format("<ODTE-4.2> InitiateDataTransfer method ended at : {0}", DateTime.Now.ToString()),
                                        LogHelperUtility.GetLogFileNameForCommonTraceing(DeviceIdentifier.VetLand,
                                                                        startSurgeryMonitor.monitorId.ToString()));

                if (SerializedObjects.SaveMonitorToStopBasedOnStatusCode(startSurgeryMonitor, statusCode, DeviceIdentifier.VetLand))
                {

                    string msgSaveMonitor = "<ODTE-5> Saved Monitor Id : " + startSurgeryMonitor.monitorId.ToString() + " StatusCode : " + statusCode.ToString() + " Set From : on elapsed data transfer";

                    LogWriter.WriteToFile(msgSaveMonitor, LogHelperUtility.GetLogFileNameForCommonTraceing(DeviceIdentifier.VetLand,
                                                                            startSurgeryMonitor.monitorId.ToString()));
                }

                string msg = string.Empty;
                if (statusCode.Equals(HttpStatusCode.Created) || statusCode.Equals(HttpStatusCode.OK))
                {
                    msg = string.Format("<ODTE-6> DataTransfer executed, anesthetic values posted at (SignalTime) : {0}", e.SignalTime.ToString());
                }
                else
                {
                    //#Evg.15 - Internet connection failure (between Listener and SFS Server) or Anesthetic values could not be posted
                    //Action: Listener will not post anesthetic values to SFS server. 
                    //Action: Listener logs the error message locally. (Logging error in catch block)
                    msg = string.Format("<ODTE-6> DataTransfer executed, anesthetic values could not be posted at (SignalTime) : {0}", e.SignalTime.ToString());
                }

                msg += Environment.NewLine + "<ODTE-7> OnDataTransferElapsed event ended at : " + DateTime.Now.ToString();

                LogWriter.WriteToFile(msg, LogHelperUtility.GetLogFileNameForCommonTraceing(DeviceIdentifier.VetLand,
                                                                        startSurgeryMonitor.monitorId.ToString()));
            }
            catch (Exception ex)
            {
                LogWriter.WriteToFile(ex.ToString(), LogHelperUtility.GetLogFileNameForCommonTraceing(DeviceIdentifier.VetLand,
                                                                                            startSurgeryMonitor.monitorId.ToString()));
            }
        }
        /// <summary>
        /// This method transfers data to server.
        /// </summary>
        /// <param name="startSurgeryMonitor"></param>
        public static void PostAnestheticValuesOnDemand(StartSurgeryMonitor startSurgeryMonitor)
        {
            try
            {
                if (startSurgeryMonitor != null)
                {
                    //Just ping the monitor here without any timer
                    string pingStatus = "<ODAVP-1> PingMonitor method called at : " + DateTime.Now.ToString();
                    PingMonitor(startSurgeryMonitor);
                    pingStatus += Environment.NewLine + "<ODAVP-2> PingMonitor method ended at : " + DateTime.Now.ToString();

                    LogWriter.WriteToFile(pingStatus, LogHelperUtility.GetLogFileNameForCommonTraceing(DeviceIdentifier.VetLand
                                                        , startSurgeryMonitor.monitorId.ToString()));

                    HttpStatusCode statusCode = DataTransferUtility.InitiateDataTransfer(startSurgeryMonitor, CommonDataSettingTypes.LiveDataFile_Folder,
                                                                    DeviceIdentifier.VetLand,
                                                                    startSurgeryMonitor.monitorId.ToString(),
                                                                    SerializedObjects.SurgeryApiKey);

                    if (SerializedObjects.SaveMonitorToStopBasedOnStatusCode(startSurgeryMonitor, statusCode, DeviceIdentifier.VetLand))
                    {

                        string msgSaveMonitor = "<ODAVP-3> Saved Monitor Id: " + startSurgeryMonitor.monitorId.ToString() + " StatusCode: " + statusCode.ToString() + " Set From : on demand data transfer";

                        LogWriter.WriteToFile(msgSaveMonitor, LogHelperUtility.GetLogFileNameForCommonTraceing(DeviceIdentifier.VetLand,
                                                                                startSurgeryMonitor.monitorId.ToString()));
                    }

                    string msg = string.Empty;
                    if (statusCode.Equals(HttpStatusCode.Created) || statusCode.Equals(HttpStatusCode.OK))
                    {
                        msg = string.Format("<ODAVP-4> On demand anesthetic values posted at : {0}", DateTime.Now.ToString());
                    }
                    else
                    {
                        //#Evg.15 - Internet connection failure (between Listener and SFS Server) or Anesthetic values could not be posted
                        //Action: Listener will not post anesthetic values to SFS server. 
                        //Action: Listener logs the error message locally. (Logging error in catch block)
                        msg = string.Format("<ODAVP-5> On demand anesthetic values could not be posted at : {0}", DateTime.Now.ToString());
                    }
                    LogWriter.WriteToFile(msg, LogHelperUtility.GetLogFileNameForCommonTraceing(DeviceIdentifier.VetLand,
                                                                            startSurgeryMonitor.monitorId.ToString()));

                }
            }
            catch (Exception ex)
            {
                LogWriter.WriteToFile(ex.ToString(), LogHelperUtility.GetLogFileNameForCommonTraceing(DeviceIdentifier.VetLand,
                                                                            startSurgeryMonitor.monitorId.ToString()));
            }
        }
        /// <summary>
        /// Method to ping the device at the frequency of posting the anesthetic values.
        /// </summary>
        /// <param name="startSurgeryMonitor"></param>
        /// <CreatedBy>Om Shakya</CreatedBy>
        /// <CreatedDate>Dec 2016</CreatedDate>
        /// <ModifyBy>...</ModifyBy>
        /// <ModifyDate>...</ModifyDate>
        private static void PingMonitor(StartSurgeryMonitor startSurgeryMonitor)
        {
            try
            {
                ObjectSerializer.SurgeryMonitor monitor = SerializedObjects.GetSurgeryMonitorDevice(startSurgeryMonitor.monitorId);
                if (monitor != null)
                {
                    //PingDeviceHelper.PingMonitorPostSurgeryMonitorStatus(startSurgeryMonitor.monitorId, monitor.monitorIPAddress, DeviceIdentifier.VetLand);


                    bool isPinged = false;
                    PingDeviceHelper.PingMonitorPostSurgeryMonitorStatus(startSurgeryMonitor.monitorId, DeviceIdentifier.VetLand, out isPinged);

                    string msgMonitorPingStatus = string.Empty;
                    SurgeryMonitorStatus.Status status = SurgeryMonitorStatus.Status.ConnectionToMonitorFailed;

                    if (isPinged)
                    {
                        msgMonitorPingStatus = CommonMessages.MonitorConnectedSuccessfully;
                        status = SurgeryMonitorStatus.Status.Active;
                    }
                    else
                    {
                        msgMonitorPingStatus = CommonMessages.MonitorConnectionFailedMsg;
                        status = SurgeryMonitorStatus.Status.ConnectionToMonitorFailed;

                        if (SerializedObjects.SaveMonitorToStopBasedOnStatusCode(startSurgeryMonitor, HttpStatusCode.NotFound, DeviceIdentifier.VetLand))
                        {

                            string msgSaveMonitor = "<PingMonitor-0> Saved Monitor Id : " + startSurgeryMonitor.monitorId.ToString() + " StatusCode : " + "Could not ping" + " Set From : PingMonitor method.";

                            LogWriter.WriteToFile(msgSaveMonitor, LogHelperUtility.GetLogFileNameForCommonTraceing(DeviceIdentifier.VetLand,
                                                                                    startSurgeryMonitor.monitorId.ToString()));
                        }
                    }

                    SurgeryMonitorStatusHelper.PostSurgeryMonitorStatusWithLogInListenerTrace(
                                                                        startSurgeryMonitor.monitorId
                                                                        , msgMonitorPingStatus
                                                                        , DeviceIdentifier.VetLand
                                                                        , status);

                    //Adds log message
                    LogWriter.WriteToFile("<PingMonitor-1> Ping status: " + isPinged.ToString() + " message: " + msgMonitorPingStatus
                                            , LogHelperUtility.GetLogFileNameForCommonTraceing(DeviceIdentifier.VetLand
                                            , startSurgeryMonitor.monitorId.ToString()));
                }
                else
                {
                    LogWriter.WriteToFile("Ping Monitor - Monitor could not be retrived to ping.",
                                            LogHelperUtility.GetLogFileNameForCommonTraceing(DeviceIdentifier.VetLand, startSurgeryMonitor.monitorId.ToString()));
                }
            }
            catch (Exception ex)
            {
                LogWriter.WriteToFile("Ping Monitor - Exception : " + ex.ToString(),
                                        LogHelperUtility.GetLogFileNameForCommonTraceing(DeviceIdentifier.VetLand, startSurgeryMonitor.monitorId.ToString()));
            }
        }
    }
}
