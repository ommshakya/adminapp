﻿using System.IO;
using System.Linq;

namespace SFS.CommonUtilities
{
    /// <summary>
    /// Class to process files on the disk.
    /// </summary>
    /// <CreatedBy>Om Shakya</CreatedBy>
    /// <CreatedDate>Aug 2016</CreatedDate>
    /// <ModifyBy>...</ModifyBy>
    /// <ModifyDate>...</ModifyDate>
    public static class FileProcessorUtility
    {
        /// <summary>
        /// Method to rename the file.
        /// </summary>
        /// <param name="oldfilename"></param>
        /// <param name="newfilename"></param>
        /// <param name="waitforfilelock"></param>
        /// <returns></returns>
        /// <CreatedBy>Om Shakya</CreatedBy>
        /// <CreatedDate>Aug 2016</CreatedDate>
        /// <ModifyBy>...</ModifyBy>
        /// <ModifyDate>...</ModifyDate>
        public static bool RenameFile(string oldfilename, string newfilename, bool waitforfilelock = false)
        {
            bool isFileRemaned = false;
            try
            {
                if (waitforfilelock) System.Threading.Thread.Sleep(1000);
                if (DoesExistsFile(oldfilename) && DoesExistsDirectory(newfilename, true))
                    File.Move(oldfilename, newfilename);
                isFileRemaned = true;
                return isFileRemaned;
            }
            catch
            {
                throw;
            }
        }
        /// <summary>
        /// Method to move the file from one location to another.
        /// </summary>
        /// <param name="sourcefilepath"></param>
        /// <param name="destinationfilepath"></param>
        /// <param name="waitforfilelock"></param>
        /// <returns></returns>
        /// <CreatedBy>Om Shakya</CreatedBy>
        /// <CreatedDate>Aug 2016</CreatedDate>
        /// <ModifyBy>...</ModifyBy>
        /// <ModifyDate>...</ModifyDate>
        public static bool MoveFile(string sourcefilepath, string destinationfilepath, bool waitforfilelock = false)
        {
            try
            {
                return RenameFile(sourcefilepath, destinationfilepath, waitforfilelock);
            }
            catch
            {
                throw;
            }
        }
        /// <summary>
        /// Method to check that the directory exists or not.
        /// </summary>
        /// <param name="path"></param>
        /// <param name="createifnotexists"></param>
        /// <returns></returns>
        /// <CreatedBy>Om Shakya</CreatedBy>
        /// <CreatedDate>Aug 2016</CreatedDate>
        /// <ModifyBy>...</ModifyBy>
        /// <ModifyDate>...</ModifyDate>
        public static bool DoesExistsDirectory(string path, bool createifnotexists = false)
        {
            bool doesExists = false;
            try
            {
                if (!Directory.Exists(Path.GetDirectoryName(path)) && createifnotexists)
                {
                    Directory.CreateDirectory(Path.GetDirectoryName(path));
                    doesExists = true;
                }
                else
                    doesExists = true;
                return doesExists;
            }
            catch
            {
                throw;
            }
        }
        /// <summary>
        /// Method to check that the file exists or not.
        /// </summary>
        /// <param name="filepath"></param>
        /// <param name="createifnotexists"></param>
        /// <CreatedBy>Om Shakya</CreatedBy>
        /// <CreatedDate>Aug 2016</CreatedDate>
        /// <ModifyBy>...</ModifyBy>
        /// <ModifyDate>...</ModifyDate>
        /// <returns></returns>
        public static bool DoesExistsFile(string filepath, bool createifnotexists = false)
        {
            bool doesExistsFile = false;
            try
            {
                if (!File.Exists(filepath) && createifnotexists)
                {
                    using (FileStream fs = File.Create(filepath)) { fs.Close(); }
                    doesExistsFile = true;
                }
                else
                    doesExistsFile = true;
                return doesExistsFile;
            }
            catch
            {
                throw;
            }
        }
        /// <summary>
        /// Method to get all files from the directory.
        /// </summary>
        /// <param name="directory"></param>
        /// <returns></returns>
        /// <CreatedBy>Om Shakya</CreatedBy>
        /// <CreatedDate>Aug 2016</CreatedDate>
        /// <ModifyBy>...</ModifyBy>
        /// <ModifyDate>...</ModifyDate>
        public static string[] GetAllFilesFromDirectory(string directory)
        {
            string[] allFiles = null;
            try
            {
                allFiles = Directory.GetFiles(directory);
                return allFiles;
            }
            catch
            {
                throw;
            }
        }
        /// <summary>
        /// Method to read all lines of a specified file.
        /// </summary>
        /// <param name="file"></param>
        /// <returns></returns>
        /// <CreatedBy>Om Shakya</CreatedBy>
        /// <CreatedDate>Aug 2016</CreatedDate>
        /// <ModifyBy>...</ModifyBy>
        /// <ModifyDate>...</ModifyDate>
        public static string[] ReadLinesOfFile(string file)
        {
            string[] allLines = null;
            try
            {
                if (DoesExistsFile(file))
                    return File.ReadLines(file).ToArray<string>();
                return allLines;
            }
            catch
            {
                throw;
            }
        }
        /// <summary>
        /// Method to delete the file.
        /// </summary>
        /// <param name="fileName"></param>
        /// <returns></returns>
        /// <CreatedBy>Om Shakya</CreatedBy>
        /// <CreatedDate>Aug 2016</CreatedDate>
        /// <ModifyBy>...</ModifyBy>
        /// <ModifyDate>...</ModifyDate>
        public static bool DeleteFile(string fileName)
        {
            bool b = false;
            try
            {
                if (!string.IsNullOrEmpty(fileName))
                {
                    if (DoesExistsFile(fileName))
                    {
                        File.Delete(fileName);
                        b = true;
                    }
                }
            }
            catch
            {
                throw;
            }
            return b;
        }
    }
}