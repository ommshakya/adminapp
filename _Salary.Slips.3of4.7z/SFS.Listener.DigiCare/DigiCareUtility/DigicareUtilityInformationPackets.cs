﻿using SFS.ConfigManager;
using System;
using System.Text;

namespace SFS.Listener.DigiCare.DigiCareUtility
{
    /// <summary>
    /// Digicare Utility Information Packets Class.
    /// </summary>
    /// <CreatedBy>Om Shakya</CreatedBy>
    /// <CreatedDate>Sep 2015</CreatedDate>
    /// <ModifyBy>...</ModifyBy>
    /// <ModifyDate>...</ModifyDate>
    public static class DigicareUtilityInformationPackets
    {
        /// <summary>
        /// Get Info_Admit_Length.
        /// </summary>
        /// <CreatedDate>Aug 2016</CreatedDate>
        /// <ModifyBy>...</ModifyBy>
        /// <ModifyDate>...</ModifyDate>
        public static int Info_Admit_Length
        {
            get { return AppConfigurations.Digicare_Admit_Info_Length; }
        }
        /// <summary>
        /// Get Info_Units_Length.
        /// </summary>
        /// <CreatedDate>Aug 2016</CreatedDate>
        /// <ModifyBy>...</ModifyBy>
        /// <ModifyDate>...</ModifyDate>
        public static int Info_Units_Length
        {
            get { return AppConfigurations.Digicare_Unit_Info_Length; }
        }
        /// <summary>
        /// Method INFO_ADMIT.
        /// </summary>
        /// <returns></returns>
        /// <CreatedDate>Aug 2016</CreatedDate>
        /// <ModifyBy>...</ModifyBy>
        /// <ModifyDate>...</ModifyDate>
        public static byte[] INFO_ADMIT()
        {
            byte[] bytes_Admit_Info = null;
            try
            {
                bytes_Admit_Info = new byte[Info_Admit_Length];
                bytes_Admit_Info[0] = 0xA0;

                //Year
                //20 - 1st part of year 2015
                byte year_part1 = (byte)ushort.Parse(DateTime.Now.Year.ToString().Substring(0, 2));// 20;
                bytes_Admit_Info[1] = year_part1;
                //15 - 2nd part of year 2015
                byte year_part2 = (byte)ushort.Parse(DateTime.Now.Year.ToString().Substring(2, 2));// 20;
                bytes_Admit_Info[2] = year_part2;

                //Month
                byte month = (byte)(DateTime.Now.Month);
                bytes_Admit_Info[3] = month;

                //Day
                byte day = (byte)DateTime.Now.Day;
                bytes_Admit_Info[4] = day;

                //hour
                byte hour = (byte)DateTime.Now.Day;
                bytes_Admit_Info[5] = hour;
                //minute
                byte minute = (byte)DateTime.Now.Minute;
                bytes_Admit_Info[6] = minute;


                //Admit Status -- Discharged : 0x00 Admitted : 0x01
                bytes_Admit_Info[7] = 0x01;

                //ADMIT TYPE -- Horse : 0x01 Dog : 0x02 Puppy : 0x03 Cat : 0x04
                bytes_Admit_Info[8] = 0x02;


                byte[] patient_name = new byte[20];
                patient_name = Encoding.ASCII.GetBytes("doggy");
                patient_name.CopyTo(bytes_Admit_Info, 9);

                byte[] patient_id = new byte[12];
                patient_id = Encoding.ASCII.GetBytes("003");
                patient_id.CopyTo(bytes_Admit_Info, 29);

                //SEX --Male : 0x00 Female :  0x01
                bytes_Admit_Info[41] = 0x00;

                //Date of birth - year
                //20 - 1st part of year 2015
                byte dob_year_part1 = (byte)ushort.Parse(DateTime.Now.Year.ToString().Substring(0, 2));// 20;
                bytes_Admit_Info[42] = dob_year_part1;
                //15 - 2nd part of year 2015
                byte dob_year_part2 = (byte)ushort.Parse(DateTime.Now.Year.ToString().Substring(2, 2));// 20;
                bytes_Admit_Info[43] = dob_year_part2;

                //Date of birth - Month
                byte dob_month = (byte)(DateTime.Now.Month - 1);
                bytes_Admit_Info[44] = dob_month;

                //Date of birth - day
                byte dob_day = (byte)DateTime.Now.Day;
                bytes_Admit_Info[45] = dob_day;



                //Age -- 0x00 : 0year , 0x0f : 127years old
                byte age = 50;
                bytes_Admit_Info[46] = age;

                //Height Unit (Cm , inches) -- 0x00 : Cm , 0x01 : inches
                bytes_Admit_Info[47] = 0x01;

                //Height Value -- Ex) 182.5 43rd byte -> 182 44th byte -> 5
                //130 - 1st part of height 130.0
                byte height_part1 = 182;
                bytes_Admit_Info[48] = height_part1;
                //00 -  2nd part of height 130.0
                byte height_part2 = 5;
                bytes_Admit_Info[49] = height_part2;

                //Weight Unit (Kg , LBS) -- 0x00 : Kg , 0x01 : LBS
                bytes_Admit_Info[50] = 0x01;

                //Weight Value -- Ex) 80.5 46th -> 80 47th -> 5
                //50 - 1st part of 50.0 LBS
                byte weight_part1 = 80;
                bytes_Admit_Info[51] = weight_part1;
                //0 - 2nd part of 50.0 LBS
                byte weight_part2 = 5;
                bytes_Admit_Info[52] = weight_part2;

                //16 - bed number
                byte bed_num = 16;
                bytes_Admit_Info[53] = bed_num;
                return bytes_Admit_Info;
            }
            catch
            {
                throw;
            }
        }
        /// <summary>
        /// Method INFO_UNITS.
        /// </summary>
        /// <returns></returns>
        /// <CreatedDate>Aug 2016</CreatedDate>
        /// <ModifyBy>...</ModifyBy>
        /// <ModifyDate>...</ModifyDate>
        public static byte[] INFO_UNITS()
        {
            byte[] bytes_Setting_Info = null;
            try
            {
                bytes_Setting_Info = new byte[Info_Units_Length];
                bytes_Setting_Info[0] = 0xA1;

                byte NIBPSystolicUnit = 0;
                bytes_Setting_Info[1] = NIBPSystolicUnit;

                byte NIBPDiastolicUnit = 0;
                bytes_Setting_Info[2] = NIBPDiastolicUnit;

                byte NIBPMAPUnit = 0;
                bytes_Setting_Info[3] = NIBPMAPUnit;

                byte IBP2SystolicUnit = 1;
                bytes_Setting_Info[4] = IBP2SystolicUnit;

                byte IBP2DiastolicUnit = 1;
                bytes_Setting_Info[5] = IBP2DiastolicUnit;

                byte IBP2MeanUnit = 1;
                bytes_Setting_Info[6] = IBP2MeanUnit;

                byte CO2EtCO2Unit = 2;
                bytes_Setting_Info[7] = CO2EtCO2Unit;

                byte CO2InsCO2Unit = 2;
                bytes_Setting_Info[8] = CO2InsCO2Unit;

                byte CO2RespUnit = 2;
                bytes_Setting_Info[9] = CO2RespUnit;

                byte Temperature1Unit = 0;
                bytes_Setting_Info[10] = Temperature1Unit;

                byte Temperature2Unit = 0;
                bytes_Setting_Info[11] = Temperature2Unit;

                byte TempDelta = 0;
                bytes_Setting_Info[12] = TempDelta;

                byte bedNum = 16;
                bytes_Setting_Info[13] = bedNum;
                return bytes_Setting_Info;
            }
            catch
            {
                throw;
            }
        }
    }
}
