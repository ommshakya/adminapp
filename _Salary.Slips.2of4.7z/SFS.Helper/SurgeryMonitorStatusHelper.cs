﻿using SFS.CommonUtilities;
using SFS.ConfigManager;
using SFS.FileWritter;
using SFS.HttpClientHelper;
using SFS.ObjectSerializer;
using smartflowsheet.surgery.api.model.objects;
using System;
using System.Net;

namespace SFS.Helper
{
    public static class SurgeryMonitorStatusHelper
    {
        /// <summary>
        /// Method to Post SurgeryMonitorStatus With Log In ListenerTrace.
        /// </summary>
        /// <param name="monitorId"></param>
        /// <param name="message"></param>
        /// <param name="deviceIdentifier"></param>
        /// <param name="status"></param>
        /// <returns></returns>
        public static bool PostSurgeryMonitorStatusWithLogInListenerTrace(Guid monitorId, string message
                                                            , DeviceIdentifier deviceIdentifier
                                                            , SurgeryMonitorStatus.Status status)
        {

            return PostSurgeryMonitorStatusWithLog(monitorId, message, status
                                                    , LogHelperUtility.GetLogFileNameForCommonTraceing(deviceIdentifier
                                                    , monitorId.ToString()));
        }
        /// <summary>
        /// Method to Post SurgeryMonitorStatus With Log In AdminAppTrace.
        /// </summary>
        /// <param name="monitorId"></param>
        /// <param name="message"></param>
        /// <param name="status"></param>
        /// <returns></returns>
        public static bool PostSurgeryMonitorStatusWithLogInAdminAppTrace(Guid monitorId, string message
                                                            , SurgeryMonitorStatus.Status status)
        {

            return PostSurgeryMonitorStatusWithLog(monitorId, message, status
                                                    , LogHelperUtility.GetTraceFileNameForAdminApp());
        }
        /// <summary>
        /// Method to Post SurgeryMonitorStatus With Log.
        /// </summary>
        /// <param name="monitorId"></param>
        /// <param name="message"></param>
        /// <param name="status"></param>
        /// <param name="filePath"></param>
        /// <returns></returns>
        private static bool PostSurgeryMonitorStatusWithLog(Guid monitorId, string message
                                                            , SurgeryMonitorStatus.Status status, string filePath)
        {
            bool result = false;
            try
            {
                if (PostSurgeryMonitorStatus(monitorId, message, status))
                {
                    LogWriter.WriteToFile("SurgeryMonitorStatus posted to SFS Server : " + message, filePath);
                    result = true;
                }
                return result;
            }
            catch 
            {
                throw;
            }
        }
        /// <summary>
        /// Method to Post SurgeryMonitorStatus.
        /// </summary>
        /// <param name="monitorId"></param>
        /// <param name="message"></param>
        /// <param name="status"></param>
        /// <returns></returns>
        private static bool PostSurgeryMonitorStatus(Guid monitorId, string message, SurgeryMonitorStatus.Status status)
        {
            bool result = false;
            HttpStatusCode statusCode = new HttpStatusCode();
            try
            {
                SurgeryMonitorStatus surgeryMonitorStatus = new SurgeryMonitorStatus();
                surgeryMonitorStatus.monitorId = monitorId;
                surgeryMonitorStatus.status = status;
                surgeryMonitorStatus.statusMessage = message;

                statusCode = new APIConnector(AppConfigurations.SFSAPI_Production_URL
                                                , SerializedObjects.SurgeryApiKey
                                                ).PostSurgeryMonitorStatus(surgeryMonitorStatus);

                if (statusCode.Equals(HttpStatusCode.Created) || statusCode.Equals(HttpStatusCode.OK))
                {
                    result = true;
                }
                else
                    throw new Exception(statusCode.ToString());
                return result;
            }
            catch
            {
                throw;
            }
        }
    }
}
