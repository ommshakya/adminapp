﻿using System;

namespace SFS.CommonUtilities
{
    /// <summary>
    /// Class for time interval utility.
    /// </summary>
    /// <CreatedBy>Om Shakya</CreatedBy>
    /// <CreatedDate>Aug 2016</CreatedDate>
    /// <ModifyBy>...</ModifyBy>
    /// <ModifyDate>...</ModifyDate>
    public static class TimeIntervalUtility
    {
        /// <summary>
        /// Method to calculate the next schedule.
        /// </summary>
        /// <param name="surgeryStartDateTime"></param>
        /// <param name="intervalFrequency"></param>
        /// <returns></returns>
        /// <CreatedBy>Om Shakya</CreatedBy>
        /// <CreatedDate>Aug 2016</CreatedDate>
        /// <ModifyBy>...</ModifyBy>
        /// <ModifyDate>...</ModifyDate>
        public static DateTime GetNextSchedule(DateTime? surgeryStartDateTime, double? intervalFrequency)
        {
            DateTime nextSchedule = DateTime.Now;
            double frequency = 1;
            double.TryParse(intervalFrequency.ToString(), out frequency);
            int freqInMiniutes = Convert.ToInt32(frequency) / 60;

            try
            {
                nextSchedule = NextScheduleAlgorithm(surgeryStartDateTime, intervalFrequency);
                if (nextSchedule.TimeOfDay < DateTime.Parse(String.Format("{0:g}", DateTime.Now)).TimeOfDay)
                {
                    while (true)
                    {
                        nextSchedule = nextSchedule.AddMinutes(freqInMiniutes);
                        if (nextSchedule.TimeOfDay >= DateTime.Parse(String.Format("{0:g}", DateTime.Now)).TimeOfDay)
                        {
                            break;
                        }
                    }
                }

                nextSchedule = nextSchedule.AddSeconds(10);
                return nextSchedule;
            }
            catch
            {
                throw;
            }
        }

        private static DateTime NextScheduleAlgorithm(DateTime? surgeryStartDateTime, double? intervalFrequency)
        {
            DateTime nextSchedule = DateTime.Now;
            try
            {
                DateTime startDateFull = DateTime.Parse(String.Format("{0:g}", surgeryStartDateTime));
                double frequency = 1;
                double.TryParse(intervalFrequency.ToString(), out frequency);

                int freqInMiniutes = Convert.ToInt32(frequency) / 60;
                DateTime roundedStartDate = startDateFull;
                DateTime firstStartDate = roundedStartDate;
                nextSchedule = firstStartDate.AddMinutes(freqInMiniutes);

                int neededMin = 0;
                if (freqInMiniutes > 1)
                {
                    if (startDateFull.Minute % freqInMiniutes != 0)
                    {
                        neededMin = (freqInMiniutes * (startDateFull.Minute / freqInMiniutes)) - startDateFull.Minute;
                        roundedStartDate = startDateFull.AddMinutes(neededMin);
                    }
                }
                firstStartDate = roundedStartDate;
                nextSchedule = firstStartDate.AddMinutes(freqInMiniutes);

                return nextSchedule;
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Method to Get Current Interval In Milliseconds.
        /// </summary>
        /// <param name="nextSchedule"></param>
        /// <returns></returns>
        /// <CreatedBy>Om Shakya</CreatedBy>
        /// <CreatedDate>Aug 2016</CreatedDate>
        /// <ModifyBy>...</ModifyBy>
        /// <ModifyDate>...</ModifyDate>
        public static double GetCurrentIntervalInMilliseconds(DateTime nextSchedule)
        {
            double interval = 0;
            try
            {
                interval = (DateTime.Now - DateTime.Parse(nextSchedule.ToString("g"))).TotalMilliseconds;
                if (interval < 0)
                    interval = -interval;

                //Make sure to avoid lag in elapsing the event by adding 5 more seconds
                interval = interval + 5 * 1000;
                return interval;
            }
            catch
            {
                throw;
            }
        }
    }
}
