﻿namespace SFS.Listener.DigiCare.DigiCareUtility
{
    /// <summary>
    /// Digicare Utility Packets Combo Identifier Enumerator.
    /// </summary>
    /// <CreatedBy>Om Shakya</CreatedBy>
    /// <CreatedDate>Sep 2015</CreatedDate>
    /// <ModifyBy>...</ModifyBy>
    /// <ModifyDate>...</ModifyDate>
    public enum DigicarePacketsComboIdentifier
    {
        ADMIT_UNITS_PacketsCombo,
        OBSERVATION_Packet
    }
}
