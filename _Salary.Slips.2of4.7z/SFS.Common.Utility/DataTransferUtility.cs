﻿using SFS.CommonUtilities.Enums;
using SFS.FileWritter;
using smartflowsheet.surgery.api.model.objects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using SFS.HttpClientHelper;
using SFS.ConfigManager;
using smartflowsheet.surgery.api.model.events;

namespace SFS.CommonUtilities
{
    /// <summary>
    /// Class for data transfer to the cloud server.
    /// </summary>
    /// <CreatedBy>Om Shakya</CreatedBy>
    /// <CreatedDate>Aug 2016</CreatedDate>
    /// <ModifyBy>...</ModifyBy>
    /// <ModifyDate>...</ModifyDate>
    public static class DataTransferUtility
    {
        /// <summary>
        /// Method to initiate the data transfer to the cloud server.
        /// </summary>
        /// <param name="hospitalization"></param>
        /// <param name="commonDataSettingTypes"></param>
        /// <param name="dataRequired"></param>
        /// <param name="deviceName"></param>
        /// <param name="monitorId"></param>
        /// <param name="surgeryApiKey"></param>
        /// <CreatedBy>Om Shakya</CreatedBy>
        /// <CreatedDate>Aug 2016</CreatedDate>
        /// <ModifyBy>...</ModifyBy>
        /// <ModifyDate>...</ModifyDate>
        public static HttpStatusCode InitiateDataTransfer(StartSurgeryMonitor startSurgeryMonitor,
                                            CommonDataSettingTypes commonDataSettingTypes,
                                            DeviceIdentifier deviceName,
                                            string monitorId,
                                            string surgeryApiKey)
        {
            HttpStatusCode statusCode = new HttpStatusCode();
            try
            {
                string directory = SettingsUtility.GetCommonDataPath(commonDataSettingTypes, deviceName);
                if (FileProcessorUtility.DoesExistsDirectory(directory))
                    statusCode = TransferDataToServer(directory, startSurgeryMonitor, deviceName, monitorId, surgeryApiKey);
                return statusCode;
            }
            catch
            {
                throw;
            }
        }
        /// <summary>
        /// Method to transfer data to server over cloud.
        /// </summary>
        /// <param name="datadirectory"></param>
        /// <param name="hospitalization"></param>
        /// <param name="dataRequired"></param>
        /// <param name="deviceName"></param>
        /// <param name="monitorId"></param>
        /// <param name="surgeryApiKey"></param>
        /// <CreatedBy>Om Shakya</CreatedBy>
        /// <CreatedDate>Aug 2016</CreatedDate>
        /// <ModifyBy>...</ModifyBy>
        /// <ModifyDate>...</ModifyDate>
        private static HttpStatusCode TransferDataToServer(string datadirectory, StartSurgeryMonitor startSurgeryMonitor
                                                            , DeviceIdentifier deviceName, string monitorId, string surgeryApiKey)
        {
            HttpStatusCode statusCode = new HttpStatusCode();
            try
            {
                statusCode = TransferCurrentData(datadirectory, startSurgeryMonitor, deviceName, monitorId, surgeryApiKey);
                return statusCode;
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Method to transfer current data to the cloud server.
        /// </summary>
        /// <param name="datadirectory"></param>
        /// <param name="hospitalization"></param>
        /// <param name="deviceName"></param>
        /// <param name="monitorId"></param>
        /// <param name="surgeryApiKey"></param>
        /// <CreatedBy>Om Shakya</CreatedBy>
        /// <CreatedDate>Aug 2016</CreatedDate>
        /// <ModifyBy>...</ModifyBy>
        /// <ModifyDate>...</ModifyDate>
        private static HttpStatusCode TransferCurrentData(string datadirectory,
                            StartSurgeryMonitor startSurgeryMonitor
                        , DeviceIdentifier deviceName, string monitorId, string surgeryApiKey)
        {
            HttpStatusCode statusCode = new HttpStatusCode();
            try
            {
                //Retreive the temperature unit setting available on monitor.
                string temperatureUnitOnMonitor = SettingsUtility.ReadMonitorTemperatureUnitSetting(deviceName, monitorId.ToString());

                //Applied the check on the file name while reding the file.
                string[] allFiles = FileProcessorUtility.GetAllFilesFromDirectory(datadirectory).Where(x => x.Contains(monitorId) 
                                    && x.Contains(DateTime.Now.ToString("MMddyyyy"))).ToArray();
                if (allFiles != null && allFiles.Length > 0)
                {
                    string file = allFiles[allFiles.Length - 1];
                    string[] allLines = FileProcessorUtility.ReadLinesOfFile(file);
                    if (allLines != null && allLines.Length > 0)
                    {
                        string currentObservation = allLines[allLines.Length - 1];
                        string[] currentLine = new string[] { currentObservation };

                        List<AnestheticValues> anestheticValues = APIUtility.PrepareListOfAnestheticValues(currentLine, 
                                                                            startSurgeryMonitor, temperatureUnitOnMonitor);

                        statusCode = new APIConnector(
                                                            AppConfigurations.SFSAPI_Production_URL,
                                                            surgeryApiKey
                                                            ).PostAnestheticValues(anestheticValues, deviceName.ToString());

                        //-------------------------------------------------------------
                        //Added below code block to log the Celcius vs. Fahrenhite
                        //Created on 15th Feb 2017
                        string obsPreparedToSend = string.Empty;
                        foreach (AnestheticValues av in anestheticValues)
                        {
                            foreach (AnestheticValue a in av.anestheticValues)
                            {
                                if (!string.IsNullOrEmpty(obsPreparedToSend))
                                    obsPreparedToSend += "|";
                                obsPreparedToSend += a.parameterName + " : " + a.value;
                            }
                        }
                        //-------------------------------------------------------------

                        if (statusCode.Equals(HttpStatusCode.Created) || statusCode.Equals(HttpStatusCode.OK))
                        {
                            LogWriter.WriteToFile(currentObservation + " | Sent: " + obsPreparedToSend, 
                                LogHelperUtility.GetLogFileNameForCommonDataTransfer(deviceName, DataTransferStatus.Sent, monitorId));
                        }
                        else
                        {
                            LogWriter.WriteToFile(currentObservation + " | Failed: " + obsPreparedToSend, 
                                LogHelperUtility.GetLogFileNameForCommonDataTransfer(deviceName, DataTransferStatus.Failed, monitorId));
                        }
                    }
                }
                return statusCode;
            }
            catch
            {
                throw;
            }
        }
    }
}
