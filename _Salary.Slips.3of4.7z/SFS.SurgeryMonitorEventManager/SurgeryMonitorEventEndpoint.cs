﻿using Microsoft.ServiceBus;
using smartflowsheet.surgery.api.model.interfaces;
using System.ServiceModel;

namespace SFS.SurgeryMonitorEventManager
{
    public class SurgeryMonitorEventEndpoint
    {
        private const string ENDPOINT_URI_SCHEME = "sb";

        private static SurgeryMonitorEventEndpoint _instance;
        private static object _lock = new object();
        private ServiceHost _serviceHost = null;

        public static SurgeryMonitorEventEndpoint Instance
        {
            get
            {
                if (_instance == null)
                {
                    lock (_lock)
                    {
                        if (_instance == null)
                        {
                            _instance = new SurgeryMonitorEventEndpoint();
                        }
                    }
                }

                return _instance;
            }
        }

        public void Open(string serviceNamespace, string servicePath, string tokenKeyName, string tokenAccessKey)
        {
            if (_serviceHost != null)
            {
                throw new SurgeryMonitorEventManagerException("Endpoint already in use");
            }

            _serviceHost = new ServiceHost(typeof(SurgeryMonitorManager));
            _serviceHost.AddServiceEndpoint(
                typeof(ISurgeryMonitorManager), new NetTcpRelayBinding(),
                ServiceBusEnvironment.CreateServiceUri(ENDPOINT_URI_SCHEME, serviceNamespace, servicePath)).EndpointBehaviors.Add(
                    new TransportClientEndpointBehavior
                    {
                        TokenProvider = TokenProvider.CreateSharedAccessSignatureTokenProvider(tokenKeyName, tokenAccessKey),
                    }
                );

            _serviceHost.Open();
        }

        public void Close()
        {
            if (_serviceHost != null)
            {
                _serviceHost.Close();
                _serviceHost = null;
            }
        }
    }
}
