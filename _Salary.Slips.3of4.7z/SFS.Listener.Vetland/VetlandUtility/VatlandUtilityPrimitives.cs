﻿namespace SFS.Listener.Vetland.VetlandUtility
{
    /// <summary>
    /// Vetland Utility Primitives class.
    /// </summary>
    public static class VetlandUtilityPrimitives
    {
        public const string REQ_CONNECT_Primitive = "4272";
        public const string FONT_DATA_Primitive = "4046";
    }
}
