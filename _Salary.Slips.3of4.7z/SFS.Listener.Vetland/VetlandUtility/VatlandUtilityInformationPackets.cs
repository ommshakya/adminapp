﻿
using SFS.ConfigManager;

namespace SFS.Listener.Vetland.VetlandUtility
{
    /// <summary>
    /// Vetland Utility Information Packets Class.
    /// </summary>
    /// <CreatedBy>Om Shakya</CreatedBy>
    /// <CreatedDate>Sep 2015</CreatedDate>
    /// <ModifyBy>...</ModifyBy>
    /// <ModifyDate>...</ModifyDate>
    public static class VetlandUtilityInformationPackets
    {
        public static int Font_Data_Length
        {
            get { return AppConfigurations.Vetland_Font_Data_Length; }
        }
    }
}
