﻿using System;

namespace SFS.ObjectSerializer
{
    /// <summary>
    /// SurgeryMonitorEndPoint serialized DTO.
    /// </summary>
    /// <CreatedBy>Om Shakya</CreatedBy>
    /// <CreatedDate>Aug 2016</CreatedDate>
    /// <ModifyBy>...</ModifyBy>
    /// <ModifyDate>...</ModifyDate>
    [Serializable]
    public class SurgeryMonitorEndPoint
    {
        public Guid installationId { get; set; }
        public string objectType { get; set; }
        public string serviceNamespace { get; set; }
        public string servicePath { get; set; }
        public string tokenAccessKey { get; set; }
        public string tokenKeyName { get; set; }
    }
}
