﻿namespace SFS.Listener.Vetland.VetlandUtility
{
    /// <summary>
    /// Vetland Utility Packets Combo Identifier Enumerator.
    /// </summary>
    /// <CreatedBy>Om Shakya</CreatedBy>
    /// <CreatedDate>Sep 2015</CreatedDate>
    /// <ModifyBy>...</ModifyBy>
    /// <ModifyDate>...</ModifyDate>
    public enum VetlandPacketsComboIdentifier
    {
        FONT_DATA_Packet
    }
}
