﻿using smartflowsheet.surgery.api.model.events;
using smartflowsheet.surgery.api.model.objects;
using System;
using System.Collections.Generic;

namespace SFS.HttpClientHelper
{
    /// <summary>
    /// Class for API utility.
    /// </summary>
    /// <CreatedDate>Aug 2016</CreatedDate>
    /// <ModifyBy>...</ModifyBy>
    /// <ModifyDate>...</ModifyDate>
    public class APIUtility
    {
        public const string DataParameterMonitoringTemperature = "Temperature";         // Temp
        public const string DataParameterMonitoringPulse = "Pulse";                     // HR
        public const string DataParameterMonitoringHeartRate = "Heart rate";            // HR
        public const string DataParameterMonitoringRR = "Resp. rate";                   // RR
        public const string DataParameterMonitoringPainScale = "Pain scale";            // Pain
        public const string DataParameterMonitoringBPMap = "BP MAP";                    // MAP
        public const string DataParameterMonitoringBPSys = "BP Sys";                    // SBP
        public const string DataParameterMonitoringBPDias = "BP Dias";                  // DBP
        public const string DataParameterMonitoringIPPV = "IPPV";                       // IPPV
        public const string DataParameterMonitoringSpO2 = "SpO2";                       // SpO2
        public const string DataParameterMonitoringETCO2 = "ETCO2";                     // ETCO2

        public APIUtility() { }
        /// <summary>
        /// Method to prepare list of list of anesthetic value.
        /// </summary>
        /// <param name="linesoffile"></param>
        /// <returns></returns>
        /// <CreatedDate>Aug 2016</CreatedDate>
        /// <ModifyBy>...</ModifyBy>
        /// <ModifyDate>...</ModifyDate>
        private static List<List<AnestheticValue>> PrepareListOfListOfAnestheticValue(string[] linesoffile,
                                                                StartSurgeryMonitor startSurgeryMonitor, string temperatureUnitOnMonitor)
        {
            List<List<AnestheticValue>> listOfListAnestheticValue = new List<List<AnestheticValue>>();
            try
            {
                if (linesoffile != null && linesoffile.Length > 0)
                {
                    foreach (string line in linesoffile)
                    {
                        if (!string.IsNullOrEmpty(line))
                        {
                            List<AnestheticValue> listAnestheticValue = new List<AnestheticValue>();
                            string[] parampair = line.Replace("\t", "|").Split('|');

                            if (parampair != null && parampair.Length > 0)
                            {
                                foreach (string pair in parampair)
                                {
                                    if (!string.IsNullOrEmpty(pair) && pair.Split(':').Length > 0)
                                    {
                                        string param = pair.Trim().Split(':')[0].Trim();
                                        string actualParam = GetParameterName(param);
                                        if (!string.IsNullOrEmpty(actualParam))
                                        {
                                            //Added this below code block to convert the Celcius into Fahrenhite
                                            //Created on 13th Feb 2017
                                            //---------------------------------------------------------
                                            if (actualParam.Equals(DataParameterMonitoringTemperature))
                                            {
                                                if (startSurgeryMonitor.temperatureUnits.Equals(TemperatureUnits.Fahrenheit)
                                                    && !string.IsNullOrEmpty(temperatureUnitOnMonitor) && temperatureUnitOnMonitor.Equals(TemperatureUnits.Celsius.ToString()))
                                                {
                                                    listAnestheticValue.Add(new AnestheticValue()
                                                    {
                                                        parameterName = actualParam,
                                                        value = ConvertToFahrenhite(pair.Trim().Split(':')[1].Trim()).ToString(),
                                                    });
                                                }
                                                else if (startSurgeryMonitor.temperatureUnits.Equals(TemperatureUnits.Celsius)
                                                    && !string.IsNullOrEmpty(temperatureUnitOnMonitor) && temperatureUnitOnMonitor.Equals(TemperatureUnits.Fahrenheit.ToString()))
                                                {
                                                    listAnestheticValue.Add(new AnestheticValue()
                                                    {
                                                        parameterName = actualParam,
                                                        value = ConvertToCelsius(pair.Trim().Split(':')[1].Trim()).ToString(),
                                                    });
                                                }
                                                else
                                                {
                                                    listAnestheticValue.Add(new AnestheticValue()
                                                    {
                                                        parameterName = actualParam,
                                                        value = pair.Trim().Split(':')[1].Trim(),
                                                    });
                                                }
                                            }
                                            //---------------------------------------------------------
                                            else
                                            {
                                                listAnestheticValue.Add(new AnestheticValue()
                                                {
                                                    parameterName = actualParam,
                                                    value = pair.Trim().Split(':')[1].Trim(),
                                                });
                                                if (actualParam.Equals(DataParameterMonitoringHeartRate))
                                                    listAnestheticValue.Add(new AnestheticValue()
                                                    {
                                                        parameterName = DataParameterMonitoringPulse,
                                                        value = pair.Trim().Split(':')[1].Trim(),
                                                    });
                                            }
                                        }
                                    }
                                }
                            }
                            listOfListAnestheticValue.Add(listAnestheticValue);
                        }
                    }
                }
                return listOfListAnestheticValue;
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Method to convert the Celcius into Fahrenhite, Created on 25th Jan 2017
        /// </summary>
        /// <param name="celcius"></param>
        /// <returns></returns>
        private static double ConvertToFahrenhite(string celcius)
        {
            double f = 0;
            try
            {
                double c = 0;
                bool b = double.TryParse(celcius, out c);
                if (b)
                {
                    f = c * 1.8 + 32;
                }
                return f;
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Method to convert the fahrenheit into celsius, Created on 25th Jan 2017
        /// </summary>
        /// <param name="fahrenheit"></param>
        /// <returns></returns>
        private static double ConvertToCelsius(string fahrenheit)
        {
            double c = 0;
            try
            {
                double f = 0;
                bool b = double.TryParse(fahrenheit, out f);
                if (b)
                {
                    c = (f - 32) / 1.8;
                }
                return c;
            }
            catch
            {
                throw;
            }
        }
        /// <summary>
        /// Method to get parameter name.
        /// </summary>
        /// <param name="p"></param>
        /// <returns></returns>
        /// <CreatedDate>Aug 2016</CreatedDate>
        /// <ModifyBy>...</ModifyBy>
        /// <ModifyDate>...</ModifyDate>
        private static string GetParameterName(string p)
        {
            string param = string.Empty;
            try
            {
                switch (p)
                {
                    case "Temp":
                    case "Temp1":
                        param = DataParameterMonitoringTemperature;// Temp
                        break;
                    case "RespRate":
                        param = DataParameterMonitoringRR;// RR
                        break;
                    case "NiBpMeanDataHigh":
                        param = DataParameterMonitoringBPMap;// MAP
                        break;
                    case "NiBpSysDataHigh":
                        param = DataParameterMonitoringBPSys; // SBP
                        break;
                    case "NiBpDiaDataHigh":
                        param = DataParameterMonitoringBPDias;// DBP
                        break;
                    case "SpO2Value":
                        param = DataParameterMonitoringSpO2;// SpO2
                        break;
                    case "EtCO2":
                        param = DataParameterMonitoringETCO2;// ETCO2
                        break;
                    case "HR_HeartRate":
                        param = DataParameterMonitoringHeartRate;// HR
                        break;
                }
                return param;
            }
            catch
            {
                throw;
            }
        }
        /// <summary>
        /// Method to prepare list of anesthetic values.
        /// </summary>
        /// <param name="linesoffile"></param>
        /// <param name="hospitalization"></param>
        /// <returns></returns>
        /// <CreatedDate>Aug 2016</CreatedDate>
        /// <ModifyBy>...</ModifyBy>
        /// <ModifyDate>...</ModifyDate>
        public static List<AnestheticValues> PrepareListOfAnestheticValues(string[] linesoffile, StartSurgeryMonitor startSurgeryMonitor, string temperatureUnitOnMonitor)
        {
            List<AnestheticValues> listAV = new List<AnestheticValues>();
            try
            {
                List<List<AnestheticValue>> listOfListOfAnestheticValue = PrepareListOfListOfAnestheticValue(linesoffile, startSurgeryMonitor, temperatureUnitOnMonitor);
                if (listOfListOfAnestheticValue != null && listOfListOfAnestheticValue.Count > 0)
                {
                    foreach (List<AnestheticValue> listOfAnestheticValue in listOfListOfAnestheticValue)
                    {
                        if (listOfAnestheticValue != null && listOfAnestheticValue.Count > 0)
                        {
                            listAV.Add(new AnestheticValues()
                            {
                                id = DateTime.UtcNow.ToString("yyyyMMddHHmmssfff"),
                                hospitalizationId = startSurgeryMonitor.hospitalizationId,
                                surgeryId = startSurgeryMonitor.surgeryId,
                                date = DateTime.UtcNow,
                                anestheticValues = listOfAnestheticValue,
                            });
                        }
                    }
                }
                return listAV;
            }
            catch
            {
                throw;
            }
        }
    }
}
