﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.NetworkInformation;
using System.Net.Sockets;
using System.Text;

namespace SFS.CommonUtilities
{
    /// <summary>
    /// Class for general utility methods.
    /// </summary>
    /// <CreatedBy>Om Shakya</CreatedBy>
    /// <CreatedDate>Sep 2015</CreatedDate>
    /// <ModifyBy>...</ModifyBy>
    /// <ModifyDate>...</ModifyDate>
    public static class GeneralMethodsUtility
    {
        /// <summary>
        /// Method to Extract Bytes.
        /// </summary>
        /// <param name="bytesSource"></param>
        /// <param name="startIndex"></param>
        /// <param name="lengthOfBytes"></param>
        /// <returns></returns>
        public static byte[] ExtractBytes(byte[] bytesSource, int startIndex, int lengthOfBytes)
        {
            try
            {
                byte[] bytesDestination = new byte[lengthOfBytes];
                Array.Copy(bytesSource, startIndex, bytesDestination, 0, lengthOfBytes);
                return bytesDestination;
            }
            catch
            {
                throw;
            }
        }
        /// <summary>
        /// Method to Prepare Byte From Upper Lower 4bits Values.
        /// </summary>
        /// <param name="upper4bitValue"></param>
        /// <param name="lower4bitValue"></param>
        /// <returns></returns>
        public static byte[] PrepareByteFromUpperLower4bitsValues(ushort upper4bitValue, ushort lower4bitValue)
        {
            try
            {
                byte[] bytes = new byte[1];
                if (upper4bitValue < 16 && lower4bitValue < 16)
                {
                    BitArray baUpper = ConvertUShortToBitsArray(upper4bitValue);
                    BitArray baLower = ConvertUShortToBitsArray(lower4bitValue);

                    BitArray baUpper4Bits = ConvertBitArrayTo4BitArray(baUpper);
                    BitArray baLower4Bits = ConvertBitArrayTo4BitArray(baLower);

                    BitArray bitArray = new BitArray(8);
                    for (int i = 0; i < 4; i++)
                    {
                        bitArray[i] = baUpper4Bits[i];
                    }
                    for (int i = 4; i < 8; i++)
                    {
                        bitArray[i] = baLower4Bits[i - 4];
                    }
                    bitArray.CopyTo(bytes, 0);
                }
                return bytes;
            }
            catch
            {
                throw;
            }
        }
        /// <summary>
        /// Method to Convert Byte Into Hexadecimal.
        /// </summary>
        /// <param name="buffer"></param>
        /// <returns></returns>
        public static string ConvertByteIntoHexadecimal(byte buffer)
        {
            try
            {
                string msgInHex = string.Empty;

                try
                {
                    msgInHex = buffer.ToString("X");
                }
                catch { throw; }

                return msgInHex;
            }
            catch
            {
                throw;
            }
        }
        /// <summary>
        /// Method to Convert Bytes Array Into Hexadecimal.
        /// </summary>
        /// <param name="buffer"></param>
        /// <param name="noOfBytesRead"></param>
        /// <param name="withHyphen"></param>
        /// <returns></returns>
        public static string ConvertBytesArrayIntoHexadecimal(byte[] buffer, int noOfBytesRead, bool withHyphen)
        {
            try
            {
                string msgInHex = string.Empty;

                try
                {
                    if (withHyphen)
                        msgInHex = BitConverter.ToString(buffer, 0, noOfBytesRead);
                    else
                        msgInHex = BitConverter.ToString(buffer, 0, noOfBytesRead).Replace("-", string.Empty);
                }
                catch { throw; }

                return msgInHex;
            }
            catch
            {
                throw;
            }
        }
        /// <summary>
        /// Method to Convert Bit Array To 4Bit Array.
        /// </summary>
        /// <param name="bitarray"></param>
        /// <returns></returns>
        public static BitArray ConvertBitArrayTo4BitArray(BitArray bitarray)
        {
            BitArray bitArray = new BitArray(4);
            try
            {
                if (bitarray.Length < 4)
                {
                    for (int i = 0; i < 4 - bitarray.Length; i++)
                        bitArray[i] = false;

                    int j = 0;
                    for (int i = 4 - bitarray.Length; i < bitArray.Length; i++)
                    {
                        bitArray[i] = bitarray[j];
                        j++;
                    }
                }
                else
                    bitArray = bitarray;
                return bitArray;
            }
            catch
            {
                throw;
            }
        }
        /// <summary>
        /// Method to Convert UShort To Bits Array.
        /// </summary>
        /// <param name="value"></param>
        /// <returns></returns>
        public static BitArray ConvertUShortToBitsArray(ushort value)
        {
            try
            {
                string result = Convert.ToString(value, 2);
                BitArray myBitArray = new BitArray(result.Length);

                int i = 0;
                foreach (char c in result)
                {
                    if (c.Equals('1'))
                        myBitArray[i] = true;
                    else
                        myBitArray[i] = false;
                    i++;
                }
                return myBitArray;
            }
            catch
            {
                throw;
            }
        }
        /// <summary>
        /// Method to Convert Byte Of Upper Lower 4bits To Value.
        /// </summary>
        /// <param name="bytearray"></param>
        /// <param name="atindex"></param>
        /// <param name="separator"></param>
        /// <returns></returns>
        public static string ConvertByteOfUpperLower4bitsToValue(byte[] bytearray, Int16 atindex, char separator)
        {
            try
            {
                byte[] bytes = new byte[1];
                bytes[0] = bytearray[atindex];

                BitArray bitArray = new BitArray(bytes);

                string firts4bits = string.Empty;
                string second4bits = string.Empty;

                for (int i = 0; i < 4; i++)
                {
                    if (bitArray[i])
                        firts4bits += "1";
                    else
                        firts4bits += "0";
                }
                for (int i = 4; i < 8; i++)
                {
                    if (bitArray[i])
                        second4bits += "1";
                    else
                        second4bits += "0";
                }
                string val = Convert.ToUInt16(firts4bits, 2).ToString() + separator + Convert.ToUInt16(second4bits, 2).ToString();
                return val;
            }
            catch
            {
                throw;
            }
        }
        /// <summary>
        /// Method to Concat Byte Values.
        /// </summary>
        /// <param name="bytelist"></param>
        /// <returns></returns>
        public static string ConcatByteValues(params byte[] bytelist)
        {
            string res = string.Empty;
            for (int i = 0; i < bytelist.Length; i++)
            {
                res += string.Concat(Convert.ToInt16(bytelist[i]));
            }
            return res;
        }
        /// <summary>
        /// Method to Convert Two Bytes To Decimal.
        /// </summary>
        /// <param name="byte1"></param>
        /// <param name="byte2"></param>
        /// <returns></returns>
        public static decimal ConvertTwoBytesToDecimal(byte byte1, byte byte2)
        {
            string val = Convert.ToUInt16(byte1).ToString() + "." + Convert.ToUInt16(byte2).ToString();
            return Convert.ToDecimal(val);
        }
        /// <summary>
        /// Method to Convert One Byte To Short.
        /// </summary>
        /// <param name="value"></param>
        /// <returns></returns>
        public static short ConvertOneByteToShort(byte value)
        {
            return Convert.ToInt16(value);
        }
        /// <summary>
        /// Method to Convert One Byte To UShort.
        /// </summary>
        /// <param name="value"></param>
        /// <returns></returns>
        public static ushort ConvertOneByteToUShort(byte value)
        {
            return Convert.ToUInt16(value);
        }
        /// <summary>
        /// Method to Convert Two Bytes To Int16.
        /// </summary>
        /// <param name="value"></param>
        /// <returns></returns>
        public static Int16 ConvertTwoBytesToInt16(byte[] value)
        {
            if (BitConverter.IsLittleEndian) // Added by Chetu on 21 Oct to resolve the error
                Array.Reverse(value);
            return BitConverter.ToInt16(value, 0);
        }

        /// <summary>
        /// Method to Convert Two Bytes To UInt16.
        /// </summary>
        /// <param name="value"></param>
        /// <returns></returns>
        public static UInt16 ConvertTwoBytesToUInt16(byte[] value)
        {
            if (BitConverter.IsLittleEndian) // Added by Chetu on 21 Oct to resolve the error
                Array.Reverse(value);
            return BitConverter.ToUInt16(value, 0);
        }
        /// <summary>
        /// Method to Convert Parsed Packet To String.
        /// </summary>
        /// <param name="dictParsedData"></param>
        /// <param name="separator"></param>
        /// <returns></returns>
        public static string ConvertParsedPacketToString(Dictionary<string, string> dictParsedData, char separator)
        {
            StringBuilder sbr = new StringBuilder();
            try
            {
                foreach (KeyValuePair<string, string> pairPD in dictParsedData)
                {
                    sbr.AppendLine(string.Format(@"{0} {2} {1}", pairPD.Key, pairPD.Value, separator));
                }
                return sbr.ToString();
            }
            catch
            {
                throw;
            }
        }
        /// <summary>
        /// Method to Convert Parsed Packet To String with line break also. Beta Version.
        /// </summary>
        /// <param name="dictParsedData"></param>
        /// <param name="separator"></param>
        /// <returns></returns>
        public static string ConvertParsedPacketToString(Dictionary<string, string> dictParsedData, char separator, char linebreaker)
        {
            StringBuilder sbr = new StringBuilder();
            try
            {
                foreach (KeyValuePair<string, string> pairPD in dictParsedData)
                {
                    if (linebreaker.Equals('|'))
                    {
                        if (!string.IsNullOrEmpty(sbr.ToString()))
                            sbr.Append(linebreaker);
                        sbr.Append(string.Format(@"{0} {2} {1}", pairPD.Key, pairPD.Value, separator));

                    }
                    else
                        sbr.AppendLine(string.Format(@"{0} {2} {1}", pairPD.Key, pairPD.Value, separator));
                }
                return sbr.ToString();
            }
            catch
            {
                throw;
            }
        }
        /// <summary>
        /// Method to generate the new GUID.
        /// </summary>
        /// <returns></returns>
        /// <CreatedBy>Om Shakya</CreatedBy>
        /// <CreatedDate>Aug 2016</CreatedDate>
        /// <ModifyBy>...</ModifyBy>
        /// <ModifyDate>...</ModifyDate>
        public static Guid NewGuid()
        {
            return Guid.NewGuid();
        }
        /// <summary>
        /// Method to validate the IP Address.
        /// </summary>
        /// <param name="ipAddress"></param>
        /// <returns></returns>
        /// <CreatedBy>Om Shakya</CreatedBy>
        /// <CreatedDate>Aug 2016</CreatedDate>
        /// <ModifyBy>...</ModifyBy>
        /// <ModifyDate>...</ModifyDate>
        public static bool IsValidIP(string ipAddress)
        {
            IPAddress unused;
            return IPAddress.TryParse(ipAddress, out unused)
                    &&
                    (
                        unused.AddressFamily != AddressFamily.InterNetwork
                        ||
                        ipAddress.Count(c => c == '.') == 3
                    );
        }
        /// <summary>
        /// Method to automatically detect the IP Address of the machine on the network.
        /// </summary>
        /// <returns></returns>
        /// <CreatedBy>Om Shakya</CreatedBy>
        /// <CreatedDate>Aug 2016</CreatedDate>
        /// <ModifyBy>...</ModifyBy>
        /// <ModifyDate>...</ModifyDate>
        public static IPAddress AutoDetectIPAddress()
        {
            IPAddress ipAddress = IPAddress.Parse("127.0.0.1");
            try
            {

                foreach (var ni in NetworkInterface.GetAllNetworkInterfaces())
                {
                    foreach (var ua in ni.GetIPProperties().UnicastAddresses)
                    {
                        if (ua.Address.AddressFamily == AddressFamily.InterNetwork)
                        {
                            if (!ua.Address.ToString().Equals("127.0.0.1"))
                            {
                                ipAddress = ua.Address;
                                break;
                            }
                        }
                    }
                }
                return ipAddress;
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Method to serialize and write the object in a file.
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="filePath"></param>
        /// <param name="objectToWrite"></param>
        /// <param name="append"></param>
        /// <CreatedBy>Om Shakya</CreatedBy>
        /// <CreatedDate>Aug 2016</CreatedDate>
        /// <ModifyBy>...</ModifyBy>
        /// <ModifyDate>...</ModifyDate>
        public static void WriteToBinaryFile<T>(string filePath, T objectToWrite, bool append = false)
        {
            try
            {
                FileProcessorUtility.DoesExistsDirectory(filePath, true);
                FileProcessorUtility.DoesExistsFile(filePath, true);
                using (Stream stream = File.Open(filePath, append ? FileMode.Append : FileMode.Create))
                {
                    var binaryFormatter = new System.Runtime.Serialization.Formatters.Binary.BinaryFormatter();
                    binaryFormatter.Serialize(stream, objectToWrite);
                }
            }
            catch
            {
                throw;
            }
        }
        /// <summary>
        /// Method to read from file deserialize the object.
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="filePath"></param>
        /// <returns></returns>
        /// <CreatedBy>Om Shakya</CreatedBy>
        /// <CreatedDate>Aug 2016</CreatedDate>
        /// <ModifyBy>...</ModifyBy>
        /// <ModifyDate>...</ModifyDate>
        public static T ReadFromBinaryFile<T>(string filePath)
        {
            using (Stream stream = File.Open(filePath, FileMode.Open))
            {
                var binaryFormatter = new System.Runtime.Serialization.Formatters.Binary.BinaryFormatter();
                return (T)binaryFormatter.Deserialize(stream);
            }
        }
        /// <summary>
        /// Method to validate the email id.
        /// </summary>
        /// <param name="emailId"></param>
        /// <returns></returns>
        /// <CreatedBy>Om Shakya</CreatedBy>
        /// <CreatedDate>Aug 2016</CreatedDate>
        /// <ModifyBy>...</ModifyBy>
        /// <ModifyDate>...</ModifyDate>
        public static bool IsValidEmailId(string emailId)
        {
            try
            {
                string pattern = @"^[a-z][a-z|0-9|]*([_][a-z|0-9]+)*([.][a-z|" +
                           @"0-9]+([_][a-z|0-9]+)*)?@[a-z][a-z|0-9|]*\.([a-z]" +
                           @"[a-z|0-9]*(\.[a-z][a-z|0-9]*)?)$";
                System.Text.RegularExpressions.Match match = System.Text.RegularExpressions.Regex.Match(emailId.Trim(), pattern, System.Text.RegularExpressions.RegexOptions.IgnoreCase);

                if (match.Success)
                    return true;
                else
                    return false;
            }
            catch
            {
                throw;
            }
        }
        /// <summary>
        /// Method to check that if the string has all numeric ones or not.
        /// </summary>
        /// <param name="text"></param>
        /// <returns></returns>
        /// <CreatedBy>Om Shakya</CreatedBy>
        /// <CreatedDate>Aug 2016</CreatedDate>
        /// <ModifyBy>...</ModifyBy>
        /// <ModifyDate>...</ModifyDate>
        public static bool AreAllOnes(string text)
        {
            bool areAllOnes = false;
            int counterOnes = 0;
            try
            {
                if (!string.IsNullOrEmpty(text))
                {
                    char[] chars = text.ToCharArray();
                    for (int counter = 0; counter < chars.Length; counter++)
                    {
                        if (chars[counter].Equals('1'))
                        {
                            counterOnes++;
                        }
                    }
                    if (counterOnes.Equals(chars.Length))
                        areAllOnes = true;
                }
                return areAllOnes;
            }
            catch
            {
                throw;
            }
        }
        /// <summary>
        /// Method to convert the hax string into the byte array.
        /// </summary>
        /// <param name="hexStringWithoutHyphen"></param>
        /// <returns></returns>
        public static byte[] HexStringToByteArray(string hexStringWithoutHyphen)
        {
            if (hexStringWithoutHyphen.Contains('-'))
                hexStringWithoutHyphen.Replace("-", "");

            byte[] retval = new byte[hexStringWithoutHyphen.Length / 2];
            for (int i = 0; i < hexStringWithoutHyphen.Length; i += 2)
                retval[i / 2] = Convert.ToByte(hexStringWithoutHyphen.Substring(i, 2), 16);
            return retval;
        }

        #region Vetland

        /// <summary>
        /// Return packet value with offset and MSB.
        /// </summary>
        /// <param name="value"></param>
        /// <returns></returns>
        public static ushort ConvertDecimalToUInt16(int value)
        {
            int offset = 512;
            // Adding offset 512 in font data. which will be removed at receiving end.
            UInt16 valueWithOffset = Convert.ToUInt16(value + offset);
            string binaryValWithOffset = Convert.ToString(valueWithOffset, 2);
            string ValueWithMSB = Convert.ToInt32(AddMSB(binaryValWithOffset), 2).ToString();
            return Convert.ToUInt16(ValueWithMSB);
        }

        /// <summary>
        /// To add MSB in binary value. and swap lower 8 and upeer 8 bits.
        /// </summary>
        /// <param name="binaryVal"></param>
        /// <returns></returns>
        private static string AddMSB(string binaryVal)
        {
            int binaryValLength = binaryVal.Length;
            char[] BinaryArray = new char[16];
            string ValueWithMSB = string.Empty;
            if (binaryValLength < 16)
            {
                // Process last 8 bits. Assign last 8 bits in array from last last position.
                int k = binaryValLength - 1;
                for (int i = 15; i >= 8; i--)
                {
                    if (i == 8)
                    {
                        BinaryArray[i] = '1';  // Adding MSB in last 8 bits.
                    }
                    else
                    {
                        BinaryArray[i] = binaryVal[k];
                        k--;
                    }

                }
                // process first 8 bits. Process remaing bits of binary value. if remaing bits are not 8 bits then make it 8 bits by adding 0.
                int remainingBitsLen = (binaryValLength >= 8) ? (binaryValLength - 8) : (8 - binaryValLength); //Calculating remaing bits of binary value.
                int remainingStringLength = remainingBitsLen;
                int count = 0;
                for (int i = 7; i >= 0; i--)
                {
                    if (count <= remainingStringLength)
                    {
                        BinaryArray[i] = binaryVal[remainingBitsLen];
                    }
                    else if (i == 0)
                    {
                        BinaryArray[0] = '1'; // Adding MSB in first 8 bits.
                    }
                    else
                    {
                        BinaryArray[i] = '0';
                    }
                    remainingBitsLen--;
                    count++;
                }
                string BinaryValue = new string(BinaryArray);
                ValueWithMSB = BinaryValue.Substring(8, 8) + BinaryValue.Substring(0, 8); //Reversing values, making last 8 bits first and first 8 bits last.
            }
            return ValueWithMSB;
        }

        public static ushort ConvertTwoBytesWithOffsetToUInt16(byte[] value)
        {
            StringBuilder sb = new StringBuilder();
            for (int j = 0; j < value.Length; j++)
            {
                int length = (value.Length - 1) - j;
                string s3 = ConvertByteToBinary(value, length);
                sb.Append(s3);
            }
            string finalValue = Convert.ToInt32(sb.ToString(), 2).ToString();
            return Convert.ToUInt16(finalValue);
        }

        private static string ConvertByteToBinary(byte[] value, int length)
        {
            string result = Convert.ToString(value[length], 2);
            return result.Substring(1);
        }
        #endregion
    }
}
