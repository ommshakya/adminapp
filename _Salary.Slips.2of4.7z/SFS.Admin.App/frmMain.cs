﻿using SFS.CommonServices;
using SFS.CommonUtilities;
using SFS.CommonUtilities.Enums;
using SFS.ConfigManager;
using SFS.FileWritter;
using SFS.ObjectSerializer;
using SFS.SurgeryMonitorEventManager;
using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net;
using System.ServiceProcess;
using System.Windows.Forms;

namespace SFS.Admin.App
{
    public partial class frmMain : Form
    {
        /// <summary>
        /// Constant FirstItemOfDeviceNamesComboBox
        /// </summary>
        private const string FirstItemOfDeviceNamesComboBox = "Select device name";
        /// <summary>
        /// Constructor frmMain
        /// </summary>
        /// <CreatedBy>Om Shakya</CreatedBy>
        /// <CreatedDate>Oct 2016</CreatedDate>
        /// <ModifyBy>...</ModifyBy>
        /// <ModifyDate>...</ModifyDate>
        public frmMain()
        {
            try
            {
                InitializeComponent();
                LoadComboBoxDeviceNames();
                LoadMonitors();
                ManageHelpLink();
                btnUnRegisterApplication.Visible = false;
                CheckApplicationRegistration();

                if (!(SerializedObjects.SurgeryMonitorEndpoint == null))
                {
                    if (WindowServicesUtility.GetWindowServiceStatus(AppConfigurations.WinApp_WindowService_Name).Equals(ServiceControllerStatus.Stopped))
                        WindowServicesUtility.StartWindowService(AppConfigurations.WinApp_WindowService_Name);
                }
            }
            catch (Exception ex)
            {
                LogWriter.WriteToError(ex, LogHelperUtility.GetErrorFileNameForAdminApp());
            }
        }
        /// <summary>
        /// btnRegisterApplication_Click button handler
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// <CreatedBy>Om Shakya</CreatedBy>
        /// <CreatedDate>Oct 2016</CreatedDate>
        /// <ModifyBy>...</ModifyBy>
        /// <ModifyDate>...</ModifyDate>
        private void btnRegisterApplication_Click(object sender, EventArgs e)
        {
            try
            {
                string emailId = string.Empty, password = string.Empty;
                emailId = txtEmailId.Text.Trim();
                password = txtPassword.Text.Trim();

                if (string.IsNullOrEmpty(emailId))
                {
                    MessageBox.Show("Please enter email id!");
                    return;
                }
                /*//Commented by Dev as per request by Pavel
                if (!GeneralMethodsUtility.IsValidEmailId(emailId))
                {
                    MessageBox.Show("Please enter valid email id!");
                    return;
                }
                */
                if (string.IsNullOrEmpty(password))
                {
                    MessageBox.Show("Please enter valid password!");
                    return;
                }

                UserCredentialDTO userCredential = new UserCredentialDTO { emailId = emailId, password = password };
                System.Threading.Thread threadRegisterApplication = new System.Threading.Thread(
                                                new System.Threading.ParameterizedThreadStart(RegisterApplication));
                threadRegisterApplication.Start(userCredential);
            }
            catch (Exception ex)
            {
                LogWriter.WriteToError(ex, LogHelperUtility.GetErrorFileNameForAdminApp());
            }
        }
        /// <summary>
        /// btnUnRegisterApplication_Click button handler
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// <CreatedBy>Om Shakya</CreatedBy>
        /// <CreatedDate>Oct 2016</CreatedDate>
        /// <ModifyBy>...</ModifyBy>
        /// <ModifyDate>...</ModifyDate>
        private void btnUnRegisterApplication_Click(object sender, EventArgs e)
        {
            try
            {
                System.Threading.Thread threadUnRegisterApplication = new System.Threading.Thread(
                                                        new System.Threading.ThreadStart(UnRegisterApplication));
                threadUnRegisterApplication.Start();
            }
            catch (Exception ex)
            {
                LogWriter.WriteToError(ex, LogHelperUtility.GetErrorFileNameForAdminApp());
            }
        }
        /// <summary>
        /// chkShowPassword_CheckedChanged checkbox handler
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// <CreatedBy>Om Shakya</CreatedBy>
        /// <CreatedDate>Oct 2016</CreatedDate>
        /// <ModifyBy>...</ModifyBy>
        /// <ModifyDate>...</ModifyDate>
        private void chkShowPassword_CheckedChanged(object sender, EventArgs e)
        {
            txtPassword.PasswordChar = chkShowPassword.Checked ? '\0' : '*';
        }
        /// <summary>
        /// btnRegisterMonitor_Click button handler
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// <CreatedBy>Om Shakya</CreatedBy>
        /// <CreatedDate>Oct 2016</CreatedDate>
        /// <ModifyBy>...</ModifyBy>
        /// <ModifyDate>...</ModifyDate>
        private void btnRegisterMonitor_Click(object sender, EventArgs e)
        {
            try
            {
                string monitorName = string.Empty, monitorIPAddress = string.Empty, deviceName = string.Empty;
                monitorName = txtMonitorName.Text.Trim();
                monitorIPAddress = txtMonitoIPAddress.Text.Trim();
                deviceName = comboBoxDeviceName.SelectedItem.ToString();
                IPAddress ipAddress;

                if (string.IsNullOrEmpty(monitorName))
                {
                    MessageBox.Show("Please enter valid monitor name!");
                    return;
                }
                if (string.IsNullOrEmpty(monitorIPAddress))
                {
                    MessageBox.Show("Please enter monitor IP Address!");
                    return;
                }
                if (!string.IsNullOrEmpty(monitorIPAddress))
                {
                    if (!IPAddress.TryParse(monitorIPAddress, out ipAddress) ||
                        GeneralMethodsUtility.AreAllOnes(monitorIPAddress) ||
                        monitorIPAddress.Equals("127.0.0.0"))
                    {
                        MessageBox.Show("Please enter valid monitor IP Address!");
                        return;
                    }
                }
                if (string.IsNullOrEmpty(deviceName))
                {
                    MessageBox.Show("Please select device name!");
                    return;
                }
                if (comboBoxDeviceName.SelectedIndex.Equals(0) || deviceName.Equals(FirstItemOfDeviceNamesComboBox))
                {
                    MessageBox.Show("Please select valid device name!");
                    return;
                }
                if (AppConfigurations.AllowDuplicateIP.Equals("No"))
                {
                    List<SurgeryMonitor> allMonitors = SerializedObjects.MonitorsList.OrderBy(x => x.name).ToList();
                    var result = allMonitors.Where(x => x.monitorIPAddress.ToString() == monitorIPAddress);
                    if (result.Count() > 0)
                    {
                        MessageBox.Show("Monitor with same IP is already registered!");
                        return;
                    }
                }
                SurgeryMonitor surgeryMonitorDTO = new SurgeryMonitor();
                surgeryMonitorDTO.name = monitorName;
                surgeryMonitorDTO.monitorIPAddress = IPAddress.Parse(monitorIPAddress);
                surgeryMonitorDTO.deviceName = deviceName;


                System.Threading.Thread threadRegisterMonitor = new System.Threading.Thread(new System.Threading.ParameterizedThreadStart(RegisterMonitor));
                threadRegisterMonitor.Start(surgeryMonitorDTO);
            }
            catch (Exception ex)
            {
                LogWriter.WriteToError(ex, LogHelperUtility.GetErrorFileNameForAdminApp());
            }
        }
        /// <summary>
        /// btnCancelRegisterMonitor_Click button handler
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// <CreatedBy>Om Shakya</CreatedBy>
        /// <CreatedDate>Oct 2016</CreatedDate>
        /// <ModifyBy>...</ModifyBy>
        /// <ModifyDate>...</ModifyDate>
        private void btnCancelRegisterMonitor_Click(object sender, EventArgs e)
        {
            ClearRegisterMonitor();
        }
        /// <summary>
        /// btnUnregisterMonitor_Click button handler
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// <CreatedBy>Om Shakya</CreatedBy>
        /// <CreatedDate>Oct 2016</CreatedDate>
        /// <ModifyBy>...</ModifyBy>
        /// <ModifyDate>...</ModifyDate>
        private void btnUnregisterMonitor_Click(object sender, EventArgs e)
        {
            try
            {
                if (dataGridViewRegisteredMonitors.SelectedRows.Count > 0)
                {
                    string monitorNames = string.Empty;
                    int counter = 0;
                    foreach (DataGridViewRow row in dataGridViewRegisteredMonitors.SelectedRows)
                    {
                        ++counter;
                        monitorNames += row.Cells[2].Value.ToString() + System.Environment.NewLine;
                    }
                    string msg = "Do you want to unregister the following monitor"
                                    + Environment.NewLine
                                    + Environment.NewLine + monitorNames;
                    DialogResult dialogResult = MessageBox.Show(msg, "Unregister the monitors", MessageBoxButtons.YesNo);

                    if (dialogResult.Equals(DialogResult.Yes))
                    {
                        foreach (DataGridViewRow row in dataGridViewRegisteredMonitors.SelectedRows)
                        {
                            string monitorId = row.Cells[3].Value.ToString();
                            ServiceResultDTO result = RegistrationService.UnRegisterMonitor(Guid.Parse(monitorId));
                            if (!result.status.Equals(ServiceResultStatus.Exception))
                            {
                                MessageBox.Show(result.message);
                            }
                        }
                        RefreshMonitorsList();
                    }
                    else
                    {
                        foreach (DataGridViewRow row in dataGridViewRegisteredMonitors.SelectedRows)
                        {
                            row.Selected = false;
                        }
                    }
                }
                else
                {
                    MessageBox.Show("Please select a monitor to unregister!");
                }
            }
            catch (Exception ex)
            {
                LogWriter.WriteToError(ex, LogHelperUtility.GetErrorFileNameForAdminApp());

                //MessageBox.Show("Could not un-register monitor, Please try again!");
                //#Evg.12 - Admin app can't update or delete monitor
                //Action: SFS-server responds with error to Edit/Delete-Monitor-AP;
                //Action: Listener shows error message to user in Admin app
                if (!string.IsNullOrEmpty(ex.Message) && ex.Message.Contains("http://"))
                {
                    //Need to make the url clickable. 
                    //Use the custom MessageBox to display the message.
                    PopupCustomMessage(ex.Message);
                }
                else
                {
                    MessageBox.Show(ex.Message);
                }
                RefreshMonitorsList();
            }
        }
        /// <summary>
        /// dataGridViewRegisteredMonitors_CellClick gridview handler
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// <CreatedBy>Om Shakya</CreatedBy>
        /// <CreatedDate>Oct 2016</CreatedDate>
        /// <ModifyBy>...</ModifyBy>
        /// <ModifyDate>...</ModifyDate>
        private void dataGridViewRegisteredMonitors_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex > -1 && e.ColumnIndex > -1)
            {
                dataGridViewRegisteredMonitors.Rows[e.RowIndex].Selected = true;
            }
        }
        /// <summary>
        /// Method CheckApplicationRegistration
        /// </summary>
        /// <CreatedBy>Om Shakya</CreatedBy>
        /// <CreatedDate>Oct 2016</CreatedDate>
        /// <ModifyBy>...</ModifyBy>
        /// <ModifyDate>...</ModifyDate>
        private void CheckApplicationRegistration()
        {
            try
            {
                if (SerializedObjects.SurgeryMonitorEndpoint == null)
                {
                    grpBoxSignIn.Enabled = true;
                    grpBoxRegisterMonitor.Enabled = false;
                    dataGridViewRegisteredMonitors.Enabled = false;
                    btnUnregisterMonitor.Enabled = false;
                    btnRegisterApplication.Enabled = true;
                    grpBoxSignIn.Location = new Point(grpBoxSignIn.Location.X, 5);
                    grpBoxSignIn.Visible = true;
                    grpBoxRegisterMonitor.Location = new Point(grpBoxRegisterMonitor.Location.X, 129);
                    dataGridViewRegisteredMonitors.Location = new Point(dataGridViewRegisteredMonitors.Location.X, 135);
                    btnUnregisterMonitor.Location = new Point(btnUnregisterMonitor.Location.X, 348);
                }
                else
                {
                    grpBoxSignIn.Enabled = false;
                    grpBoxRegisterMonitor.Enabled = true;
                    dataGridViewRegisteredMonitors.Enabled = true;
                    btnRegisterApplication.Enabled = false;
                    btnUnregisterMonitor.Enabled = true;
                    grpBoxSignIn.Visible = false;
                    grpBoxRegisterMonitor.Location = new Point(grpBoxRegisterMonitor.Location.X, 29);
                    dataGridViewRegisteredMonitors.Location = new Point(dataGridViewRegisteredMonitors.Location.X, 35);
                    btnUnregisterMonitor.Location = new Point(btnUnregisterMonitor.Location.X, 248);
                }
            }
            catch
            {
                throw;
            }
        }
        /// <summary>
        /// Method LoadComboBoxDeviceNames
        /// </summary>
        /// <CreatedBy>Om Shakya</CreatedBy>
        /// <CreatedDate>Oct 2016</CreatedDate>
        /// <ModifyBy>...</ModifyBy>
        /// <ModifyDate>...</ModifyDate>
        private void LoadComboBoxDeviceNames()
        {
            try
            {
                List<string> list = new List<string>();
                foreach (Enum e in Enum.GetValues(typeof(DeviceNames)))
                {
                    list.Add(e.ToString());
                }
                list.Insert(0, FirstItemOfDeviceNamesComboBox);
                comboBoxDeviceName.DataSource = list;
            }
            catch (Exception ex)
            {
                LogWriter.WriteToError(ex, LogHelperUtility.GetErrorFileNameForAdminApp());
                MessageBox.Show("Could not populate the device list drop down list, Please try again!");
            }
        }
        /// <summary>
        /// Method LoadMonitors
        /// </summary>
        /// <CreatedBy>Om Shakya</CreatedBy>
        /// <CreatedDate>Oct 2016</CreatedDate>
        /// <ModifyBy>...</ModifyBy>
        /// <ModifyDate>...</ModifyDate>
        private void LoadMonitors()
        {
            try
            {
                //Set AutoGenerateColumns False
                dataGridViewRegisteredMonitors.AutoGenerateColumns = false;

                //Set Columns Count
                dataGridViewRegisteredMonitors.ColumnCount = 4;

                //Add Columns
                dataGridViewRegisteredMonitors.Columns[0].Name = "deviceName";
                dataGridViewRegisteredMonitors.Columns[0].HeaderText = "Device";
                dataGridViewRegisteredMonitors.Columns[0].DataPropertyName = "deviceName";
                dataGridViewRegisteredMonitors.Columns[0].Width = 60;

                dataGridViewRegisteredMonitors.Columns[1].Name = "IPAddress";
                dataGridViewRegisteredMonitors.Columns[1].HeaderText = "IP Address";
                dataGridViewRegisteredMonitors.Columns[1].DataPropertyName = "monitorIPAddress";
                dataGridViewRegisteredMonitors.Columns[1].Width = 90;

                dataGridViewRegisteredMonitors.Columns[2].Name = "MonitorName";
                dataGridViewRegisteredMonitors.Columns[2].HeaderText = "Monitor Name";
                dataGridViewRegisteredMonitors.Columns[2].DataPropertyName = "name";
                dataGridViewRegisteredMonitors.Columns[2].Width = 178;

                dataGridViewRegisteredMonitors.Columns[3].Name = "MonitorId";
                dataGridViewRegisteredMonitors.Columns[3].HeaderText = "Monitor Id";
                dataGridViewRegisteredMonitors.Columns[3].DataPropertyName = "monitorId";
                dataGridViewRegisteredMonitors.Columns[3].Width = 162;
                dataGridViewRegisteredMonitors.Columns[3].Visible = false;
                dataGridViewRegisteredMonitors.DataSource = SerializedObjects.MonitorsList.OrderBy(x => x.name).ToList();

                dataGridViewRegisteredMonitors.ReadOnly = true;
                dataGridViewRegisteredMonitors.MultiSelect = false;
                dataGridViewRegisteredMonitors.AllowUserToResizeColumns = false;
                dataGridViewRegisteredMonitors.AllowUserToResizeRows = false;
                dataGridViewRegisteredMonitors.RowHeadersWidthSizeMode = DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            }
            catch { throw; }
        }
        /// <summary>
        /// Method RefreshMonitorsList
        /// </summary>
        /// <CreatedBy>Om Shakya</CreatedBy>
        /// <CreatedDate>Oct 2016</CreatedDate>
        /// <ModifyBy>...</ModifyBy>
        /// <ModifyDate>...</ModifyDate>
        private void RefreshMonitorsList()
        {
            try
            {
                dataGridViewRegisteredMonitors.DataSource = SerializedObjects.MonitorsList.OrderBy(x => x.name).ToList();
                dataGridViewRegisteredMonitors.FirstDisplayedScrollingRowIndex = dataGridViewRegisteredMonitors.RowCount - 1;
            }
            catch { throw; }
        }
        /// <summary>
        /// Method ClearRegisterMonitor
        /// </summary>
        /// <CreatedBy>Om Shakya</CreatedBy>
        /// <CreatedDate>Oct 2016</CreatedDate>
        /// <ModifyBy>...</ModifyBy>
        /// <ModifyDate>...</ModifyDate>
        private void ClearRegisterMonitor()
        {
            txtMonitorName.Text = string.Empty;
            txtMonitoIPAddress.Text = string.Empty;
            comboBoxDeviceName.SelectedIndex = 0;
        }
        /// <summary>
        /// Method ClearSignIn
        /// </summary>
        /// <CreatedBy>Om Shakya</CreatedBy>
        /// <CreatedDate>Oct 2016</CreatedDate>
        /// <ModifyBy>...</ModifyBy>
        /// <ModifyDate>...</ModifyDate>
        private void ClearSignIn()
        {
            txtEmailId.Text = string.Empty;
            txtPassword.Text = string.Empty;
            chkShowPassword.Checked = false;
        }
        /// <summary>
        /// Method RegisterMonitor
        /// </summary>
        /// <param name="obj"></param>
        /// <CreatedBy>Om Shakya</CreatedBy>
        /// <CreatedDate>Oct 2016</CreatedDate>
        /// <ModifyBy>...</ModifyBy>
        /// <ModifyDate>...</ModifyDate>
        private void RegisterMonitor(object obj)
        {
            try
            {
                SurgeryMonitor surgeryMonitorDTO = (SurgeryMonitor)obj;

                ServiceResultDTO result = RegistrationService.RegisterMonitor(surgeryMonitorDTO);
                if (result != null)
                {
                    MessageBox.Show(result.message);
                }
                this.Invoke(new MethodInvoker(ClearRegisterMonitor));
                this.Invoke(new MethodInvoker(RefreshMonitorsList));
            }
            catch (Exception ex)
            {
                LogWriter.WriteToError(ex, LogHelperUtility.GetErrorFileNameForAdminApp());
                //MessageBox.Show("Could not register monitor, Please try again!");

                //#Evg.12 - Admin app can't update or delete monitor
                //Action: SFS-server responds with error to Edit/Delete-Monitor-AP;
                //Action: Listener shows error message to user in Admin app
                if (!string.IsNullOrEmpty(ex.Message) && ex.Message.Contains("http://"))
                {
                    //Need to make the url clickable. 
                    //Use the custom MessageBox to display the message.
                    PopupCustomMessage(ex.Message);
                }
                else
                {
                    MessageBox.Show(ex.Message);
                }

                this.Invoke(new MethodInvoker(ClearRegisterMonitor));
                this.Invoke(new MethodInvoker(RefreshMonitorsList));
            }
        }
        /// <summary>
        /// Method RegisterApplication
        /// </summary>
        /// <param name="obj"></param>
        /// <CreatedBy>Om Shakya</CreatedBy>
        /// <CreatedDate>Oct 2016</CreatedDate>
        /// <ModifyBy>...</ModifyBy>
        /// <ModifyDate>...</ModifyDate>
        private void RegisterApplication(object obj)
        {
            try
            {
                UserCredentialDTO userCredential = (UserCredentialDTO)obj;
                ServiceResultDTO result = RegistrationService.RegisterApplication(userCredential);

                if (result != null)
                {
                    try
                    {
                        if (result != null && result.status.Equals(ServiceResultStatus.Success))
                        {
                            System.Threading.Thread.Sleep(5 * 1000);
                            WindowServicesUtility.StartWindowService(AppConfigurations.WinApp_WindowService_Name);
                        }
                    }
                    catch (Exception ex)
                    {
                        LogWriter.WriteToError(ex, LogHelperUtility.GetErrorFileNameForAdminApp());
                        throw;
                    }

                    if (!result.status.Equals(ServiceResultStatus.Exception))
                    {
                        //Download monitors and create the files for each monitor
                        RegistrationService.DownloadMonitorsAndSaveLocally();
                        MessageBox.Show(result.message);
                    }

                    this.Invoke(new MethodInvoker(ClearSignIn));
                    this.Invoke(new MethodInvoker(CheckApplicationRegistration));
                    this.Invoke(new MethodInvoker(RefreshMonitorsList));
                }
            }
            catch (Exception ex)
            {
                LogWriter.WriteToError(ex, LogHelperUtility.GetErrorFileNameForAdminApp());

                if (!string.IsNullOrEmpty(ex.Message) && ex.Message.Contains("http://"))
                {
                    //#Evg.21 - Installion failed - Admin app already installed
                    //Action: SFS - server responds with error to Account - API(surgery / account / install);
                    //Action: Admin app show error message
                    //Need to make the url clickable. 
                    //Use the custom MessageBox to display the message.
                    PopupCustomMessage(ex.Message);
                }
                else
                {
                    //#Evg.20 - Installation failed - Wrong login / password or account is not primary
                    //Action: SFS-server responds with error to Account-API (surgery/account);
                    //Action: Admin app show error message
                    MessageBox.Show(ex.Message);
                }

                this.Invoke(new MethodInvoker(ClearSignIn));
            }
        }
        /// <summary>
        /// Method UnRegisterApplication
        /// </summary>
        /// <CreatedBy>Om Shakya</CreatedBy>
        /// <CreatedDate>Oct 2016</CreatedDate>
        /// <ModifyBy>...</ModifyBy>
        /// <ModifyDate>...</ModifyDate>
        public void UnRegisterApplication()
        {
            try
            {
                SurgeryMonitorEventEndpoint.Instance.Close();

                ServiceResultDTO result = RegistrationService.UnRegisterApplication();

                if (result != null)
                {
                    if (result.status.Equals(ServiceResultStatus.Success))
                    {
                        try
                        {
                            WindowServicesUtility.StopWindowService(AppConfigurations.WinApp_WindowService_Name);
                        }
                        catch (Exception ex)
                        {
                            LogWriter.WriteToError(ex, LogHelperUtility.GetErrorFileNameForAdminApp());
                        }
                    }

                    if (!result.status.Equals(ServiceResultStatus.Exception))
                    {
                        MessageBox.Show(result.message);
                        this.Invoke(new MethodInvoker(CheckApplicationRegistration));
                        this.Invoke(new MethodInvoker(RefreshMonitorsList));
                    }
                }
            }
            catch (Exception ex)
            {
                LogWriter.WriteToError(ex, LogHelperUtility.GetErrorFileNameForAdminApp());

                if (!string.IsNullOrEmpty(ex.Message) && ex.Message.Contains("http://"))
                {
                    //#Evg.22 - Installion failed - Admin app already installed
                    //Action: SFS - server responds with error to Account - API(surgery / account / install);
                    //Action: Admin app show error message
                    //Need to make the url clickable. 
                    //Use the custom MessageBox to display the message.
                    PopupCustomMessage(ex.Message);
                }
                else
                {
                    //Any other error
                    MessageBox.Show(ex.Message);
                }
            }
        }
        /// <summary>
        /// Method to show the custom message.
        /// </summary>
        /// <param name="message"></param>
        /// <CreatedBy>Om Shakya</CreatedBy>
        /// <CreatedDate>Jan 2017</CreatedDate>
        /// <ModifyBy>...</ModifyBy>
        /// <ModifyDate>...</ModifyDate>
        private void PopupCustomMessage(string message)
        {
            try
            {
                string splitter = "http:";
                string[] msgParts = message.Split(new string[] { splitter }, StringSplitOptions.None);
                if (msgParts.Length > 1)
                {
                    string txtMsg = msgParts[0];
                    string urlMsg = splitter + msgParts[1];

                    GenerateCustomMessageBox(txtMsg, urlMsg);
                }
            }
            catch { throw; }
        }
        /// <summary>
        /// Method to create the custom message.
        /// </summary>
        /// <param name="msg"></param>
        /// <param name="url"></param>
        /// <CreatedBy>Om Shakya</CreatedBy>
        /// <CreatedDate>Jan 2017</CreatedDate>
        /// <ModifyBy>...</ModifyBy>
        /// <ModifyDate>...</ModifyDate>
        private void GenerateCustomMessageBox(string msg, string url)
        {
            try
            {
                //Note: This object can not be disposed, if it is disposed application will break.
                Label labelMsg = new Label();
                labelMsg.Text = msg;
                labelMsg.Size = new Size(325, 55);
                labelMsg.Location = new Point(10, 10);

                //Note: This object can not be disposed, if it is disposed application will break.
                LinkLabel linkLabelUrl = new LinkLabel();
                linkLabelUrl.Text = url;
                linkLabelUrl.LinkClicked += new LinkLabelLinkClickedEventHandler(LinkedLabelUrl_Clicked);
                linkLabelUrl.AutoSize = true;
                linkLabelUrl.Location = new Point(10, 70);

                //Note: This object can not be disposed, if it is disposed application will break.
                Button buttonOk = new Button();
                buttonOk.Text = "OK";
                buttonOk.Click += ButtonOk_Click;
                buttonOk.Location = new Point(260, 95);

                //Note: This object can not be disposed, if it is disposed application will break.
                Form formMsgBox = new Form();
                formMsgBox.ShowIcon = false;
                formMsgBox.MinimizeBox = false;
                formMsgBox.MaximizeBox = false;
                formMsgBox.Padding = new Padding(10);

                formMsgBox.Controls.Add(labelMsg);
                formMsgBox.Controls.Add(linkLabelUrl);
                formMsgBox.Controls.Add(buttonOk);

                formMsgBox.Size = new Size(360, 170);
                formMsgBox.FormBorderStyle = FormBorderStyle.FixedDialog;
                formMsgBox.StartPosition = FormStartPosition.CenterScreen;

                formMsgBox.ShowDialog();
            }
            catch { throw; }
        }
        /// <summary>
        /// Handler for OK button click event.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// <CreatedBy>Om Shakya</CreatedBy>
        /// <CreatedDate>Jan 2017</CreatedDate>
        /// <ModifyBy>...</ModifyBy>
        /// <ModifyDate>...</ModifyDate>
        private void ButtonOk_Click(object sender, EventArgs e)
        {
            try
            {
                Button buttonOk = (Button)sender;
                Form formMsgBox = (Form)buttonOk.Parent;
                formMsgBox.Close();
            }
            catch (Exception ex)
            {
                LogWriter.WriteToError(ex, LogHelperUtility.GetErrorFileNameForAdminApp());
            }
        }
        /// <summary>
        /// Handler for url linked label button click.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// <CreatedBy>Om Shakya</CreatedBy>
        /// <CreatedDate>Jan 2017</CreatedDate>
        /// <ModifyBy>...</ModifyBy>
        /// <ModifyDate>...</ModifyDate>
        private void LinkedLabelUrl_Clicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            try
            {
                LinkLabel LinkLabel = (LinkLabel)sender;
                System.Diagnostics.Process.Start(LinkLabel.Text);
            }
            catch (Exception ex)
            {
                LogWriter.WriteToError(ex, LogHelperUtility.GetErrorFileNameForAdminApp());
            }
        }
        /// <summary>
        /// Manage the help link here.
        /// </summary>
        private void ManageHelpLink()
        {
            try
            {
                LinkLabel.Link link = new LinkLabel.Link();
                string currentPath = Application.StartupPath;
                currentPath = Path.Combine(currentPath, "Documents\\Surgery Admin Help.pdf");
                if (!System.IO.File.Exists(currentPath))
                    if (FileProcessorUtility.DoesExistsDirectory(currentPath, true))
                    {
                        string localFile = Path.Combine(Application.StartupPath, "Surgery Admin Help.pdf");
                        System.IO.File.Copy(localFile, currentPath);
                    }

                link.LinkData = currentPath;
                linkHelp.Links.Add(link);

                //Note: This object can not be disposed, if it is disposed application will break.
                ToolTip toolTip = new ToolTip();
                toolTip.SetToolTip(this.linkHelp, AppConfigurations.WinApp_Help_Tooltip_Text);
            }
            catch (Exception ex)
            {
                LogWriter.WriteToError(ex, LogHelperUtility.GetErrorFileNameForAdminApp());
            }
        }
        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            try
            {
                System.Diagnostics.Process.Start(e.Link.LinkData as string);
            }
            catch (Exception ex)
            {
                LogWriter.WriteToError(ex, LogHelperUtility.GetErrorFileNameForAdminApp());
            }
        }
    }
}
