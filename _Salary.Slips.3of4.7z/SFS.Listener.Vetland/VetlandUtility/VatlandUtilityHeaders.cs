﻿namespace SFS.Listener.Vetland.VetlandUtility
{
    /// <summary>
    /// Vetland Utility Headers Class.
    /// </summary>
    /// <CreatedBy>Om Shakya</CreatedBy>
    /// <CreatedDate>Sep 2015</CreatedDate>
    /// <ModifyBy>...</ModifyBy>
    /// <ModifyDate>...</ModifyDate>
    public static class VetlandUtilityHeaders
    {
        public static string REQ_CONNECT_Header { get { return "42"; } }
        public static string FONT_DATA_Header { get { return "40"; } }
    }
}
