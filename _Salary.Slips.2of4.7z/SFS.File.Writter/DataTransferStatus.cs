﻿namespace SFS.FileWritter
{
    /// <summary>
    /// Enum for data transfer status.
    /// </summary>
    /// <CreatedDate>Aug 2016</CreatedDate>
    /// <ModifyBy>...</ModifyBy>
    /// <ModifyDate>...</ModifyDate>
    public enum DataTransferStatus
    {
        Failed,
        Sent
    }
}
