﻿namespace SFS.Listener.BioNet.BioNetUtility
{
    /// <summary>
    /// BioNet Utility Packets Combo Identifier Enumerator.
    /// </summary>
    /// <CreatedBy>Om Shakya</CreatedBy>
    /// <CreatedDate>Sep 2015</CreatedDate>
    /// <ModifyBy>...</ModifyBy>
    /// <ModifyDate>...</ModifyDate>
    public enum BioNetPacketsComboIdentifier
    {
        USER_ADMIT_ALARM_SETTING_PacketsCombo,
        SETTING_PARAM_PacketsCombo
    }
}
