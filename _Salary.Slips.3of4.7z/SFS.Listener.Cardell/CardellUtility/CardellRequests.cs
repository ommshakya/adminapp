﻿namespace SFS.Listener.Cardell.CardellUtility
{
    public static class CardellRequests
    {
        /// <summary>
        /// Get CONNECT_REQ_HeaderPrimitive
        /// </summary>
        /// <CreatedBy>Om Shakya</CreatedBy>
        /// <CreatedDate>Oct 2016</CreatedDate>
        /// <ModifyBy>...</ModifyBy>
        /// <ModifyDate>...</ModifyDate>
        public static string CONNECT_REQ_HeaderPrimitive
        {
            get
            {
                return string.Concat("BBBB", "09");
            }
        }
        /// <summary>
        /// Get CONNECT_REQ_HeaderHeartbeat
        /// </summary>
        /// <CreatedBy>Om Shakya</CreatedBy>
        /// <CreatedDate>Oct 2016</CreatedDate>
        /// <ModifyBy>...</ModifyBy>
        /// <ModifyDate>...</ModifyDate>
        public static string CONNECT_REQ_HeaderHeartbeat
        {
            get
            {
                return string.Concat("BBBB", "08");
            }
        }
        /// <summary>
        /// Get CONNECT_ACCEPT_HeaderHeartbeat
        /// </summary>
        /// <CreatedBy>Om Shakya</CreatedBy>
        /// <CreatedDate>Oct 2016</CreatedDate>
        /// <ModifyBy>...</ModifyBy>
        /// <ModifyDate>...</ModifyDate>
        public static string CONNECT_ACCEPT_HeaderHeartbeat
        {
            get
            {
                return string.Concat("BBBB", "06");
            }
        }
        /// <summary>
        /// Get CONNECT_ACCEPT_HeaderPrimitive
        /// </summary>
        /// <CreatedBy>Om Shakya</CreatedBy>
        /// <CreatedDate>Oct 2016</CreatedDate>
        /// <ModifyBy>...</ModifyBy>
        /// <ModifyDate>...</ModifyDate>
        public static string CONNECT_ACCEPT_HeaderPrimitive
        {
            get
            {
                return string.Concat("BBBB", "0A");
            }
        }
        /// <summary>
        /// Get DISCONNECT_REQ_HeaderPrimitive
        /// </summary>
        /// <CreatedBy>Om Shakya</CreatedBy>
        /// <CreatedDate>Oct 2016</CreatedDate>
        /// <ModifyBy>...</ModifyBy>
        /// <ModifyDate>...</ModifyDate>
        public static string DISCONNECT_REQ_HeaderPrimitive
        {
            get
            {
                return string.Concat("C0", "03");
            }
        }
        /// <summary>
        /// Get DATA_ACK_HeaderPrimitive
        /// </summary>
        /// <CreatedBy>Om Shakya</CreatedBy>
        /// <CreatedDate>Oct 2016</CreatedDate>
        /// <ModifyBy>...</ModifyBy>
        /// <ModifyDate>...</ModifyDate>
        public static string DATA_ACK_HeaderPrimitive
        {
            get
            {
                return string.Concat("D2", "01");
            }
        }
    }
}
