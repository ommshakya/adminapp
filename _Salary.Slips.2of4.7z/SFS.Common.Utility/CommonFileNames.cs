﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SFS.CommonUtilities
{
    public static class CommonFileNames
    {
        public static string SurgeryApiKey_FileName = "SFS.SurgeryApiKey.sfs";
        public static string SurgeryMonitorEndPointSimulator_FileName = "SFS.SurgeryMonitorEndPointSimulator.sfs";
    }
}
