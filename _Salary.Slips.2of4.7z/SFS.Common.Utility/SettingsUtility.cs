﻿using SFS.CommonUtilities.Enums;
using SFS.ConfigManager;
using SFS.FileWritter;
using System;
using System.IO;

namespace SFS.CommonUtilities
{
    /// <summary>
    /// Class for application configuration settings utility.
    /// </summary>
    /// <CreatedBy>Om Shakya</CreatedBy>
    /// <CreatedDate>Aug 2016</CreatedDate>
    /// <ModifyBy>...</ModifyBy>
    /// <ModifyDate>...</ModifyDate>
    public static class SettingsUtility
    {
        private static string SpecialFolder = Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData);
        private static string ApplicationFolder = "SmartFlowSheet";

        /// <summary>
        /// Method to get common data path. Note: If new file or folder setting is configured, add a case in this method.
        /// </summary>
        /// <param name="commonDataEnum"></param>
        /// <param name="deviceName"></param>
        /// <param name="monitorId"></param>
        /// <returns></returns>
        /// <CreatedBy>Om Shakya</CreatedBy>
        /// <CreatedDate>Aug 2016</CreatedDate>
        /// <ModifyBy>...</ModifyBy>
        /// <ModifyDate>...</ModifyDate>
        public static string GetCommonDataPath_Original(CommonDataSettingTypes commonDataEnum, DeviceIdentifier deviceName, string monitorId = "only for specific calls")
        {
            string path = string.Empty;
            try
            {
                string commonAppData = Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData);

                string basefolder_for_device = string.Empty;
                if (!deviceName.Equals(DeviceIdentifier.None))
                    basefolder_for_device = "\\" + deviceName.ToString() + "\\";

                switch (commonDataEnum)
                {
                    case CommonDataSettingTypes.None:
                        path = string.Empty;
                        break;
                    case CommonDataSettingTypes.Base_Folder:
                        path = commonAppData + "\\" + AppConfigurations.WinApp_Settings_BaseFolderName + basefolder_for_device;
                        break;
                    case CommonDataSettingTypes.DataContainer_Folder:
                        path = GetCommonDataPath(CommonDataSettingTypes.Base_Folder, deviceName) + "\\"
                                + AppConfigurations.WinApp_Settings_DataContainer_FolderName + "\\";
                        break;
                    case CommonDataSettingTypes.ServiceBusEndPoint:
                        path = GetCommonDataPath(CommonDataSettingTypes.Base_Folder, deviceName) + "\\";
                        break;
                    case CommonDataSettingTypes.SurgeryApiKey:
                        path = GetCommonDataPath(CommonDataSettingTypes.Base_Folder, deviceName) + "\\";
                        break;
                    case CommonDataSettingTypes.AdminApp:
                        path = GetCommonDataPath(CommonDataSettingTypes.Base_Folder, deviceName) + "\\";
                        break;
                    case CommonDataSettingTypes.LiveDataFile_Folder:
                        path = GetCommonDataPath(CommonDataSettingTypes.DataContainer_Folder, deviceName) + "\\"
                                         + AppConfigurations.WinApp_Settings_LiveData_FolderName + "\\";
                        break;
                    case CommonDataSettingTypes.PendingDataFiles_Folder:
                        path = GetCommonDataPath(CommonDataSettingTypes.DataContainer_Folder, deviceName) + "\\"
                                         + AppConfigurations.WinApp_Settings_PendingDataFiles_FolderName + "\\";
                        break;
                    case CommonDataSettingTypes.SentDataFiles_Folder:
                        path = GetCommonDataPath(CommonDataSettingTypes.DataContainer_Folder, deviceName) + "\\"
                                         + AppConfigurations.WinApp_Settings_SentDataFiles_FolderName + "\\";
                        break;
                    case CommonDataSettingTypes.FailedDataFiles_Folder:
                        path = GetCommonDataPath(CommonDataSettingTypes.DataContainer_Folder, deviceName) + "\\"
                                        + AppConfigurations.WinApp_Settings_FailedDataFiles_FolderName + "\\";
                        break;
                    case CommonDataSettingTypes.SettingsContainer_Folder:
                        path = GetCommonDataPath(CommonDataSettingTypes.Base_Folder, deviceName) + "\\"
                                         + AppConfigurations.WinApp_Settings_SettingsContainer_FolderName + "\\";
                        break;
                    case CommonDataSettingTypes.Disconnect_File:
                        path = GetCommonDataPath(CommonDataSettingTypes.SettingsContainer_Folder, deviceName) + "\\"
                                         + AppConfigurations.WinApp_Settings_Disconnect_FileName + "." + monitorId + ".sfs";
                        break;
                }
                return path;
            }
            catch
            {
                throw;
            }
        }
        /// <summary>
        /// Method to GetBaseFolder.
        /// </summary>
        /// <param name="deviceIdentifier"></param>
        /// <returns></returns>
        private static string GetBaseFolder(DeviceIdentifier deviceIdentifier)
        {
            return SpecialFolder + "\\" + ApplicationFolder + "\\" + deviceIdentifier.ToString() + "\\";
        }
        /// <summary>
        /// Method to GetDataContainerFolder.
        /// </summary>
        /// <param name="deviceIdentifier"></param>
        /// <returns></returns>
        private static string GetDataContainerFolder(DeviceIdentifier deviceIdentifier)
        {
            return GetBaseFolder(deviceIdentifier) + "\\" + "Data" + "\\"; ;
        }
        /// <summary>
        /// Method to GetSettingsContainerFolder.
        /// </summary>
        /// <param name="deviceIdentifier"></param>
        /// <returns></returns>
        private static string GetSettingsContainerFolder(DeviceIdentifier deviceIdentifier)
        {
            return GetBaseFolder(deviceIdentifier) + "\\" + "Settings" + "\\"; ;
        }
        /// <summary>
        /// Method to GetListenerLogContainerFolder.
        /// </summary>
        /// <param name="deviceIdentifier"></param>
        /// <returns></returns>
        private static string GetListenerLogContainerFolder(DeviceIdentifier deviceIdentifier)
        {
            return GetBaseFolder(deviceIdentifier) + "\\" + "ListenerLog" + "\\"; ;
        }
        /// <summary>
        /// Method to GetSimulatorLogContainerFolder.
        /// </summary>
        /// <param name="deviceIdentifier"></param>
        /// <returns></returns>
        private static string GetSimulatorLogContainerFolder(DeviceIdentifier deviceIdentifier)
        {
            return GetBaseFolder(deviceIdentifier) + "\\" + "SimulatorLog" + "\\"; ;
        }
        /// <summary>
        /// Method to Get Common Data Path.
        /// </summary>
        /// <param name="commonDataEnum"></param>
        /// <param name="deviceIdentifier"></param>
        /// <param name="monitorId"></param>
        /// <returns></returns>
        public static string GetCommonDataPath(CommonDataSettingTypes commonDataEnum, DeviceIdentifier deviceIdentifier, string monitorId = "only for specific calls")
        {
            string path = string.Empty;
            try
            {
                switch (commonDataEnum)
                {
                    case CommonDataSettingTypes.ServiceBusEndPoint:
                        path = GetBaseFolder(deviceIdentifier) + "\\";
                        break;
                    case CommonDataSettingTypes.SurgeryApiKey:
                        path = GetBaseFolder(deviceIdentifier) + "\\";
                        break;
                    case CommonDataSettingTypes.AdminApp:
                        path = GetBaseFolder(deviceIdentifier) + "\\";
                        break;
                    case CommonDataSettingTypes.DataContainer_Folder:
                        path = GetDataContainerFolder(deviceIdentifier) + "\\";
                        break;
                    case CommonDataSettingTypes.ListenerLogContainer_Folder:
                        path = GetListenerLogContainerFolder(deviceIdentifier) + "\\";
                        break;
                    case CommonDataSettingTypes.SimulatorLogContainer_Folder:
                        path = GetSimulatorLogContainerFolder(deviceIdentifier) + "\\";
                        break;
                    case CommonDataSettingTypes.SettingsContainer_Folder:
                        path = GetSettingsContainerFolder(deviceIdentifier) + "\\";
                        break;
                    case CommonDataSettingTypes.LiveDataFile_Folder:
                        path = GetDataContainerFolder(deviceIdentifier) + "\\" + "LiveData" + "\\";
                        break;
                    case CommonDataSettingTypes.PendingDataFiles_Folder:
                        path = GetDataContainerFolder(deviceIdentifier) + "\\" + "PendingData" + "\\";
                        break;
                    case CommonDataSettingTypes.SentDataFiles_Folder:
                        path = GetDataContainerFolder(deviceIdentifier) + "\\" + "SentDataFiles" + "\\";
                        break;
                    case CommonDataSettingTypes.FailedDataFiles_Folder:
                        path = GetDataContainerFolder(deviceIdentifier) + "\\" + "FailedDataFiles" + "\\";
                        break;
                    case CommonDataSettingTypes.Disconnect_File:
                        path = GetSettingsContainerFolder(deviceIdentifier) + "\\" + "SFS.Shutdown.sfs" + "." + monitorId + ".sfs";
                        break;
                    case CommonDataSettingTypes.TemperatureUnitSetting_File:
                        path = GetSettingsContainerFolder(deviceIdentifier) + "\\" + "SFS.TempUnitOnMonitor.sfs" + "." + monitorId + ".sfs";
                        break;
                    case CommonDataSettingTypes.InstallCode_File:
                        path = GetBaseFolder(deviceIdentifier) + "\\" + "SFS.InstallCode" + "." + monitorId + ".sfs";
                        break;
                }
                return path;
            }
            catch
            {
                throw;
            }
        }
        /// <summary>
        /// Method to Set Disconnect Setting.
        /// </summary>
        /// <param name="value"></param>
        /// <param name="deviceName"></param>
        /// <param name="monitorId"></param>
        /// <CreatedBy>Om Shakya</CreatedBy>
        /// <CreatedDate>Aug 2016</CreatedDate>
        /// <ModifyBy>...</ModifyBy>
        /// <ModifyDate>...</ModifyDate>
        public static void SetDisconnectSetting(DisconnectSetting value, DeviceIdentifier deviceName, string monitorId)
        {
            try
            {
                SetSettingValue(CommonDataSettingTypes.Disconnect_File, value.ToString(), deviceName, monitorId);
            }
            catch
            {
                throw;
            }
        }
        /// <summary>
        /// Method to Read Disconnect Setting.
        /// </summary>
        /// <param name="deviceName"></param>
        /// <param name="monitorId"></param>
        /// <returns></returns>
        /// <CreatedBy>Om Shakya</CreatedBy>
        /// <CreatedDate>Aug 2016</CreatedDate>
        /// <ModifyBy>...</ModifyBy>
        /// <ModifyDate>...</ModifyDate>
        public static DisconnectSetting ReadDisconnectSetting(DeviceIdentifier deviceName, string monitorId)
        {
            DisconnectSetting disconnectSetting = DisconnectSetting.None;
            try
            {
                disconnectSetting = (DisconnectSetting)Enum.Parse(typeof(DisconnectSetting)
                                                                    , ReadSettingValue(CommonDataSettingTypes.Disconnect_File, deviceName, monitorId));
                return disconnectSetting;
            }
            catch
            {
                throw;
            }
        }
        /// <summary>
        /// Method to Set Setting Value.
        /// </summary>
        /// <param name="type"></param>
        /// <param name="value"></param>
        /// <param name="deviceName"></param>
        /// <param name="monitorId"></param>
        /// <CreatedBy>Om Shakya</CreatedBy>
        /// <CreatedDate>Aug 2016</CreatedDate>
        /// <ModifyBy>...</ModifyBy>
        /// <ModifyDate>...</ModifyDate>
        private static void SetSettingValue(CommonDataSettingTypes type, string value, DeviceIdentifier deviceName, string monitorId)
        {
            try
            {
                string fileLoc = GetCommonDataPath(type, deviceName, monitorId);

                //Get the directory name from file location
                string directoryName = Path.GetDirectoryName(fileLoc);

                //If file not exists, create it
                if (!Directory.Exists(directoryName))
                    Directory.CreateDirectory(directoryName);

                //If file not exists, create it
                if (!File.Exists(fileLoc))
                    using (FileStream fs = File.Create(fileLoc)) { fs.Close(); }

                //Overwrite the value
                if (File.Exists(fileLoc))
                    File.WriteAllText(fileLoc, value);
            }
            catch
            {
                throw;
            }
        }
        /// <summary>
        /// Method to Read Setting Value.
        /// </summary>
        /// <param name="type"></param>
        /// <param name="deviceName"></param>
        /// <param name="monitorId"></param>
        /// <returns></returns>
        /// <CreatedBy>Om Shakya</CreatedBy>
        /// <CreatedDate>Aug 2016</CreatedDate>
        /// <ModifyBy>...</ModifyBy>
        /// <ModifyDate>...</ModifyDate>
        private static string ReadSettingValue(CommonDataSettingTypes type, DeviceIdentifier deviceName, string monitorId)
        {
            string settingValue = string.Empty;
            try
            {
                string fileLoc = GetCommonDataPath(type, deviceName, monitorId);
                //Read the setting value from file
                if (!string.IsNullOrEmpty(fileLoc))
                {
                    settingValue = File.ReadAllText(fileLoc);
                }
                return settingValue;
            }
            catch
            {
                throw;
            }
        }
        /// <summary>
        ///  Method to Set Temperature unit setting available on monitor.
        /// </summary>
        /// <param name="temperatureUnitOnMonitor"></param>
        /// <param name="deviceName"></param>
        /// <param name="monitorId"></param>
        public static void SetMonitorTemperatureUnitSetting(string temperatureUnitOnMonitor, DeviceIdentifier deviceName, string monitorId)
        {
            try
            {
                SetSettingValue(CommonDataSettingTypes.TemperatureUnitSetting_File, temperatureUnitOnMonitor, deviceName, monitorId);
            }
            catch
            {
                throw;
            }
        }
        /// <summary>
        /// Method to Get Temperature unit setting available on monitor.
        /// </summary>
        /// <param name="deviceName"></param>
        /// <param name="monitorId"></param>
        /// <returns></returns>
        public static string ReadMonitorTemperatureUnitSetting(DeviceIdentifier deviceName, string monitorId)
        {
            string disconnectSetting = string.Empty;
            try
            {
                string fileLoc = GetCommonDataPath(CommonDataSettingTypes.TemperatureUnitSetting_File, deviceName, monitorId);
                if (File.Exists(fileLoc))
                {
                    disconnectSetting = ReadSettingValue(CommonDataSettingTypes.TemperatureUnitSetting_File, deviceName, monitorId);
                }
                return disconnectSetting;
            }
            catch
            {
                throw;
            }
        }

    }
}
