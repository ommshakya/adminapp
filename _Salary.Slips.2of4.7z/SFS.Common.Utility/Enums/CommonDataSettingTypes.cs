﻿namespace SFS.CommonUtilities.Enums
{
    /// <summary>
    /// Enum for common data setting types.
    /// </summary>
    /// <CreatedBy>Om Shakya</CreatedBy>
    /// <CreatedDate>Aug 2016</CreatedDate>
    /// <ModifyBy>...</ModifyBy>
    /// <ModifyDate>...</ModifyDate>
    public enum CommonDataSettingTypes
    {
        None,
        Base_Folder,
        SettingsContainer_Folder,
        DataContainer_Folder,
        LiveDataFile_Folder,
        PendingDataFiles_Folder,
        SentDataFiles_Folder,
        FailedDataFiles_Folder,
        Disconnect_File,
        ServiceBusEndPoint,
        SurgeryApiKey,
        AdminApp,
        ListenerLogContainer_Folder,
        SimulatorLogContainer_Folder,
        TemperatureUnitSetting_File,
        InstallCode_File
    }
}
