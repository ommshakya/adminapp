﻿using SFS.CommonUtilities;
using SFS.ConfigManager;
using System;
using System.Collections;
using System.Text;

namespace SFS.Listener.BioNet.BioNetUtility
{
    /// <summary>
    /// BioNet Utility Information Packets Class.
    /// </summary>
    /// <CreatedBy>Om Shakya</CreatedBy>
    /// <CreatedDate>Sep 2015</CreatedDate>
    /// <ModifyBy>...</ModifyBy>
    /// <ModifyDate>...</ModifyDate>
    public static class BioNetUtilityInformationPackets
    {
        /// <summary>
        /// Get User_Info_Length (It is fixed as per Bionet protocol documentation).
        /// </summary>
        /// <CreatedBy>Om Shakya</CreatedBy>
        /// <CreatedDate>Sep 2015</CreatedDate>
        /// <ModifyBy>...</ModifyBy>
        /// <ModifyDate>...</ModifyDate>
        public static int User_Info_Length
        {
            get { return AppConfigurations.BioNet_User_Info_Length; }
        }

        /// <summary>
        /// Get Admit_Info_Length (It is fixed as per Bionet protocol documentation).
        /// </summary>
        /// <CreatedBy>Om Shakya</CreatedBy>
        /// <CreatedDate>Sep 2015</CreatedDate>
        /// <ModifyBy>...</ModifyBy>
        /// <ModifyDate>...</ModifyDate>
        public static int Admit_Info_Length
        {
            get { return AppConfigurations.BioNet_Admit_Info_Length; }
        }

        /// <summary>
        /// Get Alarm_Info_Length (It is fixed as per Bionet protocol documentation).
        /// </summary>
        /// <CreatedBy>Om Shakya</CreatedBy>
        /// <CreatedDate>Sep 2015</CreatedDate>
        /// <ModifyBy>...</ModifyBy>
        /// <ModifyDate>...</ModifyDate>
        public static int Alarm_Info_Length
        {
            get { return AppConfigurations.BioNet_Alarm_Info_Length; }
        }

        /// <summary>
        /// Get Setting_Info_Length (It is fixed as per Bionet protocol documentation).
        /// </summary>
        /// <CreatedBy>Om Shakya</CreatedBy>
        /// <CreatedDate>Sep 2015</CreatedDate>
        /// <ModifyBy>...</ModifyBy>
        /// <ModifyDate>...</ModifyDate>
        public static int Setting_Info_Length
        {
            get { return AppConfigurations.BioNet_Setting_Info_Length; }
        }

        /// <summary>
        /// Method USER_INFO, it forms the USER_INFO.
        /// </summary>
        /// <returns></returns>
        public static byte[] USER_INFO()
        {
            byte[] bytes_User_Info = null;
            try
            {
                bytes_User_Info = new byte[23];
                bytes_User_Info[0] = 0xC1;

                //Device Model Information (BM3Vet or BM5Vet)
                //0x01	BM3Vet  0x02	BM3 +   0x03	BM3 wide    0x04	BM5Vet  0x05	BM7
                byte device_model = 4;
                bytes_User_Info[1] = device_model;

                //Protocol version -- Version :1byte(Upper.Lower) ( 4bit . 4bit )
                //ex) 1.5 ( 0001 0101 )
                byte[] byteVersion = GeneralMethodsUtility.PrepareByteFromUpperLower4bitsValues(1, 5);
                bytes_User_Info[2] = byteVersion[0];

                byte[] unit_room_name = new byte[11];
                unit_room_name = Encoding.ASCII.GetBytes("A/8");
                unit_room_name.CopyTo(bytes_User_Info, 3);

                //16 - bed number
                byte bedNum = 16;
                bytes_User_Info[14] = bedNum;

                //AC Filter -- 50hz (0x01), 60hz (0x02)
                byte ac_filter = 1;
                bytes_User_Info[15] = ac_filter;

                //Year
                //20 - 1st part of year 2015
                byte year_part1 = (byte)ushort.Parse(DateTime.Now.Year.ToString().Substring(0, 2));// 20;
                bytes_User_Info[16] = year_part1;
                //15 - 2nd part of year 2015
                byte year_part2 = (byte)ushort.Parse(DateTime.Now.Year.ToString().Substring(2, 2));// 15;
                bytes_User_Info[17] = year_part2;

                //Month
                byte month = (byte)(DateTime.Now.Month - 1);
                bytes_User_Info[18] = month;

                //Day
                byte day = (byte)DateTime.Now.Day;
                bytes_User_Info[19] = day;

                //Hour
                byte hour = (byte)DateTime.Now.Hour;
                bytes_User_Info[20] = hour;

                //Minute
                byte minute = (byte)DateTime.Now.Minute;
                bytes_User_Info[21] = minute;

                //16 - bed number
                byte bed_num = 16;
                bytes_User_Info[22] = bed_num;
                return bytes_User_Info;
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Method ADMIT_INFO, it forms the ADMIT_INFO.
        /// </summary>
        /// <returns></returns>
        public static byte[] ADMIT_INFO()
        {
            byte[] bytes_Admit_Info = null;
            try
            {
                bytes_Admit_Info = new byte[49];
                bytes_Admit_Info[0] = 0xC2;

                //Admit Status -- Discharged : 0x00 Admitted : 0x01
                bytes_Admit_Info[1] = 0x01;

                //ADMIT TYPE -- Horse : 0x01 Dog : 0x02 Puppy : 0x03 Cat : 0x04
                bytes_Admit_Info[2] = 0x02;

                byte[] hospital_name = new byte[11];
                hospital_name = Encoding.ASCII.GetBytes("kim"); //WE HAVE ASSUMED ASCII ENCODING, IF REQUIRED CHANGE IT and in PARSER ALSO
                hospital_name.CopyTo(bytes_Admit_Info, 3);

                byte[] patient_name = new byte[11];
                patient_name = Encoding.ASCII.GetBytes("samqwe");
                patient_name.CopyTo(bytes_Admit_Info, 14);

                byte[] patient_id = new byte[11];
                patient_id = Encoding.ASCII.GetBytes("003");
                patient_id.CopyTo(bytes_Admit_Info, 25);

                //SEX --Male : 0x00 Female :  0x01
                bytes_Admit_Info[36] = 0x00;

                //Year
                //20 - 1st part of year 2015
                byte year_part1 = (byte)ushort.Parse(DateTime.Now.Year.ToString().Substring(0, 2));// 20;
                bytes_Admit_Info[37] = year_part1;
                //15 - 2nd part of year 2015
                byte year_part2 = (byte)ushort.Parse(DateTime.Now.Year.ToString().Substring(2, 2));// 20;
                bytes_Admit_Info[38] = year_part2;

                //Month
                byte month = (byte)(DateTime.Now.Month - 1);
                bytes_Admit_Info[39] = month;

                //Day
                byte day = (byte)DateTime.Now.Day;
                bytes_Admit_Info[40] = day;

                //Age -- 0x00 : 0year , 0x0f : 127years old
                byte age = 50;
                bytes_Admit_Info[41] = age;

                //Height Unit (Cm , inches) -- 0x00 : Cm , 0x01 : inches
                bytes_Admit_Info[42] = 0x01;

                //Height Value -- Ex) 182.5 43rd byte -> 182 44th byte -> 5
                //130 - 1st part of height 130.0
                byte height_part1 = 130;
                bytes_Admit_Info[43] = height_part1;
                //00 -  2nd part of height 130.0
                byte height_part2 = 0;
                bytes_Admit_Info[44] = height_part2;

                //Weight Unit (Kg , LBS) -- 0x00 : Kg , 0x01 : LBS
                bytes_Admit_Info[45] = 0x01;

                //Weight Value -- Ex) 80.5 46th -> 80 47th -> 5
                //50 - 1st part of 50.0 LBS
                byte weight_part1 = 80;
                bytes_Admit_Info[46] = weight_part1;
                //0 - 2nd part of 50.0 LBS
                byte weight_part2 = 5;
                bytes_Admit_Info[47] = weight_part2;

                //16 - bed number
                byte bed_num = 16;
                bytes_Admit_Info[48] = bed_num;
                return bytes_Admit_Info;
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Method ALARM_INFO, it forms the ALARM_INFO.
        /// </summary>
        /// <returns></returns>
        public static byte[] ALARM_INFO()
        {
            byte[] bytes_Alarm_Info = null;
            try
            {
                bytes_Alarm_Info = new byte[95];
                bytes_Alarm_Info[0] = 0xC3;

                //HR Alarm level -  2 for LOW
                bytes_Alarm_Info[1] = 0x02;

                UInt16 HR_Alarm_limit_low = 0;
                byte[] bytes_HR_Alarm_limit_low = BitConverter.GetBytes(HR_Alarm_limit_low);
                bytes_HR_Alarm_limit_low.CopyTo(bytes_Alarm_Info, 2);

                UInt16 HR_Alarm_limit_high = 299;
                byte[] bytes_HR_Alarm_limit_high = BitConverter.GetBytes(HR_Alarm_limit_high);
                bytes_HR_Alarm_limit_high.CopyTo(bytes_Alarm_Info, 4);

                //%SpO2 and SpO2-PR Alarm Level
                //Upper 4bit : SpO2-% Alarm Level Lower 4bit : SpO2-PR Alarm Level
                //Alarm Level Value 0x01 : Message 0x02 : LOW 0x03 : medium 0x04 : high
                byte[] byteSpO2_SpO2PR = GeneralMethodsUtility.PrepareByteFromUpperLower4bitsValues(4, 4);
                bytes_Alarm_Info[6] = byteSpO2_SpO2PR[0];

                byte SpO2_Alarm_Limit_low = 0;
                bytes_Alarm_Info[7] = SpO2_Alarm_Limit_low;

                byte SpO2_Alarm_Limit_high = 100;
                bytes_Alarm_Info[8] = SpO2_Alarm_Limit_high;

                UInt16 SpO2_PR_Alarm_limit_low = 0;
                byte[] bytes_SpO2_PR_Alarm_limit_low = BitConverter.GetBytes(SpO2_PR_Alarm_limit_low);
                bytes_SpO2_PR_Alarm_limit_low.CopyTo(bytes_Alarm_Info, 9);

                UInt16 SpO2_PR_Alarm_limit_high = 300;
                byte[] bytes_SpO2_PR_Alarm_limit_high = BitConverter.GetBytes(SpO2_PR_Alarm_limit_high);
                bytes_SpO2_PR_Alarm_limit_high.CopyTo(bytes_Alarm_Info, 11);

                //RESP-R alarm level - 3 means Medium
                bytes_Alarm_Info[13] = 0x03;

                //RESP R Alarm limit low
                byte RESP_R_Alarm_limit_low = 149;
                bytes_Alarm_Info[14] = RESP_R_Alarm_limit_low;

                //RESP R Alarm limit high
                byte RESP_R_Alarm_limit_high = 150;
                bytes_Alarm_Info[15] = RESP_R_Alarm_limit_high;

                //NIBP Alarm level - 4 mens high
                bytes_Alarm_Info[16] = 0x04;

                UInt16 SYS_alarm_limit_low = 0;
                byte[] bytes_SYS_alarm_limit_low = BitConverter.GetBytes(SYS_alarm_limit_low);
                bytes_SYS_alarm_limit_low.CopyTo(bytes_Alarm_Info, 17);

                UInt16 SYS_alarm_limit_high = 300;
                byte[] bytes_SYS_alarm_limit_high = BitConverter.GetBytes(SYS_alarm_limit_high);
                bytes_SYS_alarm_limit_high.CopyTo(bytes_Alarm_Info, 19);

                UInt16 mean_alarm_limit_low = 0;
                byte[] bytes_mean_alarm_limit_low = BitConverter.GetBytes(mean_alarm_limit_low);
                bytes_mean_alarm_limit_low.CopyTo(bytes_Alarm_Info, 21);

                UInt16 mean_alarm_limit_high = 300;
                byte[] bytes_mean_alarm_limit_high = BitConverter.GetBytes(mean_alarm_limit_high);
                bytes_mean_alarm_limit_high.CopyTo(bytes_Alarm_Info, 23);

                UInt16 DIA_alarm_limit_low = 0;
                byte[] bytes_DIA_alarm_limit_low = BitConverter.GetBytes(DIA_alarm_limit_low);
                bytes_DIA_alarm_limit_low.CopyTo(bytes_Alarm_Info, 25);

                UInt16 DIA_alarm_limit_high = 300;
                byte[] bytes_DIA_alarm_limit_high = BitConverter.GetBytes(DIA_alarm_limit_high);
                bytes_DIA_alarm_limit_high.CopyTo(bytes_Alarm_Info, 27);

                //TEMP1 , TEMP2 Alarm level
                //Upper 4bits : TEMP1 Alarm Level Lower 4bits : TEMP2 Alarm Level
                //0x01 : Message 0x02 : LOW 0x03 : medium 0x04 : high 
                byte[] byteTemp1_Temp2 = GeneralMethodsUtility.PrepareByteFromUpperLower4bitsValues(4, 4);
                bytes_Alarm_Info[29] = byteTemp1_Temp2[0];

                //T1 alarm LOW limit : 30.5 - its is 30
                byte t1_alarm_limit_low_1stpart = 30;
                bytes_Alarm_Info[30] = t1_alarm_limit_low_1stpart;

                //T1 alarm LOW limit : 30.5 - its is 5
                byte t1_alarm_limit_low_2ndpart = 5;
                bytes_Alarm_Info[31] = t1_alarm_limit_low_2ndpart;

                //T1 alarm HIGH limit : 30.5 - its is 30
                byte t1_alarm_limit_high_1stpart = 30;
                bytes_Alarm_Info[32] = t1_alarm_limit_high_1stpart;

                //T1 alarm HIGH limit : 30.5 - its is 5
                byte t1_alarm_limit_high_2ndpart = 5;
                bytes_Alarm_Info[33] = t1_alarm_limit_high_2ndpart;

                //T2 alarm LOW limit : 30.5 - its is 30
                byte t2_alarm_limit_low_1stpart = 30;
                bytes_Alarm_Info[34] = t2_alarm_limit_low_1stpart;

                //T2 alarm LOW limit : 30.5 - its is 5
                byte t2_alarm_limit_low_2ndpart = 5;
                bytes_Alarm_Info[35] = t2_alarm_limit_low_2ndpart;

                //T2 alarm HIGH limit : 30.5 - its is 30
                byte t2_alarm_limit_high_1stpart = 30;
                bytes_Alarm_Info[36] = t2_alarm_limit_high_1stpart;

                //T2 alarm HIGH limit : 30.5 - its is 5
                byte t2_alarm_limit_high_2ndpart = 5;
                bytes_Alarm_Info[37] = t2_alarm_limit_high_2ndpart;

                //IBP1 , IBP2 Alarm Level
                //Upper 4bits : IBP1 Alarm Level Lower 4bits : IBP2 Alarm Level
                //0x01 : Message 0x02 : LOW 0x03 : medium 0x04 : high 
                byte[] byteIBP1_IBP2 = GeneralMethodsUtility.PrepareByteFromUpperLower4bitsValues(4, 4);
                bytes_Alarm_Info[38] = byteIBP1_IBP2[0];

                UInt16 IBP1_SYS_alarm_limit_low = 0;
                byte[] bytes_IBP1_SYS_alarm_limit_low = BitConverter.GetBytes(IBP1_SYS_alarm_limit_low);
                bytes_IBP1_SYS_alarm_limit_low.CopyTo(bytes_Alarm_Info, 39);

                UInt16 IBP1_SYS_alarm_limit_high = 300;
                byte[] bytes_IBP1_SYS_alarm_limit_high = BitConverter.GetBytes(IBP1_SYS_alarm_limit_high);
                bytes_IBP1_SYS_alarm_limit_high.CopyTo(bytes_Alarm_Info, 41);

                UInt16 IBP1_mean_alarm_limit_low = 0;
                byte[] bytes_IBP1_mean_alarm_limit_low = BitConverter.GetBytes(IBP1_mean_alarm_limit_low);
                bytes_IBP1_mean_alarm_limit_low.CopyTo(bytes_Alarm_Info, 43);

                UInt16 IBP1_mean_alarm_limit_high = 300;
                byte[] bytes_IBP1_mean_alarm_limit_high = BitConverter.GetBytes(IBP1_mean_alarm_limit_high);
                bytes_IBP1_mean_alarm_limit_high.CopyTo(bytes_Alarm_Info, 45);

                UInt16 IBP1_DIA_alarm_limit_low = 0;
                byte[] bytes_IBP1_DIA_alarm_limit_low = BitConverter.GetBytes(IBP1_DIA_alarm_limit_low);
                bytes_IBP1_DIA_alarm_limit_low.CopyTo(bytes_Alarm_Info, 47);

                UInt16 IBP1_DIA_alarm_limit_high = 300;
                byte[] bytes_IBP1_DIA_alarm_limit_high = BitConverter.GetBytes(IBP1_DIA_alarm_limit_high);
                bytes_IBP1_DIA_alarm_limit_high.CopyTo(bytes_Alarm_Info, 49);

                UInt16 IBP1_Rate_alarm_limit_low = 0;
                byte[] bytes_IBP1_Rate_alarm_limit_low = BitConverter.GetBytes(IBP1_Rate_alarm_limit_low);
                bytes_IBP1_Rate_alarm_limit_low.CopyTo(bytes_Alarm_Info, 51);

                UInt16 IBP1_Rate_alarm_limit_high = 300;
                byte[] bytes_IBP1_Rate_alarm_limit_high = BitConverter.GetBytes(IBP1_Rate_alarm_limit_high);
                bytes_IBP1_Rate_alarm_limit_high.CopyTo(bytes_Alarm_Info, 53);

                UInt16 IBP2_SYS_alarm_limit_low = 0;
                byte[] bytes_IBP2_SYS_alarm_limit_low = BitConverter.GetBytes(IBP2_SYS_alarm_limit_low);
                bytes_IBP2_SYS_alarm_limit_low.CopyTo(bytes_Alarm_Info, 55);
                PartOf_ALARM_INFO(bytes_Alarm_Info);
                return bytes_Alarm_Info;
            }
            catch
            {
                throw;
            }
        }

        private static void PartOf_ALARM_INFO(byte[] bytes_Alarm_Info)
        {
            UInt16 IBP2_SYS_alarm_limit_high = 300;
            byte[] bytes_IBP2_SYS_alarm_limit_high = BitConverter.GetBytes(IBP2_SYS_alarm_limit_high);
            bytes_IBP2_SYS_alarm_limit_high.CopyTo(bytes_Alarm_Info, 57);

            UInt16 IBP2_mean_alarm_limit_low = 0;
            byte[] bytes_IBP2_mean_alarm_limit_low = BitConverter.GetBytes(IBP2_mean_alarm_limit_low);
            bytes_IBP2_mean_alarm_limit_low.CopyTo(bytes_Alarm_Info, 59);

            UInt16 IBP2_mean_alarm_limit_high = 300;
            byte[] bytes_IBP2_mean_alarm_limit_high = BitConverter.GetBytes(IBP2_mean_alarm_limit_high);
            bytes_IBP2_mean_alarm_limit_high.CopyTo(bytes_Alarm_Info, 61);

            UInt16 IBP2_DIA_alarm_limit_low = 0;
            byte[] bytes_IBP2_DIA_alarm_limit_low = BitConverter.GetBytes(IBP2_DIA_alarm_limit_low);
            bytes_IBP2_DIA_alarm_limit_low.CopyTo(bytes_Alarm_Info, 63);

            UInt16 IBP2_DIA_alarm_limit_high = 300;
            byte[] bytes_IBP2_DIA_alarm_limit_high = BitConverter.GetBytes(IBP2_DIA_alarm_limit_high);
            bytes_IBP2_DIA_alarm_limit_high.CopyTo(bytes_Alarm_Info, 65);

            UInt16 IBP2_Rate_alarm_limit_low = 0;
            byte[] bytes_IBP2_Rate_alarm_limit_low = BitConverter.GetBytes(IBP2_Rate_alarm_limit_low);
            bytes_IBP2_Rate_alarm_limit_low.CopyTo(bytes_Alarm_Info, 67);

            UInt16 IBP2_Rate_alarm_limit_high = 300;
            byte[] bytes_IBP2_Rate_alarm_limit_high = BitConverter.GetBytes(IBP2_Rate_alarm_limit_high);
            bytes_IBP2_Rate_alarm_limit_high.CopyTo(bytes_Alarm_Info, 69);

            //EtCO2, FiCO2, awRR Alarm level - 3 means Medium
            bytes_Alarm_Info[71] = 0x03;

            byte EtCO2_Alarm_Limit_low = 0;
            bytes_Alarm_Info[72] = EtCO2_Alarm_Limit_low;

            byte EtCo2_Alarm_Limit_high = 100;
            bytes_Alarm_Info[73] = EtCo2_Alarm_Limit_high;

            byte FiCO2_Alarm_Limit_low = 0;
            bytes_Alarm_Info[74] = FiCO2_Alarm_Limit_low;

            byte FiCo2_Alarm_Limit_high = 100;
            bytes_Alarm_Info[75] = FiCo2_Alarm_Limit_high;

            //awRR (Air-way Respiration Rate) Alarm Level - 3 means Medium
            bytes_Alarm_Info[76] = 0x03;

            byte awRR_Alarm_Limit_low = 0;
            bytes_Alarm_Info[77] = awRR_Alarm_Limit_low;

            byte awRR_Alarm_Limit_high = 30;
            bytes_Alarm_Info[78] = awRR_Alarm_Limit_high;

            bytes_Alarm_Info[79] = 0x02;//ASYSTOLE Alarm Level - 2 means LOW
            bytes_Alarm_Info[80] = 0x03;//VTAC/VFIB Alarm Level - 3 means Medium
            bytes_Alarm_Info[81] = 0x04;//VTAC Alarm Level - 4 means HIGH

            bytes_Alarm_Info[82] = 3;//Irregular alarm level
            bytes_Alarm_Info[83] = 3;//PAUSE alarm level
            bytes_Alarm_Info[84] = 3;//PVC alarm level
            bytes_Alarm_Info[85] = 3;//BIGEMINY alarm level
            bytes_Alarm_Info[86] = 3;//TRIGEMINY alarm level
            bytes_Alarm_Info[87] = 3;//COUPLET alarm level
            bytes_Alarm_Info[88] = 3;//R ON T alarm level
            bytes_Alarm_Info[89] = 3;//VPC RUN alarm level
            bytes_Alarm_Info[90] = 3;//V BRADY alarm level
            bytes_Alarm_Info[91] = 3;//VCC VENT alarm level
            bytes_Alarm_Info[92] = 3;//ST alarm level
            bytes_Alarm_Info[93] = 3;//Battery Low alarm level

            byte bedNum = 16;
            bytes_Alarm_Info[94] = bedNum; //16 - bed number
        }

        /// <summary>
        /// Method SETTING_INFO, it forms the SETTING_INFO.
        /// </summary>
        /// <returns></returns>
        public static byte[] SETTING_INFO()
        {
            byte[] bytes_Setting_Info = null;
            try
            {
                bytes_Setting_Info = new byte[22];
                bytes_Setting_Info[0] = 0xC4;

                /*SET parameter//bit0 : ECG
                bit1 : SpO2
                bit2 : RESP
                bit3 : NIBP
                bit4 : TEMP
                bit5 : IBP1
                bit6 : IBP2
                bit7 : EtCO2
                */
                BitArray bits = new BitArray(8);
                bits[0] = true;
                bits[1] = false;
                bits[2] = true;
                bits[3] = false;
                bits[4] = true;
                bits[5] = false;
                bits[6] = true;
                bits[7] = false;

                byte[] bytes1 = new byte[1];
                bits.CopyTo(bytes1, 0);

                //SET parameter
                bytes1.CopyTo(bytes_Setting_Info, 1);

                // NURSE CALL ON/OFF -- 0x00 : OFF , 0x01 :ON
                bytes_Setting_Info[2] = 0x01;

                // COLOR SELECT -- 0x00: Green, 0x01: color
                bytes_Setting_Info[3] = 0x01;

                // ECG LEAD SELECT -- 0x03 : lead III
                bytes_Setting_Info[4] = 0x03;

                // ECG SIZE -- 0x01: X0.5 , 0x02 : X1 0x03: X2 ,  0x04 : X4
                bytes_Setting_Info[5] = 0x04;

                //QRS_VOLUME -- 0:OFF, 10 levels
                byte QRS_VOLUME = 100;
                bytes_Setting_Info[6] = QRS_VOLUME;

                //ECG FILTER -- 0x02: MODERATE
                bytes_Setting_Info[7] = 0x02;

                //PACE -- 0x00: OFF, 0x01: ON
                bytes_Setting_Info[8] = 0x01;

                //ARRHYTH -- 0x00: OFF, 0x01: ON
                bytes_Setting_Info[9] = 0x01;

                //RESP SIZE -- 0x02 : X2 , 0x04 : X4 0x06 : X6 , 0x08 : X8
                bytes_Setting_Info[10] = 0x02;

                //SpO2_Rate_volume -- 0:OFF, 10 levels
                byte SpO2_Rate_volume = 90;
                bytes_Setting_Info[11] = SpO2_Rate_volume;

                //NIBP CUFF TYPE -- 1 : ADT , 2 :PED , 3 : NEO
                bytes_Setting_Info[12] = 0x02;

                //SpO2_Rate_volume -- 0 : OFF, 1 : 1min , 2 : 2min 3 : 3min , 4 : 4min , 5 : 5min 10 : 10min , 15 : 15min, 20 : 20min, 30 : 3min
                //60 : 60min, 90 : 90min 102 : 2hours, 104 : 4hours 108 : 8hours
                byte NIBP_INTERVAL = 102;
                bytes_Setting_Info[13] = NIBP_INTERVAL;

                //TEMP Unit -- 0x01 : ‘C , 0x02 : ‘F
                bytes_Setting_Info[14] = 0x01;

                //IBP 1  Name -- 0x01 : ART , 0x02 : FEM 0x03 : PAP , 0x04 : RAP 0x05 : LAP , 0x06 : UAP 0x07 : UVP , 0x08 : CVP 0x09 : ICP , 0x0A : Other
                bytes_Setting_Info[15] = 0x03;

                //IBP1 scale -- 0x01 : 30 , 0x02 : 60 0x03 : 80 , 0x04 : 100 0x05 : 160 , 0x06 : 200 0x07 : 300
                bytes_Setting_Info[16] = 0x03;

                //IBP2 Name -- 0x01 : ART , 0x02 : FEM 0x03 : PAP , 0x04 : RAP 0x05 : LAP , 0x06 : UAP 0x07 : UVP , 0x08 : CVP 0x09 : ICP , 0x0A : Other
                bytes_Setting_Info[17] = 0x03;

                //IBP2 Scale -- 0x01 : 30 , 0x02 : 60 0x03 : 80 , 0x04 : 100 0x05 : 160 , 0x06 : 200 0x07 : 300
                bytes_Setting_Info[18] = 0x03;

                //EtCO2 Scale -- 0x01 : 40 , 0x02 : 50 0x03 : 60 , 0x04 : 80 0x05 : 100
                bytes_Setting_Info[19] = 0x04;

                //EtCO2 Type -- 0x01 : Small 0x02 : Large
                bytes_Setting_Info[20] = 0x02;

                //16 - bed number
                byte bedNum = 16;
                bytes_Setting_Info[21] = bedNum;
                return bytes_Setting_Info;
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Method to Get Packets Combo Length.
        /// </summary>
        /// <param name="identifier"></param>
        /// <returns></returns>
        public static int GetPacketsComboLength(BioNetPacketsComboIdentifier identifier)
        {
            int length = 0;
            try
            {
                switch (identifier)
                {
                    case BioNetPacketsComboIdentifier.SETTING_PARAM_PacketsCombo:
                        length = Setting_Info_Length
                                + BioNetUtilityDataPackets.Parameter_Data_Length;
                        break;

                    case BioNetPacketsComboIdentifier.USER_ADMIT_ALARM_SETTING_PacketsCombo:
                        length = User_Info_Length
                                 + Admit_Info_Length
                                 + Alarm_Info_Length
                                 + Setting_Info_Length;
                        break;
                }
                return length;
            }
            catch
            {
                throw;
            }
        }
    }
}
