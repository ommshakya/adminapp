﻿namespace SFS.Listener.Vetland.VetlandUtility
{
    /// <summary>
    /// Vetland Utility Requests class.
    /// </summary>
    public static class VetlandUtilityRequests
    {
        /// <summary>
        /// To get first 2 bytes of connection packet. 
        /// </summary>
        public static string CONNECT_REQ_HeaderPrimitive
        {
            get
            {
                return string.Concat(VetlandUtilityHeaders.REQ_CONNECT_Header, VetlandUtilityPrimitives.REQ_CONNECT_Primitive);
            }
        }

        /// <summary>
        /// To get first 2 bytes of font data.
        /// </summary>
        public static string CONNECT_FONT_HeaderPrimitive
        {
            get
            {
                return string.Concat(VetlandUtilityHeaders.FONT_DATA_Header, VetlandUtilityPrimitives.FONT_DATA_Primitive);
            }
        }
    }
}
