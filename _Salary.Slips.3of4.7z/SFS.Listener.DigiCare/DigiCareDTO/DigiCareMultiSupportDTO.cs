﻿using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Sockets;
using System.Threading;

namespace SFS.Listener.DigiCare.DigiCareDTO
{
    /// <summary>
    /// DTO class for supporting the multiple surgeries implementation of Digicare.
    /// </summary>
    public static class DigiCareMultiSupportDTO
    {
        /// <summary>
        /// Property to check whether Digicare listener is running or not.
        /// </summary>
        public static bool isDigiCareListenerRunning;
        /// <summary>
        /// Collection of DigiCare connected clients/monitors.
        /// </summary>
        public static Dictionary<Guid, IPAddress> DigiCareConnectedClients;
        /// <summary>
        /// Collection of DigiCare connected tcp clients.
        /// </summary>
        public static Dictionary<Guid, TcpClient> DigiCareConnectedClientTcpClient;
        /// <summary>
        /// Collection of DigiCare data transfer threads of connected client/monitor.
        /// </summary>
        public static Dictionary<Guid, Thread> DigiCareConnectedClientDataTransferThreads;
        /// <summary>
        /// Collection of DigiCare data transfer timers if thread of connected client/monitor.
        /// </summary>
        public static Dictionary<Guid, System.Timers.Timer> DigiCareConnectedClientDataTransferThreadTimers;
    }
}
