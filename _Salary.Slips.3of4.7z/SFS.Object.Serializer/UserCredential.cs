﻿namespace SFS.ObjectSerializer
{
    /// <summary>
    /// UserCredential DTO.
    /// </summary>
    /// <CreatedBy>Om Shakya</CreatedBy>
    /// <CreatedDate>Aug 2016</CreatedDate>
    /// <ModifyBy>...</ModifyBy>
    /// <ModifyDate>...</ModifyDate>
    public class UserCredentialDTO
    {
        public string emailId { get; set; }
        public string password { get; set; }
    }
}
