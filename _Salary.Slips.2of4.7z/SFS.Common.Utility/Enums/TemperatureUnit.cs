﻿namespace SFS.CommonUtilities.Enums
{
    public enum TemperatureUnit
    {
        Celsius,
        Fahrenheit
    }
}
