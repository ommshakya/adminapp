﻿using System.Windows.Forms;

namespace SFS.Admin.App
{
    public partial class FrmMsg : Form
    {
        public FrmMsg()
        {
            InitializeComponent();
        }
    }
}
