﻿using SFS.CommonServices;
using SFS.CommonUtilities;
using SFS.CommonUtilities.Enums;
using SFS.FileWritter;
using SFS.ObjectSerializer;
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Configuration.Install;
using System.IO;
using System.Reflection;
using System.ServiceProcess;

namespace SFS.Admin.App
{
    [RunInstaller(true)]
    public partial class CustomInstaller : System.Configuration.Install.Installer
    {
        public CustomInstaller()
        {
            InitializeComponent();
        }
        public string InstallerErrorFilePath
        {
            get
            {
                return Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData) + "\\SFS.Installer.Error.txt";
            }
        }
        /// <summary>
        /// Install event of the installer.
        /// </summary>
        /// <param name="stateSaver"></param>
        public override void Install(IDictionary stateSaver)
        {
            base.Install(stateSaver);

            try
            {
                //This is the install  code verification logic.
                string installCode = Context.Parameters["InstallCode"];

                if (string.IsNullOrEmpty(installCode))
                {
                    InstallCode codeRead = Serializer.ReadFromBinaryFile<InstallCode>(
                                     SettingsUtility.GetCommonDataPath(CommonDataSettingTypes.InstallCode_File, DeviceIdentifier.InstallCode)
                                     );
                    installCode = codeRead.installcode;
                }

                if (installCode.Length > 3)
                {
                    string actualCode = installCode.Substring(1, 3);
                    int days = 0;
                    bool b = int.TryParse(actualCode, out days);
                    if (!(b & days.Equals(365)))
                    {
                        throw new InstallException("Install Code is invalid. Please restart the installation again and enter the valid Install Code.");
                    }

                    InstallCode code = new InstallCode();
                    code.installcode = installCode;

                    Serializer.WriteToBinaryFile<InstallCode>(
                                        SettingsUtility.GetCommonDataPath(CommonDataSettingTypes.InstallCode_File,
                                            DeviceIdentifier.InstallCode), code);
                }
                else
                    throw new InstallException("Install Code is invalid. Please restart the installation again and enter the valid Install Code.");
            }
            catch (Exception ex)
            {
                LogWriter.WriteToError(ex, InstallerErrorFilePath);
            }
        }
        /// <summary>
        /// OnBeforeInstall event of the installer.
        /// </summary>
        /// <param name="stateSaver"></param>
        protected override void OnBeforeInstall(IDictionary stateSaver)
        {
            ServiceInstaller ServiceInstallerObj = new ServiceInstaller();
            try
            {
                string winServiceName = string.Empty;
                var config = ConfigurationManager.OpenExeConfiguration(Assembly.GetAssembly(typeof(CustomInstaller)).Location);
                winServiceName = config.AppSettings.Settings["WinApp_WindowService_Name"].Value;

                if (IsServiceInstalled(winServiceName))
                {
                    ServiceInstallerObj.Context = new InstallContext();
                    ServiceInstallerObj.Context = Context;
                    ServiceInstallerObj.ServiceName = winServiceName;
                    ServiceInstallerObj.Uninstall(null);
                }
            }
            catch (Exception ex)
            {
                LogWriter.WriteToError(ex, InstallerErrorFilePath);
            }
            finally
            {
                ServiceInstallerObj.Dispose();
            }
            base.OnBeforeInstall(stateSaver);
        }
        /// <summary>
        /// Commit event of the installer.
        /// </summary>
        /// <param name="savedState"></param>
        public override void Commit(IDictionary savedState)
        {
            try
            {
                //This is the code to get the document file path
                //using the configuration settings and the flag to identify whether it is required or not

                var config = ConfigurationManager.OpenExeConfiguration(Assembly.GetAssembly(typeof(CustomInstaller)).Location);
                string yesNo = config.AppSettings.Settings["WinApp_Settings_Open_Document_On_Install"].Value;

                bool result = false;
                bool.TryParse(yesNo, out result);

                if (result)
                {
                    string docFilePath = Path.Combine(Context.Parameters["DIR"], "Documents\\Surgery Admin Help.pdf");
                    System.Diagnostics.Process.Start(docFilePath);
                }
            }
            catch (Exception ex)
            {
                LogWriter.WriteToError(ex, InstallerErrorFilePath);
            }
            finally
            {
                base.Commit(savedState);
                System.Diagnostics.Process.Start(Path.GetDirectoryName(this.Context.Parameters["AssemblyPath"]) + "\\Surgery Admin.exe");
            }
        }
        /// <summary>
        /// Uninstall event of the installer
        /// </summary>
        /// <param name="savedState"></param>
        public override void Uninstall(IDictionary savedState)
        {
            base.Uninstall(savedState);
            try
            {
                try
                {
                    RemoveFilesFolders();
                }
                catch { throw; }
                try
                {
                    RemoveCommonFolders();
                }
                catch { throw; }
            }
            catch (Exception ex)
            {
                LogWriter.WriteToError(ex, InstallerErrorFilePath);
            }
        }
        /// <summary>
        /// OnBeforeUninstall event of the installer.
        /// </summary>
        /// <param name="savedState"></param>
        protected override void OnBeforeUninstall(IDictionary savedState)
        {
            try
            {
                try
                {
                    UnRegisterApplication();
                }
                catch
                {
                    throw new InstallException("Could not unregister application, Please try uninstallation again after some time.");
                }
                string winServiceName = string.Empty;

                var config = ConfigurationManager.OpenExeConfiguration(Assembly.GetAssembly(typeof(CustomInstaller)).Location);
                winServiceName = config.AppSettings.Settings["WinApp_WindowService_Name"].Value;

                ServiceController controller = new ServiceController(winServiceName);
                try
                {

                    if (controller.Status == ServiceControllerStatus.Running |
                        controller.Status == ServiceControllerStatus.Paused)
                    {
                        controller.Stop();
                        controller.WaitForStatus(ServiceControllerStatus.Stopped, new TimeSpan(0, 0, 0, 45));
                        controller.Close();
                    }
                }
                catch
                {
                    throw new InstallException("Could not remove the window service ''" + winServiceName + ", Please stop it manually and then try uninstallation.");
                }
                finally { controller.Dispose(); }
            }
            catch (Exception ex)
            {
                LogWriter.WriteToError(ex, InstallerErrorFilePath);
            }
            base.OnBeforeUninstall(savedState);
        }

        #region Private methods
        /// <summary>
        /// Method to check whether the service is installed or not.
        /// </summary>
        /// <param name="serviceName"></param>
        /// <returns></returns>
        private static bool IsServiceInstalled(string serviceName)
        {
            try
            {
                ServiceController[] services = ServiceController.GetServices();
                foreach (ServiceController service in services)
                    if (service.ServiceName == serviceName) return true;
                return false;
            }
            catch
            {
                throw;
            }
        }
        /// <summary>
        /// Method to GetApiUrlFromConfig.
        /// </summary>
        /// <returns></returns>
        private static string GetApiUrlFromConfig()
        {
            try
            {
                var config = ConfigurationManager.OpenExeConfiguration(Assembly.GetAssembly(typeof(CustomInstaller)).Location);
                string url = config.AppSettings.Settings["SFSAPI_Production_URL"].Value;
                return url;
            }
            catch
            {
                throw;
            }
        }
        /// <summary>
        /// Method to UnRegisterMonitors.
        /// </summary>
        private static void UnRegisterMonitors()
        {
            try
            {
                string url = GetApiUrlFromConfig();

                bool result = RegistrationService.UnRegisterMonitorsFromInstaller(url);
                if (!result)
                    throw new Exception("Could not unregister monitors.");
            }
            catch
            {
                throw;
            }
        }
        /// <summary>
        /// Method to UnRegisterApplication.
        /// </summary>
        private static void UnRegisterApplication()
        {
            try
            {
                string url = GetApiUrlFromConfig();

                bool result = RegistrationService.UnRegisterApplicationFromInstaller(url);
                if (!result)
                    throw new Exception("Could not unregister application.");
            }
            catch
            {
                throw;
            }
        }
        /// <summary>
        /// Method to RemoveFilesFolders.
        /// </summary>
        private void RemoveFilesFolders()
        {
            try
            {
                string baseDirectory = Context.Parameters["DIR"].ToString();
                string logFileDirectory = Path.Combine(baseDirectory, "Log");

                if (Directory.Exists(logFileDirectory))
                {
                    var subDir = Directory.EnumerateDirectories(logFileDirectory);
                    foreach (string dir in subDir)
                    {
                        if (Directory.Exists(dir))
                        {
                            DeleteFiles(dir);
                            Directory.Delete(dir);
                        }
                    }
                    DeleteFiles(logFileDirectory);
                    Directory.Delete(logFileDirectory);
                }

                string errorFileDirectory = Path.Combine(baseDirectory, "Error");
                if (Directory.Exists(errorFileDirectory))
                {
                    var subDir = Directory.EnumerateDirectories(errorFileDirectory);
                    foreach (string dir in subDir)
                    {
                        if (Directory.Exists(dir))
                        {
                            DeleteFiles(dir);
                            Directory.Delete(dir);
                        }
                    }
                    DeleteFiles(errorFileDirectory);
                    Directory.Delete(errorFileDirectory);
                }

                if (Directory.Exists(baseDirectory))
                {
                    DeleteFiles(Context.Parameters["DIR"]);
                }
            }
            catch
            {
                throw;
            }
        }
        /// <summary>
        /// Method to RemoveCommonFolders.
        /// </summary>
        private static void RemoveCommonFolders()
        {
            try
            {
                //Remove the program data folder also
                var config = ConfigurationManager.OpenExeConfiguration(Assembly.GetAssembly(typeof(CustomInstaller)).Location);
                string WinApp_Settings_BaseFolderName = config.AppSettings.Settings["WinApp_Settings_BaseFolderName"].Value;

                string baseFolder = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData), WinApp_Settings_BaseFolderName);
                string serviceBusEndPointFolder = Path.Combine(baseFolder, DeviceIdentifier.ServiceBusEndPoint.ToString());
                string surgeryApiKeyFolder = Path.Combine(baseFolder, DeviceIdentifier.SurgeryApiKey.ToString());
                string adminAppFolder = Path.Combine(baseFolder, DeviceIdentifier.AdminApp.ToString());
                string monitorsFolder = Path.Combine(baseFolder, DeviceIdentifier.Monitors.ToString());
                string digiCareFolder = Path.Combine(baseFolder, DeviceIdentifier.DigiCare.ToString());
                string cardellFolder = Path.Combine(baseFolder, DeviceIdentifier.Cardell.ToString());
                string vetLandFolder = Path.Combine(baseFolder, DeviceIdentifier.VetLand.ToString());
                string bioNetFolder = Path.Combine(baseFolder, DeviceIdentifier.BioNet.ToString());
                string installCodeFolder = Path.Combine(baseFolder, DeviceIdentifier.InstallCode.ToString());

                List<string> listOfFolders = new List<string>();
                listOfFolders.Add(adminAppFolder);
                listOfFolders.Add(serviceBusEndPointFolder);
                listOfFolders.Add(surgeryApiKeyFolder);
                listOfFolders.Add(monitorsFolder);
                listOfFolders.Add(digiCareFolder);
                listOfFolders.Add(cardellFolder);
                listOfFolders.Add(vetLandFolder);
                listOfFolders.Add(bioNetFolder);
                listOfFolders.Add(installCodeFolder);

                //Clear and Delete  this base folder at last
                listOfFolders.Add(baseFolder);

                foreach (string folder in listOfFolders)
                    ClearFolder(folder);
            }
            catch
            {
                throw;
            }
        }
        /// <summary>
        /// Method to ClearFolder.
        /// </summary>
        /// <param name="folder"></param>
        private static void ClearFolder(string folder)
        {
            try
            {
                if (Directory.Exists(folder))
                {
                    var subDir = Directory.EnumerateDirectories(folder);
                    foreach (string dir in subDir)
                    {
                        if (Directory.Exists(dir))
                        {
                            var subDir1 = Directory.EnumerateDirectories(dir);
                            foreach (string dir1 in subDir1)
                            {
                                if (Directory.Exists(dir1))
                                {
                                    DeleteFiles(dir1);
                                    Directory.Delete(dir1);
                                }
                            }
                            DeleteFiles(dir);
                            Directory.Delete(dir);
                        }
                    }
                    DeleteFiles(folder);
                    Directory.Delete(folder);
                }
            }
            catch { throw; }
        }
        /// <summary>
        /// Method to DeleteFiles.
        /// </summary>
        /// <param name="dir"></param>
        private static void DeleteFiles(string dir)
        {
            try
            {
                if (Directory.Exists(dir))
                {
                    var files = Directory.EnumerateFiles(dir);
                    foreach (string currentFile in files)
                    {
                        if (Path.GetExtension(currentFile).Equals(".txt") ||
                            Path.GetExtension(currentFile).Equals(".tmp") ||
                            Path.GetExtension(currentFile).Equals(".sfs"))
                            File.Delete(currentFile);
                    }
                }
            }
            catch { throw; }
        }
        #endregion
    }
}
