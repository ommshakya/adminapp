﻿using System.Collections.Generic;

namespace SFS.CommonUtilities
{
    /// <summary>
    /// Lookup Utility class.
    /// </summary>
    /// <CreatedBy>Om Shakya</CreatedBy>
    /// <CreatedDate>Aug 2016</CreatedDate>
    /// <ModifyBy>...</ModifyBy>
    /// <ModifyDate>...</ModifyDate>
    public static class LookupUtility
    {
        /// <summary>
        /// Method to Lookup byte values in byte categories.
        /// </summary>
        /// <param name="lookupkey"></param>
        /// <param name="lookupin"></param>
        /// <returns></returns>
        /// <CreatedBy>Om Shakya</CreatedBy>
        /// <CreatedDate>Aug 2016</CreatedDate>
        /// <ModifyBy>...</ModifyBy>
        /// <ModifyDate>...</ModifyDate>
        public static string Lookup(ushort lookupkey, Dictionary<ushort, string> lookupin)
        {
            string result = string.Empty;
            try
            {
                result = lookupin[lookupkey].ToString();
                return result;
            }
            catch
            {
                throw;
            }
        }
    }
}
