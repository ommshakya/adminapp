﻿namespace SFS.Listener.BioNet.BioNetUtility
{
    /// <summary>
    /// BioNet Utility Headers Class.
    /// </summary>
    /// <CreatedBy>Om Shakya</CreatedBy>
    /// <CreatedDate>Sep 2015</CreatedDate>
    /// <ModifyBy>...</ModifyBy>
    /// <ModifyDate>...</ModifyDate>
    public static class BioNetUtilityHeaders
    {
        /// <summary>
        /// Get CONNECT_REQ_Header, (It is fixed set of characters as per Bionet protocol documentation).
        /// </summary>
        /// <CreatedBy>Om Shakya</CreatedBy>
        /// <CreatedDate>Sep 2015</CreatedDate>
        /// <ModifyBy>...</ModifyBy>
        /// <ModifyDate>...</ModifyDate>
        public static string CONNECT_REQ_Header { get { return "C0"; } }
        /// <summary>
        /// Get CONNECT_ACCEPT_Header, (It is fixed set of characters as per Bionet protocol documentation).
        /// </summary>
        /// <CreatedBy>Om Shakya</CreatedBy>
        /// <CreatedDate>Sep 2015</CreatedDate>
        /// <ModifyBy>...</ModifyBy>
        /// <ModifyDate>...</ModifyDate>
        public static string CONNECT_ACCEPT_Header { get { return "C0"; } }
        /// <summary>
        /// Get DISCONNECT_REQ_Header, (It is fixed set of characters as per Bionet protocol documentation).
        /// </summary>
        /// <CreatedBy>Om Shakya</CreatedBy>
        /// <CreatedDate>Sep 2015</CreatedDate>
        /// <ModifyBy>...</ModifyBy>
        /// <ModifyDate>...</ModifyDate>
        public static string DISCONNECT_REQ_Header { get { return "C0"; } }
        /// <summary>
        /// Get DATA_ACK_Header, (It is fixed set of characters as per Bionet protocol documentation).
        /// </summary>
        /// <CreatedBy>Om Shakya</CreatedBy>
        /// <CreatedDate>Sep 2015</CreatedDate>
        /// <ModifyBy>...</ModifyBy>
        /// <ModifyDate>...</ModifyDate>
        public static string DATA_ACK_Header { get { return "C0"; } }
        /// <summary>
        /// Get USER_INFO_Header, (It is fixed set of characters as per Bionet protocol documentation).
        /// </summary>
        /// <CreatedBy>Om Shakya</CreatedBy>
        /// <CreatedDate>Sep 2015</CreatedDate>
        /// <ModifyBy>...</ModifyBy>
        /// <ModifyDate>...</ModifyDate>
        public static string USER_INFO_Header { get { return "C1"; } }
        /// <summary>
        /// Get ADMIT_INFO_Header, (It is fixed set of characters as per Bionet protocol documentation).
        /// </summary>
        /// <CreatedBy>Om Shakya</CreatedBy>
        /// <CreatedDate>Sep 2015</CreatedDate>
        /// <ModifyBy>...</ModifyBy>
        /// <ModifyDate>...</ModifyDate>
        public static string ADMIT_INFO_Header { get { return "C2"; } }
        /// <summary>
        /// Get ALARM_INFO_Header, (It is fixed set of characters as per Bionet protocol documentation).
        /// </summary>
        /// <CreatedBy>Om Shakya</CreatedBy>
        /// <CreatedDate>Sep 2015</CreatedDate>
        /// <ModifyBy>...</ModifyBy>
        /// <ModifyDate>...</ModifyDate>
        public static string ALARM_INFO_Header { get { return "C3"; } }
        /// <summary>
        /// Get SETTING_INFO_Header, (It is fixed set of characters as per Bionet protocol documentation).
        /// </summary>
        /// <CreatedBy>Om Shakya</CreatedBy>
        /// <CreatedDate>Sep 2015</CreatedDate>
        /// <ModifyBy>...</ModifyBy>
        /// <ModifyDate>...</ModifyDate>
        public static string SETTING_INFO_Header { get { return "C4"; } }
        /// <summary>
        /// Get PARAMETER_DATA_Header, (It is fixed set of characters as per Bionet protocol documentation).
        /// </summary>
        /// <CreatedBy>Om Shakya</CreatedBy>
        /// <CreatedDate>Sep 2015</CreatedDate>
        /// <ModifyBy>...</ModifyBy>
        /// <ModifyDate>...</ModifyDate>
        public static string PARAMETER_DATA_Header { get { return "D1"; } }
    }
}
