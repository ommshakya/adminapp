﻿using SFS.CommonUtilities.Enums;
using SFS.FileWritter;
using System;

namespace SFS.CommonUtilities
{
    /// <summary>
    /// Class for helping the log writter.
    /// </summary>
    /// <CreatedBy>Om Shakya</CreatedBy>
    /// <CreatedDate>Aug 2016</CreatedDate>
    /// <ModifyBy>...</ModifyBy>
    /// <ModifyDate>...</ModifyDate>
    public static class LogHelperUtility
    {
        #region Public Methods
        /// <summary>
        /// Method to Get Log File Name For Listener.
        /// </summary>
        /// <param name="deviceName"></param>
        /// <param name="monitorId"></param>
        /// <returns></returns>
        /// <CreatedBy>Om Shakya</CreatedBy>
        /// <CreatedDate>Aug 2016</CreatedDate>
        /// <ModifyBy>...</ModifyBy>
        /// <ModifyDate>...</ModifyDate>
        public static string GetLogFileNameForListener(DeviceIdentifier deviceName, string monitorId)
        {
            string fileName = "Listener";
            try
            {
                if (!string.IsNullOrEmpty(deviceName.ToString()))
                    fileName += "." + deviceName.ToString() + ".";

                fileName += string.Format(@"{0}.{1}.Log.txt", DateTime.Now.ToString("MMddyyyy"), monitorId);
                fileName = SettingsUtility.GetCommonDataPath(CommonDataSettingTypes.ListenerLogContainer_Folder, deviceName) + fileName;
                return fileName;
            }
            catch
            {
                throw;
            }
        }
        /// <summary>
        /// Method to Get Log File Name For Simulator.
        /// </summary>
        /// <param name="deviceName"></param>
        /// <returns></returns>
        /// <CreatedBy>Om Shakya</CreatedBy>
        /// <CreatedDate>Aug 2016</CreatedDate>
        /// <ModifyBy>...</ModifyBy>
        /// <ModifyDate>...</ModifyDate>
        public static string GetLogFileNameForSimulator(DeviceIdentifier deviceName)
        {
            string fileName = "Simulator";
            try
            {
                if (!string.IsNullOrEmpty(deviceName.ToString()))
                    fileName += "." + deviceName.ToString() + ".";

                fileName += string.Format(@"{0}.Log.txt", DateTime.Now.ToString("MMddyyyy"));
                fileName = SettingsUtility.GetCommonDataPath(CommonDataSettingTypes.SimulatorLogContainer_Folder, deviceName) + fileName;
                return fileName;
            }
            catch
            {
                throw;
            }
        }
        /// <summary>
        /// Method to Get Log File Name For Common Live Data.
        /// </summary>
        /// <param name="deviceName"></param>
        /// <param name="monitorId"></param>
        /// <returns></returns>
        /// <CreatedBy>Om Shakya</CreatedBy>
        /// <CreatedDate>Aug 2016</CreatedDate>
        /// <ModifyBy>...</ModifyBy>
        /// <ModifyDate>...</ModifyDate>
        public static string GetLogFileNameForCommonLiveData(DeviceIdentifier deviceName, string monitorId)
        {
            string fileName = "Live.Data";
            try
            {
                if (!string.IsNullOrEmpty(deviceName.ToString()))
                    fileName += "." + deviceName.ToString() + ".";

                fileName += string.Format(@"{0}.{1}.Log.txt", DateTime.Now.ToString("MMddyyyy"), monitorId);
                fileName = SettingsUtility.GetCommonDataPath(CommonDataSettingTypes.LiveDataFile_Folder, deviceName) + fileName;
                return fileName;
            }
            catch
            {
                throw;
            }
        }
        /// <summary>
        /// Method to Get Log File Name For Common Data Transfer.
        /// </summary>
        /// <param name="deviceName"></param>
        /// <param name="dataTransferStatus"></param>
        /// <param name="monitorId"></param>
        /// <returns></returns>
        /// <CreatedBy>Om Shakya</CreatedBy>
        /// <CreatedDate>Aug 2016</CreatedDate>
        /// <ModifyBy>...</ModifyBy>
        /// <ModifyDate>...</ModifyDate>
        public static string GetLogFileNameForCommonDataTransfer(DeviceIdentifier deviceName, DataTransferStatus dataTransferStatus, string monitorId)
        {
            string fileName = "Data.Transfer";
            try
            {
                if (!string.IsNullOrEmpty(deviceName.ToString()))
                    fileName += "." + deviceName.ToString() + ".";

                fileName += string.Format(@"{0}.{1}.{2}.Log.txt", GetDataTransferFileName(dataTransferStatus), DateTime.Now.ToString("MMddyyyy"), monitorId);
                fileName = SettingsUtility.GetCommonDataPath(CommonDataSettingTypes.DataContainer_Folder, deviceName) + "\\DataTransfer\\" + fileName;
                return fileName;
            }
            catch
            {
                throw;
            }
        }
        /// <summary>
        /// Method to Get Log File Name For Common Traceing.
        /// </summary>
        /// <param name="deviceName"></param>
        /// <param name="monitorId"></param>
        /// <returns></returns>
        /// <CreatedBy>Om Shakya</CreatedBy>
        /// <CreatedDate>Aug 2016</CreatedDate>
        /// <ModifyBy>...</ModifyBy>
        /// <ModifyDate>...</ModifyDate>
        public static string GetLogFileNameForCommonTraceing(DeviceIdentifier deviceName, string monitorId)
        {
            string fileName = "Trace.Error";
            try
            {
                if (!string.IsNullOrEmpty(deviceName.ToString()))
                    fileName += "." + deviceName.ToString() + ".";

                fileName += string.Format(@"{0}.{1}.Log.txt", DateTime.Now.ToString("MMddyyyy"), monitorId);
                fileName = SettingsUtility.GetCommonDataPath(CommonDataSettingTypes.DataContainer_Folder, deviceName) + "\\TraceError\\" + fileName;
                return fileName;
            }
            catch
            {
                throw;
            }
        }
        /// <summary>
        /// Method to Get Error File Name For Admin App.
        /// </summary>
        /// <param name="deviceName"></param>
        /// <returns></returns>
        /// <CreatedBy>Om Shakya</CreatedBy>
        /// <CreatedDate>Aug 2016</CreatedDate>
        /// <ModifyBy>...</ModifyBy>
        /// <ModifyDate>...</ModifyDate>
        public static string GetErrorFileNameForAdminApp()
        {
            string fileName = string.Format(@"{0}.Admin.App.Error.txt", DateTime.Now.ToString("MMddyyyy"));
            try
            {
                fileName = SettingsUtility.GetCommonDataPath(CommonDataSettingTypes.AdminApp,
                                                          DeviceIdentifier.AdminApp) + fileName;
                return fileName;
            }
            catch
            {
                throw;
            }
        }
        /// <summary>
        /// Method to Get Trace File Name For Admin App.
        /// </summary>
        /// <param name="deviceName"></param>
        /// <returns></returns>
        /// <CreatedBy>Om Shakya</CreatedBy>
        /// <CreatedDate>Aug 2016</CreatedDate>
        /// <ModifyBy>...</ModifyBy>
        /// <ModifyDate>...</ModifyDate>
        public static string GetTraceFileNameForAdminApp()
        {
            string fileName = string.Format(@"{0}.Admin.App.Trace.txt", DateTime.Now.ToString("MMddyyyy"));
            try
            {
                fileName = SettingsUtility.GetCommonDataPath(CommonDataSettingTypes.AdminApp,
                                                          DeviceIdentifier.AdminApp) + fileName;
                return fileName;
            }
            catch
            {
                throw;
            }
        }

        #endregion

        #region Private Methods
        /// <summary>
        /// Method to Get Data Transfer File Name.
        /// </summary>
        /// <param name="dataTransferStatus"></param>
        /// <returns></returns>
        /// <CreatedBy>Om Shakya</CreatedBy>
        /// <CreatedDate>Aug 2016</CreatedDate>
        /// <ModifyBy>...</ModifyBy>
        /// <ModifyDate>...</ModifyDate>
        private static string GetDataTransferFileName(DataTransferStatus dataTransferStatus)
        {
            string fileName = "Data.Unknown";
            try
            {
                if (dataTransferStatus.Equals(DataTransferStatus.Sent))
                    fileName = "Data.Sent";
                if (dataTransferStatus.Equals(DataTransferStatus.Failed))
                    fileName = "Data.Failed";
                return fileName;
            }
            catch
            {
                throw;
            }
        }
        #endregion
    }
}
