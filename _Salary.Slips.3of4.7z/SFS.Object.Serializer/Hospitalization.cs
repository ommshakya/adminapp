﻿using System;

namespace SFS.ObjectSerializer
{
    /// <summary>
    /// Hospitalization serializable DTO.
    /// </summary>
    /// <CreatedDate>Aug 2016</CreatedDate>
    /// <ModifyBy>...</ModifyBy>
    /// <ModifyDate>...</ModifyDate>
    [Serializable]
    public class Hospitalization
    {
        public int activeSurgeryNumber { get; set; }
        public string clientNameFirst { get; set; }
        public string clientNameLast { get; set; }
        public DateTime dateCreated { get; set; }
        public Guid hospitalizationId { get; set; }
        public string patientBreed { get; set; }
        public string patientName { get; set; }
        public string patientSpecies { get; set; }
        public Guid? surgeryId { get; set; }
        public double? surgeryIntervalFrequency { get; set; }
        public DateTime? surgeryStartDate { get; set; }
    }
}
