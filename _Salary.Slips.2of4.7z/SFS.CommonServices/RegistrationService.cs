﻿using SFS.CommonUtilities;
using SFS.CommonUtilities.Enums;
using SFS.ConfigManager;
using SFS.FileWritter;
using SFS.HttpClientHelper;
using SFS.ObjectSerializer;
using SFS.SurgeryMonitorEventManager;
using System;
using System.Collections.Generic;
using System.Linq;

namespace SFS.CommonServices
{
    /// <summary>
    /// A class to register various objects via the SFS API calls.
    /// </summary>
    /// <CreatedBy>Om Shakya</CreatedBy>
    /// <CreatedDate>Aug 2016</CreatedDate>
    /// <ModifyBy>...</ModifyBy>
    /// <ModifyDate>...</ModifyDate>
    public static class RegistrationService
    {
        /// <summary>
        /// Method to Register Application.
        /// </summary>
        /// <param name="userCredential"></param>
        /// <returns></returns>
        /// <CreatedBy>Om Shakya</CreatedBy>
        /// <CreatedDate>Aug 2016</CreatedDate>
        /// <ModifyBy>...</ModifyBy>
        /// <ModifyDate>...</ModifyDate>
        public static ServiceResultDTO RegisterApplication(UserCredentialDTO userCredential)
        {
            ServiceResultDTO serviceResultDTO = null;
            try
            {
                string surgeryApiKey = new APIConnector(AppConfigurations.SFSAPI_Production_URL, null
                                                                    ).GetSurgeryApiKey(userCredential.emailId,
                                                                    userCredential.password);
                if (!string.IsNullOrEmpty(surgeryApiKey))
                {
                    bool b = Serializer.WriteToBinaryFile<string>(
                                                  SettingsUtility.GetCommonDataPath(CommonDataSettingTypes.SurgeryApiKey,
                                                          DeviceIdentifier.SurgeryApiKey)
                                                  + "\\"+ CommonFileNames.SurgeryApiKey_FileName,
                                                  surgeryApiKey);

                    if (b)
                    {
                        smartflowsheet.surgery.api.model.objects.SurgeryMonitorEndpoint endPoint = new APIConnector(
                                                                            AppConfigurations.SFSAPI_Production_URL,
                                                                            surgeryApiKey
                                                                            ).RegisterApplication();

                        if (endPoint != null)
                        {
                            SurgeryMonitorEndPoint surgeryMonitorEndPointDTO = new SurgeryMonitorEndPoint();
                            surgeryMonitorEndPointDTO.installationId = endPoint.installationId;
                            surgeryMonitorEndPointDTO.objectType = endPoint.objectType;
                            surgeryMonitorEndPointDTO.serviceNamespace = endPoint.serviceNamespace;
                            surgeryMonitorEndPointDTO.servicePath = endPoint.servicePath;
                            surgeryMonitorEndPointDTO.tokenAccessKey = endPoint.tokenAccessKey;
                            surgeryMonitorEndPointDTO.tokenKeyName = endPoint.tokenKeyName;

                            Serializer.WriteToBinaryFile<SurgeryMonitorEndPoint>(
                                SettingsUtility.GetCommonDataPath(CommonDataSettingTypes.ServiceBusEndPoint,
                                    DeviceIdentifier.ServiceBusEndPoint)
                                + "\\"+ CommonFileNames.SurgeryMonitorEndPointSimulator_FileName,
                                surgeryMonitorEndPointDTO);


                            serviceResultDTO = new ServiceResultDTO
                            {
                                status = ServiceResultStatus.Success,
                                message = CommonMessages.ApplicationRegisteredSuccessfully
                            };
                        }
                    }
                }
                return serviceResultDTO;
            }
            catch
            {
                throw;
            }
        }
        /// <summary>
        /// Method to Register Monitor.
        /// </summary>
        /// <param name="surgeryMonitorDTO"></param>
        /// <returns></returns>
        /// <CreatedBy>Om Shakya</CreatedBy>
        /// <CreatedDate>Aug 2016</CreatedDate>
        /// <ModifyBy>...</ModifyBy>
        /// <ModifyDate>...</ModifyDate>
        public static ServiceResultDTO RegisterMonitor(SurgeryMonitor surgeryMonitorDTO)
        {
            ServiceResultDTO serviceResultDTO = null;
            try
            {
                smartflowsheet.surgery.api.model.objects.SurgeryMonitor surgeryMonitorObj = new smartflowsheet.surgery.api.model.objects.SurgeryMonitor();
                surgeryMonitorObj.deviceName = surgeryMonitorDTO.deviceName;
                surgeryMonitorObj.ipAddress = surgeryMonitorDTO.monitorIPAddress.ToString();
                surgeryMonitorObj.name = surgeryMonitorDTO.name;

                smartflowsheet.surgery.api.model.objects.SurgeryMonitor surgeryMonitor = new APIConnector(
                                                    AppConfigurations.SFSAPI_Production_URL,
                                                    SerializedObjects.SurgeryApiKey
                                                    ).RegisterMonitor(surgeryMonitorObj);

                if (surgeryMonitor != null)
                {
                    surgeryMonitorDTO.monitorId = surgeryMonitor.monitorId;
                    surgeryMonitorDTO.objectType = surgeryMonitor.objectType;
                    surgeryMonitorDTO.deviceName = surgeryMonitor.deviceName;
                    surgeryMonitorDTO.monitorIPAddress = System.Net.IPAddress.Parse(surgeryMonitor.ipAddress);

                    Serializer.WriteToBinaryFile<SurgeryMonitor>(
                        SettingsUtility.GetCommonDataPath(CommonDataSettingTypes.ServiceBusEndPoint,
                            DeviceIdentifier.Monitors)
                        + "\\SFS.Monitor." + surgeryMonitor.monitorId.ToString() + ".sfs",
                        surgeryMonitorDTO);

                    serviceResultDTO = new ServiceResultDTO
                    {
                        status = ServiceResultStatus.Success,
                        message = CommonMessages.MonitorRegisteredSuccessfully
                    };
                }
                return serviceResultDTO;
            }
            catch
            {
                throw;
            }
        }
        /// <summary>
        /// Method to Un Register Application.
        /// </summary>
        /// <param name="userCredential"></param>
        /// <returns></returns>
        /// <CreatedBy>Om Shakya</CreatedBy>
        /// <CreatedDate>Aug 2016</CreatedDate>
        /// <ModifyBy>...</ModifyBy>
        /// <ModifyDate>...</ModifyDate>
        public static ServiceResultDTO UnRegisterApplication()
        {
            try
            {
                return doUnRegisterApplication();
            }
            catch
            {
                throw;
            }
        }
        /// <summary>
        /// Method to Un Register Application from uninstall functionality of the Installer.
        /// </summary>
        /// <param name="apiUrl"></param>
        /// <returns></returns>
        /// <CreatedBy>Om Shakya</CreatedBy>
        /// <CreatedDate>Sep 2016</CreatedDate>
        /// <ModifyBy>...</ModifyBy>
        /// <ModifyDate>...</ModifyDate>
        public static bool UnRegisterApplicationFromInstaller(string apiUrl)
        {
            try
            {
                ServiceResultDTO result = doUnRegisterApplication(apiUrl);
                if (result != null)
                {
                    return result.status.Equals(ServiceResultStatus.Success);
                }
                else
                    return false;
            }
            catch
            {
                throw;
            }
        }
        /// <summary>
        /// Method to Un Register Monitor.
        /// </summary>
        /// <param name="monitorId"></param>
        /// <returns></returns>
        /// <CreatedBy>Om Shakya</CreatedBy>
        /// <CreatedDate>Aug 2016</CreatedDate>
        /// <ModifyBy>...</ModifyBy>
        /// <ModifyDate>...</ModifyDate>
        public static ServiceResultDTO UnRegisterMonitor(Guid monitorId)
        {
            try
            {
                return doUnRegisterMonitor(monitorId);
            }
            catch
            {
                throw;
            }

        }
        /// <summary>
        /// Method to Un Register Monitors from uninstall functionality of the Installer.
        /// </summary>
        /// <param name="monitorId"></param>
        /// <returns></returns>
        /// <CreatedBy>Om Shakya</CreatedBy>
        /// <CreatedDate>Aug 2016</CreatedDate>
        /// <ModifyBy>...</ModifyBy>
        /// <ModifyDate>...</ModifyDate>
        public static bool UnRegisterMonitorsFromInstaller(string apiUrl)
        {
            bool result = false;
            try
            {
                List<SurgeryMonitor> listMonitors = SerializedObjects.MonitorsList;

                int counter = 0;
                if (listMonitors != null)
                {
                    foreach (SurgeryMonitor monitor in listMonitors)
                    {
                        Guid monitorId = monitor.monitorId;

                        ServiceResultDTO res = doUnRegisterMonitor(monitorId, apiUrl);
                        if (res.status.Equals(ServiceResultStatus.Success))
                            counter++;
                    }
                    if (counter.Equals(listMonitors.Count))
                        result = true;
                }
                return result;
            }
            catch
            {
                throw;
            }
        }
        
        /// <summary>
        /// Base logic of unregister application.
        /// </summary>
        /// <param name="optionalUrlForInstallerOnly"></param>
        /// <returns></returns>
        /// <CreatedBy>Om Shakya</CreatedBy>
        /// <CreatedDate>Sep 2016</CreatedDate>
        /// <ModifyBy>...</ModifyBy>
        /// <ModifyDate>...</ModifyDate>
        private static ServiceResultDTO doUnRegisterApplication(string optionalUrlForInstallerOnly = null)
        {
            ServiceResultDTO serviceResultDTO = null;
            try
            {
                if (SerializedObjects.SurgeryMonitorEndpoint != null)
                {
                    SurgeryMonitorEventEndpoint.Instance.Close();

                    new APIConnector(
                                   string.IsNullOrEmpty(optionalUrlForInstallerOnly) ? AppConfigurations.SFSAPI_Production_URL : optionalUrlForInstallerOnly,
                                    SerializedObjects.SurgeryApiKey
                                    ).UnregisterApplication(Guid.Parse(SerializedObjects.SurgeryMonitorEndpoint.installationId.ToString()));

                    string fileEndPoint = SettingsUtility.GetCommonDataPath(CommonDataSettingTypes.ServiceBusEndPoint,
                            DeviceIdentifier.ServiceBusEndPoint)
                        + "\\"+ CommonFileNames.SurgeryMonitorEndPointSimulator_FileName;

                    if (System.IO.File.Exists(fileEndPoint))
                        System.IO.File.Delete(fileEndPoint);


                    string fileSApiKey = SettingsUtility.GetCommonDataPath(CommonDataSettingTypes.SurgeryApiKey,
                            DeviceIdentifier.SurgeryApiKey)
                        + CommonFileNames.SurgeryApiKey_FileName;

                    if (System.IO.File.Exists(fileSApiKey))
                        System.IO.File.Delete(fileSApiKey);

                    serviceResultDTO = new ServiceResultDTO
                    {
                        status = ServiceResultStatus.Success,
                        message = CommonMessages.ApplicationRegisteredSuccessfully
                    };
                }
                else
                {
                    throw new Exception(CommonMessages.SurgeryMonitorEndpointNotFound);
                }

                return serviceResultDTO;
            }
            catch
            {
                throw;
            }
        }
        /// <summary>
        /// Base logic of unregister monitor.
        /// </summary>
        /// <param name="monitorId"></param>
        /// <param name="optionalUrlForInstallerOnly"></param>
        /// <returns></returns>
        /// <CreatedBy>Om Shakya</CreatedBy>
        /// <CreatedDate>Sep 2016</CreatedDate>
        /// <ModifyBy>...</ModifyBy>
        /// <ModifyDate>...</ModifyDate>
        private static ServiceResultDTO doUnRegisterMonitor(Guid monitorId, string optionalUrlForInstallerOnly = null)
        {
            ServiceResultDTO serviceResultDTO;
            try
            {
                new APIConnector(
                                string.IsNullOrEmpty(optionalUrlForInstallerOnly) ? AppConfigurations.SFSAPI_Production_URL : optionalUrlForInstallerOnly,
                                SerializedObjects.SurgeryApiKey
                                ).UnregisterMonitor(monitorId);

                string file = SettingsUtility.GetCommonDataPath(CommonDataSettingTypes.ServiceBusEndPoint,
                                                                DeviceIdentifier.Monitors) + "\\SFS.Monitor." + monitorId.ToString() + ".sfs";
                if (System.IO.File.Exists(file))
                    System.IO.File.Delete(file);

                serviceResultDTO = new ServiceResultDTO
                {
                    status = ServiceResultStatus.Success,
                    message = CommonMessages.MonitorRegisteredSuccessfully
                };
                return serviceResultDTO;
            }
            catch
            {
                throw;
            }

        }
        /// <summary>
        /// Method to unregister all the monitors.
        /// </summary>
        /// <returns></returns>
        /// <CreatedBy>Om Shakya</CreatedBy>
        /// <CreatedDate>Oct 2016</CreatedDate>
        /// <ModifyBy>...</ModifyBy>
        /// <ModifyDate>...</ModifyDate>
        public static bool UnRegisterAllMonitors()
        {
            return UnRegisterMonitorsFromInstaller(null);
        }

        /// <summary>
        /// Method to get the list of monitors.
        /// </summary>
        /// <returns></returns>
        public static List<smartflowsheet.surgery.api.model.objects.SurgeryMonitor> GetMonitorsList()
        {
            return new APIConnector(AppConfigurations.SFSAPI_Production_URL,
                                    SerializedObjects.SurgeryApiKey
                                    ).GetMonitorsList().ToList<smartflowsheet.surgery.api.model.objects.SurgeryMonitor>();
        }
        /// <summary>
        /// Method to download the monitors and save locally.
        /// </summary>
        /// <returns></returns>
        public static ServiceResultDTO DownloadMonitorsAndSaveLocally()
        {
            ServiceResultDTO serviceResultDTO = null;
            try
            {
                List<smartflowsheet.surgery.api.model.objects.SurgeryMonitor> allMonitors = GetMonitorsList();
                int counter = 0;
                if (allMonitors != null && allMonitors.Count > 0)
                {
                    foreach (smartflowsheet.surgery.api.model.objects.SurgeryMonitor surgeryMonitor in allMonitors)
                    {
                        SurgeryMonitor monitor = new SurgeryMonitor();
                        monitor.deviceName = surgeryMonitor.deviceName;
                        monitor.monitorId = surgeryMonitor.monitorId;
                        monitor.monitorIPAddress = System.Net.IPAddress.Parse(surgeryMonitor.ipAddress);
                        monitor.name = surgeryMonitor.name;
                        monitor.objectType = surgeryMonitor.objectType;

                        Serializer.WriteToBinaryFile<SurgeryMonitor>(
                            SettingsUtility.GetCommonDataPath(CommonDataSettingTypes.ServiceBusEndPoint,
                                DeviceIdentifier.Monitors)
                            + "\\SFS.Monitor." + monitor.monitorId.ToString() + ".sfs",
                            monitor);
                        counter++;
                    }
                    string msg = string.Empty;
                    if (counter.Equals(allMonitors.Count))
                        msg = CommonMessages.AllMonitorsDownloadedSuccessfully;
                    else
                        msg = CommonMessages.AllMonitorsCouldNotBeDownloaded;
                    serviceResultDTO = new ServiceResultDTO
                    {
                        status = ServiceResultStatus.Success,
                        message = msg
                    };
                }
                return serviceResultDTO;
            }
            catch
            {
                throw;
            }
        }
    }
}
