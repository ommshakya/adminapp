﻿namespace SFS.Listener.DigiCare.DigiCareUtility
{
    /// <summary>
    /// Digicare Utility Headers Class.
    /// </summary>
    /// <CreatedBy>Om Shakya</CreatedBy>
    /// <CreatedDate>Sep 2015</CreatedDate>
    /// <ModifyBy>...</ModifyBy>
    /// <ModifyDate>...</ModifyDate>
    public static class DigicareUtilityHeaders
    {
        /// <summary>
        /// Get REQ_CONNECT_Header.
        /// </summary>
        public static string REQ_CONNECT_Header { get { return "C0"; } }
        /// <summary>
        /// Get REQ_ACCEPT_Header.
        /// </summary>
        public static string REQ_ACCEPT_Header { get { return "C0"; } }
        /// <summary>
        /// Get REQ_DISCONNECT_Header.
        /// </summary>
        public static string REQ_DISCONNECT_Header { get { return "C0"; } }
        /// <summary>
        /// Get INFO_ADMIT_Header.
        /// </summary>
        public static string INFO_ADMIT_Header { get { return "A0"; } }
        /// <summary>
        /// Get INFO_UNITS_Header.
        /// </summary>
        public static string INFO_UNITS_Header { get { return "A1"; } }
        /// <summary>
        /// Get DATA_ACK_Header.
        /// </summary>
        public static string DATA_ACK_Header { get { return "D2"; } }
        /// <summary>
        /// Get DATA_OBSERVATION_Header.
        /// </summary>
        public static string DATA_OBSERVATION_Header { get { return "D1"; } }
    }
}
