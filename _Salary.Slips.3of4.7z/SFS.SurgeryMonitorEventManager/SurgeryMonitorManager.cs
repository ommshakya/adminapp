﻿using SFS.CommonUtilities;
using SFS.CommonUtilities.Enums;
using SFS.FileWritter;
using SFS.Helper;
using SFS.Listener.BioNet;
using SFS.Listener.Cardell;
using SFS.Listener.DigiCare;
using SFS.Listener.Vetland;
using SFS.ObjectSerializer;
using smartflowsheet.surgery.api.model.events;
using smartflowsheet.surgery.api.model.interfaces;
using smartflowsheet.surgery.api.model.objects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading;
using System.Timers;

namespace SFS.SurgeryMonitorEventManager
{
    public class SurgeryMonitorManager : ISurgeryMonitorManager
    {
        #region Public Variables
        //Cardell dictionaries objects
        public static Dictionary<Guid, Thread> CardellSurgeryMonitorThreads = new Dictionary<Guid, Thread>();
        public static Dictionary<Guid, StartSurgeryMonitor> CardellStartMonitorEvent = new Dictionary<Guid, StartSurgeryMonitor>();
        public static bool HasStopMonitorBasedOnStatusCodeTimerStartedCardell = false;

        //DigiCare dictionaries starts
        public static Dictionary<Guid, Thread> DigiCareSurgeryMonitorThreads = new Dictionary<Guid, Thread>();
        public static Dictionary<Guid, StartSurgeryMonitor> DigiCareStartMonitorEvent = new Dictionary<Guid, StartSurgeryMonitor>();
        public static bool HasStopMonitorBasedOnStatusCodeTimerStartedDigiCare = false;

        //VetLand dictionaries starts
        public static Dictionary<Guid, Thread> VetLandSurgeryMonitorThreads = new Dictionary<Guid, Thread>();
        public static Dictionary<Guid, StartSurgeryMonitor> VetLandStartMonitorEvent = new Dictionary<Guid, StartSurgeryMonitor>();
        public static bool HasStopMonitorBasedOnStatusCodeTimerStartedVetLand = false;

        //BioNet dictionaries starts
        public static Dictionary<Guid, Thread> BioNetSurgeryMonitorThreads = new Dictionary<Guid, Thread>();
        public static Dictionary<Guid, StartSurgeryMonitor> BioNetStartMonitorEvent = new Dictionary<Guid, StartSurgeryMonitor>();
        public static bool HasStopMonitorBasedOnStatusCodeTimerStartedBioNet = false;

        #endregion

        /// <summary>
        /// Start Monitor method
        /// </summary>
        /// <param name="StartMonitorEvent"></param>
        /// <returns></returns>
        /// <CreatedBy>Om Shakya</CreatedBy>
        /// <CreatedDate>Oct 2016</CreatedDate>
        /// <ModifyBy>...</ModifyBy>
        /// <ModifyDate>...</ModifyDate>
        public SurgeryMonitorStatus StartMonitor(StartSurgeryMonitor startMonitorEvent)
        {
            SurgeryMonitorStatus result = null;

            //Additional logging, Feb 2017
            DateTime eventReceivedDateTime = DateTime.Now;
            try
            {
                if (IsStartSurgeryMonitorValid(startMonitorEvent))
                {
                    //Check if the startMonitorEvent has all the values
                    ObjectSerializer.SurgeryMonitor monitor = SerializedObjects.GetSurgeryMonitorDevice(startMonitorEvent.monitorId);
                    if (monitor != null)
                    {
                        DeviceNames deviceName = (DeviceNames)Enum.Parse(typeof(DeviceNames), monitor.deviceName);

                        string msg = "Received (StartSurgeryEvent) monitor id: " + Convert.ToString(startMonitorEvent.monitorId);
                        msg += " Retreived monitor Id : " + Convert.ToString(monitor.monitorId);
                        msg += " Device name : " + Convert.ToString(deviceName);
                        msg += " Monitor name : " + Convert.ToString(monitor.name);
                        msg += " IP Address : " + Convert.ToString(monitor.monitorIPAddress);
                        msg += " Frequency : " + Convert.ToString(startMonitorEvent.surgeryIntervalFrequency);

                        //Additional logging, Feb 2017
                        //---------------------------Starts---------------
                        msg += " EventReceivedDateTime : " + Convert.ToString(eventReceivedDateTime);
                        msg += " ClientLastName : " + Convert.ToString(startMonitorEvent.clientLastName);
                        msg += " HospitalizationId : " + Convert.ToString(startMonitorEvent.hospitalizationId);
                        msg += " PatientName : " + Convert.ToString(startMonitorEvent.patientName);
                        msg += " SurgeryId : " + Convert.ToString(startMonitorEvent.surgeryId);
                        msg += " SurgeryStartDate : " + Convert.ToString(startMonitorEvent.surgeryStartDate);
                        //---------------------------Ends---------------
                        msg += " temperatureUnits : " + Convert.ToString(startMonitorEvent.temperatureUnits);

                        LogWriter.WriteToFile(msg, LogHelperUtility.GetTraceFileNameForAdminApp());

                        switch (deviceName)
                        {
                            case DeviceNames.Cardell:
                                msg = "Started Cardell surgery!";
                                LogWriter.WriteToFile(msg, LogHelperUtility.GetTraceFileNameForAdminApp());
                                result = StartMonitor_Cardell(startMonitorEvent);
                                break;
                            case DeviceNames.DigiCare:
                                msg = "Started DigiCare surgery!";
                                LogWriter.WriteToFile(msg, LogHelperUtility.GetTraceFileNameForAdminApp());
                                result = StartMonitor_DigiCare(startMonitorEvent);
                                break;
                            case DeviceNames.VetLand:
                                msg = "Started VetLand surgery!";
                                LogWriter.WriteToFile(msg, LogHelperUtility.GetTraceFileNameForAdminApp());
                                result = StartMonitor_VetLand(startMonitorEvent);
                                break;
                            case DeviceNames.BioNet:
                                msg = "Started BioNet surgery!";
                                LogWriter.WriteToFile(msg, LogHelperUtility.GetTraceFileNameForAdminApp());
                                result = StartMonitor_BioNet(startMonitorEvent);
                                break;
                        }
                    }
                    else
                    {
                        result = new SurgeryMonitorStatus
                        {
                            monitorId = startMonitorEvent.monitorId,
                            status = SurgeryMonitorStatus.Status.ConnectionToMonitorFailed,
                            statusMessage = CommonMessages.MonitorIsNotAvailable
                        };

                        //#Evg.16 - Monitor is not available
                        //Action: Listener sends error message to Status-API ;
                        //Action: Listener adds log message
                        SurgeryMonitorStatusHelper.PostSurgeryMonitorStatusWithLogInAdminAppTrace(
                                                  startMonitorEvent.monitorId
                                                , CommonMessages.MonitorIsNotAvailable
                                                , SurgeryMonitorStatus.Status.ConnectionToMonitorFailed);

                        LogWriter.WriteToFile(CommonMessages.MonitorIsNotAvailable, LogHelperUtility.GetErrorFileNameForAdminApp());
                    }
                }
                else
                {
                    LogWriter.WriteToFile(CommonMessages.StartSurgeryMonitorDoesNotHaveEnoughInformation, LogHelperUtility.GetErrorFileNameForAdminApp());
                    throw new Exception(CommonMessages.StartSurgeryMonitorDoesNotHaveEnoughInformation);
                }
            }
            catch (Exception ex)
            {
                LogWriter.WriteToFile(ex.ToString(), LogHelperUtility.GetErrorFileNameForAdminApp());

                //#Evg.9 - SFS-server can't start monitor
                //Action: Listener responds with error message to SFS-server;
                result = new SurgeryMonitorStatus
                {
                    monitorId = startMonitorEvent.monitorId,
                    status = SurgeryMonitorStatus.Status.ConnectionToMonitorFailed,
                    statusMessage = CommonMessages.SFSserverCannotStartMonitor
                };

                //Action: Listener updates monitor status using Status - API
                SurgeryMonitorStatusHelper.PostSurgeryMonitorStatusWithLogInAdminAppTrace(
                                                  startMonitorEvent.monitorId
                                                , CommonMessages.SFSserverCannotStartMonitor
                                                , SurgeryMonitorStatus.Status.ConnectionToMonitorFailed);
            }
            return result;
        }

        /// <summary>
        /// Stop Monitor method
        /// </summary>
        /// <param name="stopMonitorEvent"></param>
        /// <returns></returns>
        /// <CreatedBy>Om Shakya</CreatedBy>
        /// <CreatedDate>Oct 2016</CreatedDate>
        /// <ModifyBy>...</ModifyBy>
        /// <ModifyDate>...</ModifyDate>
        public SurgeryMonitorStatus StopMonitor(StopSurgeryMonitor stopMonitorEvent)
        {
            SurgeryMonitorStatus result = null;

            //Additional logging, Feb 2017
            DateTime eventReceivedDateTime = DateTime.Now;
            try
            {
                if (IsStopSurgeryMonitorValid(stopMonitorEvent))
                {
                    //Get all the registered surgery monitor devices list
                    ObjectSerializer.SurgeryMonitor monitor = SerializedObjects.GetSurgeryMonitorDevice(stopMonitorEvent.monitorId);
                    if (monitor != null)
                    {
                        DeviceNames deviceName = (DeviceNames)Enum.Parse(typeof(DeviceNames), monitor.deviceName);

                        string msg = "Received (StopSurgeryEvent) monitor id: " + stopMonitorEvent.monitorId.ToString();
                        msg += " Device name : " + deviceName.ToString();
                        msg += " Monitor name : " + monitor.name.ToString();
                        msg += " IP Address : " + monitor.monitorIPAddress.ToString();

                        //Additional logging, Feb 2017
                        //---------------------------Starts---------------
                        msg += " EventReceivedDateTime : " + eventReceivedDateTime.ToString();
                        msg += " EventType : " + stopMonitorEvent.eventType.ToString();
                        //---------------------------Ends---------------

                        LogWriter.WriteToFile(msg, LogHelperUtility.GetTraceFileNameForAdminApp());

                        switch (deviceName)
                        {
                            case DeviceNames.Cardell:
                                msg = "Stopped Cardell surgery!";
                                LogWriter.WriteToFile(msg, LogHelperUtility.GetTraceFileNameForAdminApp());
                                result = StopMonitor_Cardell(stopMonitorEvent);
                                break;
                            case DeviceNames.DigiCare:
                                msg = "Stopped DigiCare surgery!";
                                LogWriter.WriteToFile(msg, LogHelperUtility.GetTraceFileNameForAdminApp());
                                result = StopMonitor_DigiCare(stopMonitorEvent);
                                break;
                            case DeviceNames.VetLand:
                                msg = "Stopped Vetland surgery!";
                                LogWriter.WriteToFile(msg, LogHelperUtility.GetTraceFileNameForAdminApp());
                                result = StopMonitor_Vetland(stopMonitorEvent);
                                break;
                            case DeviceNames.BioNet:
                                msg = "Stopped BioNet surgery!";
                                LogWriter.WriteToFile(msg, LogHelperUtility.GetTraceFileNameForAdminApp());
                                result = StopMonitor_BioNet(stopMonitorEvent);
                                break;
                        }
                    }
                    else
                    {
                        LogWriter.WriteToFile(CommonMessages.MonitorNotFoundOnLocalDisk, LogHelperUtility.GetErrorFileNameForAdminApp());
                        throw new Exception(CommonMessages.MonitorNotFoundOnLocalDisk);
                    }
                }
                else
                {
                    LogWriter.WriteToFile(CommonMessages.StopSurgeryMonitorDoesNotHaveEnoughInformation, LogHelperUtility.GetErrorFileNameForAdminApp());
                    throw new Exception(CommonMessages.StopSurgeryMonitorDoesNotHaveEnoughInformation);
                }
            }
            catch (Exception ex)
            {
                LogWriter.WriteToFile(ex.ToString(), LogHelperUtility.GetErrorFileNameForAdminApp());

                //#Evg.10 - SFS-server can't stop monitor
                //Action: Listener responds with error message to SFS-server;
                result = new SurgeryMonitorStatus
                {
                    monitorId = stopMonitorEvent.monitorId,
                    status = SurgeryMonitorStatus.Status.ConnectionToMonitorFailed,
                    statusMessage = CommonMessages.SFSserverCannotStopMonitor// ex.Message
                };

                //Action: Listener updates monitor status using Status-API
                SurgeryMonitorStatusHelper.PostSurgeryMonitorStatusWithLogInAdminAppTrace(
                                                stopMonitorEvent.monitorId
                                                , CommonMessages.SFSserverCannotStopMonitor
                                                , SurgeryMonitorStatus.Status.ConnectionToMonitorFailed);
            }
            return result;
        }

        #region Common methods

        /// <summary>
        /// Common method to run the logic to stop the monitor if httpstatus code is 404 or 405.
        /// </summary>
        /// <param name="deviceIdentifier"></param>
        /// <CreatedBy>Om Shakya</CreatedBy>
        /// <CreatedDate>Nov 2016</CreatedDate>
        /// <ModifyBy>...</ModifyBy>
        /// <ModifyDate>...</ModifyDate>
        private void CommonTimerElapsedEventMethod(DeviceIdentifier deviceIdentifier)
        {
            try
            {
                //Retrive the list of monitors that are marked to stop when http status code is 404
                List<StopMonitorBasedOnStatusCode> list = SerializedObjects.GetListMonitorsToStopBasedOnStatusCode(deviceIdentifier);
                if (list != null && list.Count > 0)
                {
                    foreach (StopMonitorBasedOnStatusCode obj in list)
                    {
                        if (obj != null)
                        {
                            if (obj.httpStatusCode.Equals(HttpStatusCode.NotFound) || obj.httpStatusCode.Equals(HttpStatusCode.MethodNotAllowed))
                            {
                                string msg = "OnElapsedEventOfTimer_ elapsed : " + deviceIdentifier.ToString();
                                msg += " obj.httpStatusCode: " + obj.httpStatusCode.ToString();

                                //Prepare the stop surgery monitor object
                                StopSurgeryMonitor topSurgeryMonitor = new StopSurgeryMonitor();
                                topSurgeryMonitor.monitorId = obj.monitorId;
                                SurgeryMonitorStatus stopMonitorStatus = StopMonitor(topSurgeryMonitor);

                                msg += " StopMonitor(topSurgeryMonitor) sent: " + obj.monitorId.ToString();

                                if (stopMonitorStatus.status.Equals(SurgeryMonitorStatus.Status.Stopped))
                                {
                                    string filePath = SettingsUtility.GetCommonDataPath(CommonDataSettingTypes.SettingsContainer_Folder, deviceIdentifier)
                                            + "\\MonitorsToStopBasedOnStatusCode\\SFS.Monitor." + obj.monitorId.ToString() + ".sfs";

                                    msg += " filePath: " + filePath;
                                    if (System.IO.File.Exists(filePath))
                                    {
                                        System.IO.File.Delete(filePath);
                                        msg += " System.IO.File.Delete(filePath): " + filePath;
                                    }
                                }
                                LogWriter.WriteToFile(msg, LogHelperUtility.GetTraceFileNameForAdminApp());
                            }
                        }
                    }
                }

            }
            catch
            {
                throw;
            }
        }
        /// <summary>
        /// Method to verify that the SurgeryMonitor is valid or not.
        /// </summary>
        /// <param name="startMonitorEvent"></param>
        /// <returns></returns>
        private static bool IsStartSurgeryMonitorValid(StartSurgeryMonitor startMonitorEvent)
        {
            //Additional logging, Feb 2017
            //Refined this method completely.
            bool b = false;
            StringBuilder txt = new StringBuilder();
            txt.Append(" Validating the startMonitorEvent.");
            try
            {
                if (startMonitorEvent != null)
                {
                    txt.Append(" clientLastName : " + Convert.ToString(startMonitorEvent.clientLastName));
                    txt.Append(" eventType : " + Convert.ToString(startMonitorEvent.eventType));
                    txt.Append(" hospitalizationId : " + Convert.ToString(startMonitorEvent.hospitalizationId));
                    txt.Append(" monitorId : " + Convert.ToString(startMonitorEvent.monitorId));
                    txt.Append(" patientName : " + Convert.ToString(startMonitorEvent.patientName));
                    txt.Append(" surgeryId : " + Convert.ToString(startMonitorEvent.surgeryId));
                    txt.Append(" surgeryIntervalFrequency : " + Convert.ToString(startMonitorEvent.surgeryIntervalFrequency));
                    txt.Append(" surgeryStartDate : " + Convert.ToString(startMonitorEvent.surgeryStartDate));
                    txt.Append(" temperatureUnits : " + Convert.ToString(startMonitorEvent.temperatureUnits));

                    if (!string.IsNullOrEmpty(Convert.ToString(startMonitorEvent.hospitalizationId)) &&
                        !string.IsNullOrEmpty(Convert.ToString(startMonitorEvent.monitorId)) &&
                        !string.IsNullOrEmpty(Convert.ToString(startMonitorEvent.surgeryId)) &&
                        !string.IsNullOrEmpty(Convert.ToString(startMonitorEvent.surgeryIntervalFrequency)) &&
                        startMonitorEvent.surgeryIntervalFrequency > 0 &&
                        !string.IsNullOrEmpty(Convert.ToString(startMonitorEvent.surgeryStartDate)))
                        b = true;
                }
                txt.Append(" startMonitorEvent is valid : " + b.ToString());

                return b;
            }
            catch
            {
                throw;
            }
            finally
            {
                LogWriter.WriteToFile(txt.ToString(), LogHelperUtility.GetTraceFileNameForAdminApp());
            }
        }
        /// <summary>
        /// Method to check that the surgerymonitor to stop is valid.
        /// </summary>
        /// <param name="stopMonitorEvent"></param>
        /// <returns></returns>
        private static bool IsStopSurgeryMonitorValid(StopSurgeryMonitor stopMonitorEvent)
        {
            bool b = false;
            try
            {
                if (stopMonitorEvent != null)
                {
                    string msg = string.Empty;
                    msg += " Validating the stopMonitorEvent." + Environment.NewLine;
                    msg += "eventType : " + Convert.ToString(stopMonitorEvent.eventType) + Environment.NewLine;
                    msg += "monitorId : " + Convert.ToString(stopMonitorEvent.monitorId) + Environment.NewLine;

                    LogWriter.WriteToFile(msg, LogHelperUtility.GetTraceFileNameForAdminApp());

                    if (!string.IsNullOrEmpty(Convert.ToString(stopMonitorEvent.eventType)) &&
                        !string.IsNullOrEmpty(Convert.ToString(stopMonitorEvent.monitorId)))
                        b = true;
                }
                return b;
            }
            catch
            {
                throw;
            }
        }
        #endregion

        #region Cardell Server code block starts
        /// <summary>
        /// Start monitor method for Cardell
        /// </summary>
        /// <param name="startMonitorEvent"></param>
        /// <returns></returns>
        /// <CreatedBy>Om Shakya</CreatedBy>
        /// <CreatedDate>Oct 2016</CreatedDate>
        /// <ModifyBy>...</ModifyBy>
        /// <ModifyDate>...</ModifyDate>
        private SurgeryMonitorStatus StartMonitor_Cardell(StartSurgeryMonitor startMonitorEvent)
        {
            try
            {
                //LOGIC to Start the Cardell listener
                KeepWatchOnStatusCode_Cardell();

                string msg = string.Empty;

                //Check whether this surgery monitor is in use or not, if not then start it
                if (!CardellSurgeryMonitorThreads.Keys.Contains(startMonitorEvent.monitorId))
                {
                    msg += "Starting monitor - " + startMonitorEvent.monitorId.ToString();
                    msg += Environment.NewLine + "Starting surgeryId - " + startMonitorEvent.surgeryId.ToString();

                    //Create and start a thread to start the surgery monitor
                    Thread threadStartSurgeryMonitor = new Thread(new ParameterizedThreadStart(StartMonitorHandler_Cardell));
                    threadStartSurgeryMonitor.Start(startMonitorEvent);

                    //Add this surgery monitor in collection
                    CardellSurgeryMonitorThreads.Add(startMonitorEvent.monitorId, threadStartSurgeryMonitor);
                    CardellStartMonitorEvent.Add(startMonitorEvent.monitorId, startMonitorEvent);
                }
                //If monitor is already in use
                else
                {
                    msg += Environment.NewLine + "Already started monitor - " + startMonitorEvent.monitorId.ToString();
                    msg += Environment.NewLine + "Already started - new surgeryId - " + startMonitorEvent.surgeryId.ToString();

                    //if surgeryId does not match
                    //then stop the previous one and start the surgery

                    if (CardellStartMonitorEvent[startMonitorEvent.monitorId] != null)
                    {
                        bool doesExists = false;
                        doesExists = CardellStartMonitorEvent[startMonitorEvent.monitorId].surgeryId.Equals(startMonitorEvent.surgeryId);

                        msg += Environment.NewLine + "Already started - existing surgeryId - " + CardellStartMonitorEvent[startMonitorEvent.monitorId].surgeryId.ToString();
                        //If surgeryId for the existing monitor does not exists
                        //If monitor has a new surgeryId for surgery
                        if (!doesExists)
                        {
                            msg += Environment.NewLine + "Both surgeryId id differs! Stoping existing monitor!";

                            StopSurgeryMonitor obj = new StopSurgeryMonitor();
                            obj.monitorId = startMonitorEvent.monitorId;
                            SurgeryMonitorStatus stopMonitorStatus = StopMonitor(obj);
                            System.Threading.Thread.Sleep(1000);

                            SurgeryMonitorStatus.Status status = stopMonitorStatus.status;
                            if (status.Equals(SurgeryMonitorStatus.Status.Stopped))
                            {
                                msg += Environment.NewLine + "Existing monitor stopped! Starting this monitor with new surgeryId id!";

                                //Create and start a thread to start the surgery monitor
                                Thread threadStartSurgeryMonitor = new Thread(new ParameterizedThreadStart(StartMonitorHandler_Cardell));
                                threadStartSurgeryMonitor.Start(startMonitorEvent);

                                //Add this surgery monitor in collection
                                CardellSurgeryMonitorThreads.Add(startMonitorEvent.monitorId, threadStartSurgeryMonitor);
                                CardellStartMonitorEvent.Add(startMonitorEvent.monitorId, startMonitorEvent);

                                msg += Environment.NewLine + "Started this monitor with new surgeryId id!";
                            }
                            else
                            {
                                msg += Environment.NewLine + "Existing monitor could not be stopped!";
                                return new SurgeryMonitorStatus
                                {
                                    monitorId = startMonitorEvent.monitorId,
                                    status = SurgeryMonitorStatus.Status.ConnectionToMonitorFailed,
                                    statusMessage = "Surgery could not be started for already started monitor with different surgeryId id."
                                };
                            }
                        }
                        //If surgeryId for the existing monitor exists then post the anesthetic values right away
                        else
                        {
                            msg += Environment.NewLine + "Existing monitor with existing surgeryId id!";
                            CardellServer.PostAnestheticValuesOnDemand(startMonitorEvent);
                        }
                    }
                }
                LogWriter.WriteToFile(msg, LogHelperUtility.GetLogFileNameForCommonTraceing(DeviceIdentifier.Cardell, startMonitorEvent.monitorId.ToString()));

                return new SurgeryMonitorStatus
                {
                    monitorId = startMonitorEvent.monitorId,
                    status = SurgeryMonitorStatus.Status.Active,
                };
            }
            catch (Exception ex)
            {
                LogWriter.WriteToFile(ex.ToString(), LogHelperUtility.GetLogFileNameForCommonTraceing(DeviceIdentifier.Cardell, startMonitorEvent.monitorId.ToString()));
                throw;
            }
        }
        /// <summary>
        /// Start monitor handler for Cardell
        /// </summary>
        /// <param name="obj"></param>
        /// <CreatedBy>Om Shakya</CreatedBy>
        /// <CreatedDate>Oct 2016</CreatedDate>
        /// <ModifyBy>...</ModifyBy>
        /// <ModifyDate>...</ModifyDate>
        private void StartMonitorHandler_Cardell(object obj)
        {
            try
            {
                StartSurgeryMonitor startSurgeryMonitor = (StartSurgeryMonitor)obj;
                Console.WriteLine();
                CardellServer.StartServer(startSurgeryMonitor);
            }
            catch
            {
                throw;
            }
        }
        /// <summary>
        /// Stop monitor mothod for Cardell
        /// </summary>
        /// <param name="stopMonitorEvent"></param>
        /// <returns></returns>
        /// <CreatedBy>Om Shakya</CreatedBy>
        /// <CreatedDate>Oct 2016</CreatedDate>
        /// <ModifyBy>...</ModifyBy>
        /// <ModifyDate>...</ModifyDate>
        private static SurgeryMonitorStatus StopMonitor_Cardell(StopSurgeryMonitor stopMonitorEvent)
        {
            try
            {
                //LOGIC to stop the Cardell listener

                string msg = string.Empty;
                if (CardellSurgeryMonitorThreads[stopMonitorEvent.monitorId] != null)
                {
                    //Set the disconnect flag to true
                    SettingsUtility.SetDisconnectSetting(DisconnectSetting.True, DeviceIdentifier.Cardell, stopMonitorEvent.monitorId.ToString());
                    msg += "Diconnect flag set to true!";

                    //Stop the Cardell listener
                    CardellServer.StopServer(stopMonitorEvent);
                    msg += "Cardell Server stoped!";

                    //Abort the CardellSurgeryMonitorThread of this monitor
                    CardellSurgeryMonitorThreads[stopMonitorEvent.monitorId].Abort();
                    msg += "CardellSurgeryMonitorThreads aborted!";

                    //Remove the CardellSurgeryMonitorThread for this monitor
                    CardellSurgeryMonitorThreads.Remove(stopMonitorEvent.monitorId);
                    msg += "CardellSurgeryMonitorThreads removed!";

                    if (CardellStartMonitorEvent[stopMonitorEvent.monitorId] != null)
                    {
                        CardellStartMonitorEvent.Remove(stopMonitorEvent.monitorId);
                    }
                }

                LogWriter.WriteToFile(msg, LogHelperUtility.GetLogFileNameForCommonTraceing(DeviceIdentifier.Cardell,
                                                                                stopMonitorEvent.monitorId.ToString()));

                return new SurgeryMonitorStatus
                {
                    monitorId = stopMonitorEvent.monitorId,
                    status = SurgeryMonitorStatus.Status.Stopped,
                };
            }
            catch (Exception ex)
            {
                LogWriter.WriteToFile(ex.ToString(), LogHelperUtility.GetLogFileNameForCommonTraceing(DeviceIdentifier.Cardell,
                                                                                stopMonitorEvent.monitorId.ToString()));
                throw;
            }
        }
        /// <summary>
        /// Keep Watch On StatusCode forCardell
        /// </summary>
        /// <CreatedBy>Om Shakya</CreatedBy>
        /// <CreatedDate>Nov 2016</CreatedDate>
        /// <ModifyBy>...</ModifyBy>
        /// <ModifyDate>...</ModifyDate>
        private void KeepWatchOnStatusCode_Cardell()
        {
            try
            {
                string msg = "HasStopMonitorBasedOnStatusCodeTimerStartedCardell: " + HasStopMonitorBasedOnStatusCodeTimerStartedCardell.ToString();
                if (!HasStopMonitorBasedOnStatusCodeTimerStartedCardell)
                {
                    //Note: This object can not be disposed, if it is disposed application will break.
                    System.Timers.Timer timerWatch = new System.Timers.Timer();
                    double interval = 10 * 1000;

                    //Handle data transfer elapsed event
                    timerWatch.Elapsed += (sender, e) => OnElapsedEventOfTimer_Cardell(sender, e);
                    timerWatch.Interval = Convert.ToInt32(interval);
                    timerWatch.Enabled = true;
                    timerWatch.Start();
                    HasStopMonitorBasedOnStatusCodeTimerStartedCardell = true;
                    msg += " HasStopMonitorBasedOnStatusCodeTimerStartedCardell: " + HasStopMonitorBasedOnStatusCodeTimerStartedCardell.ToString();
                    msg += " timerWatch started";
                }

                LogWriter.WriteToFile(msg, LogHelperUtility.GetTraceFileNameForAdminApp());
            }
            catch
            {
                throw;
            }
        }
        /// <summary>
        /// On Elapsed Event Of Timer for Cardell
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// <CreatedBy>Om Shakya</CreatedBy>
        /// <CreatedDate>Nov 2016</CreatedDate>
        /// <ModifyBy>...</ModifyBy>
        /// <ModifyDate>...</ModifyDate>
        private void OnElapsedEventOfTimer_Cardell(object sender, ElapsedEventArgs e)
        {
            try
            {
                CommonTimerElapsedEventMethod(DeviceIdentifier.Cardell);

                //Check if still any surgery is running, if not then dispose the timer and set the flag to false
                if (CardellSurgeryMonitorThreads == null || CardellSurgeryMonitorThreads.Count == 0)
                {
                    try
                    {
                        HasStopMonitorBasedOnStatusCodeTimerStartedCardell = false;
                        System.Timers.Timer timer = (System.Timers.Timer)sender;
                        timer.Elapsed -= (sen, eve) => OnElapsedEventOfTimer_Cardell(sen, eve);
                        timer.Stop();
                        timer.Dispose();
                    }
                    catch { throw; }
                }
            }
            catch
            {
                throw;
            }

        }
        #endregion Cardell Server code block ends

        #region  DigiCare Server code block starts
        /// <summary>
        /// Start monitor method for DigiCare
        /// </summary>
        /// <param name="startMonitorEvent"></param>
        /// <returns></returns>
        /// <CreatedBy>Om Shakya</CreatedBy>
        /// <CreatedDate>Oct 2016</CreatedDate>
        /// <ModifyBy>...</ModifyBy>
        /// <ModifyDate>...</ModifyDate>
        private SurgeryMonitorStatus StartMonitor_DigiCare(StartSurgeryMonitor startMonitorEvent)
        {
            try
            {
               
                //LOGIC to Start the Digicare listener
                KeepWatchOnStatusCode_DigiCare();

                string msg = string.Empty;

                //Check whether this surgery monitor is in use or not, if not then start it
                if (!DigiCareSurgeryMonitorThreads.Keys.Contains(startMonitorEvent.monitorId))
                {
                    msg += "Starting monitor - " + startMonitorEvent.monitorId.ToString();
                    msg += Environment.NewLine + "Starting surgeryId - " + startMonitorEvent.surgeryId.ToString();

                    //Create and start a thread to start the surgery monitor
                    Thread threadStartSurgeryMonitor = new Thread(new ParameterizedThreadStart(StartMonitorHandler_DigiCare));
                    threadStartSurgeryMonitor.Start(startMonitorEvent);

                    //Add this surgery monitor in collection
                    DigiCareSurgeryMonitorThreads.Add(startMonitorEvent.monitorId, threadStartSurgeryMonitor);
                    DigiCareStartMonitorEvent.Add(startMonitorEvent.monitorId, startMonitorEvent);
                }
                //If monitor is already in use
                else
                {
                    msg += Environment.NewLine + "Already started monitor - " + startMonitorEvent.monitorId.ToString();
                    msg += Environment.NewLine + "Already started - new surgeryId - " + startMonitorEvent.surgeryId.ToString();

                    //if surgeryId id does not match
                    //then stop the previous one and start the surgery

                    if (DigiCareStartMonitorEvent[startMonitorEvent.monitorId] != null)
                    {
                        bool doesExists = false;
                        doesExists = DigiCareStartMonitorEvent[startMonitorEvent.monitorId].surgeryId.Equals(startMonitorEvent.surgeryId);

                        msg += Environment.NewLine + "Already started - existing surgeryId - " + DigiCareStartMonitorEvent[startMonitorEvent.monitorId].surgeryId.ToString();
                        //If surgeryId for the existing monitor does not exists
                        //If monitor has a new surgeryId for surgery
                        if (!doesExists)
                        {
                            msg += Environment.NewLine + "Both surgeryId id differs! Stoping existing monitor!";

                            StopSurgeryMonitor obj = new StopSurgeryMonitor();
                            obj.monitorId = startMonitorEvent.monitorId;
                            SurgeryMonitorStatus stopMonitorStatus = StopMonitor(obj);
                            System.Threading.Thread.Sleep(1000);

                            SurgeryMonitorStatus.Status status = stopMonitorStatus.status;
                            if (status.Equals(SurgeryMonitorStatus.Status.Stopped))
                            {
                                msg += Environment.NewLine + "Existing monitor stopped! Starting this monitor with new surgeryId id!";
                                //Create and start a thread to start the surgery monitor
                                Thread threadStartSurgeryMonitor = new Thread(new ParameterizedThreadStart(StartMonitorHandler_DigiCare));
                                threadStartSurgeryMonitor.Start(startMonitorEvent);

                                //Add this surgery monitor in collection
                                DigiCareSurgeryMonitorThreads.Add(startMonitorEvent.monitorId, threadStartSurgeryMonitor);
                                DigiCareStartMonitorEvent.Add(startMonitorEvent.monitorId, startMonitorEvent);

                                msg += Environment.NewLine + "Started this monitor with new surgeryId id!";
                            }
                            else
                            {
                                msg += Environment.NewLine + "Existing monitor could not be stopped!";
                                return new SurgeryMonitorStatus
                                {
                                    monitorId = startMonitorEvent.monitorId,
                                    status = SurgeryMonitorStatus.Status.ConnectionToMonitorFailed,
                                    statusMessage = "Surgery could not be started for already started monitor with different surgeryId id."
                                };
                            }
                        }
                        //If surgeryId id for the existing monitor exists then post the anesthetic values right away
                        else
                        {
                            msg += Environment.NewLine + "Existing monitor with existing surgeryId id!";
                            DigicareServer.PostAnestheticValuesOnDemand(startMonitorEvent);
                        }
                    }
                }
                LogWriter.WriteToFile(msg, LogHelperUtility.GetLogFileNameForCommonTraceing(DeviceIdentifier.DigiCare, startMonitorEvent.monitorId.ToString()));

                return new SurgeryMonitorStatus
                {
                    monitorId = startMonitorEvent.monitorId,
                    status = SurgeryMonitorStatus.Status.Active,
                };
            }
            catch (Exception ex)
            {
                LogWriter.WriteToFile(ex.ToString(), LogHelperUtility.GetLogFileNameForCommonTraceing(DeviceIdentifier.DigiCare, startMonitorEvent.monitorId.ToString()));
                throw;
            }
        }
        /// <summary>
        /// Start monitor handler for DigiCare
        /// </summary>
        /// <param name="obj"></param>
        /// <CreatedBy>Om Shakya</CreatedBy>
        /// <CreatedDate>Oct 2016</CreatedDate>
        /// <ModifyBy>...</ModifyBy>
        /// <ModifyDate>...</ModifyDate>
        private void StartMonitorHandler_DigiCare(object obj)
        {
            try
            {
                StartSurgeryMonitor startSurgeryMonitor = (StartSurgeryMonitor)obj;
                Console.WriteLine();
                DigicareServer.StartServer(startSurgeryMonitor);
            }
            catch
            {
                throw;
            }
        }
        /// <summary>
        /// Stop monitor for DigiCare
        /// </summary>
        /// <param name="stopMonitorEvent"></param>
        /// <returns></returns>
        /// <CreatedBy>Om Shakya</CreatedBy>
        /// <CreatedDate>Oct 2016</CreatedDate>
        /// <ModifyBy>...</ModifyBy>
        /// <ModifyDate>...</ModifyDate>
        private static SurgeryMonitorStatus StopMonitor_DigiCare(StopSurgeryMonitor stopMonitorEvent)
        {
            try
            {
                //LOGIC to stop the DigiCare listener

                string msg = string.Empty;
                if (DigiCareSurgeryMonitorThreads[stopMonitorEvent.monitorId] != null)
                {
                    //Set the disconnect flag to true
                    SettingsUtility.SetDisconnectSetting(DisconnectSetting.True, DeviceIdentifier.DigiCare, stopMonitorEvent.monitorId.ToString());
                    msg += "Diconnect flag set to true!";

                    //Stop the DigiCare listener
                    DigicareServer.StopServer(stopMonitorEvent);
                    msg += "DigiCare Server stoped!";

                    //Abort the DigiCareSurgeryMonitorThread of this monitor
                    DigiCareSurgeryMonitorThreads[stopMonitorEvent.monitorId].Abort();
                    msg += "DigiCareSurgeryMonitorThreads aborted!";

                    //Remove the DigiCareSurgeryMonitorThread for this monitor
                    DigiCareSurgeryMonitorThreads.Remove(stopMonitorEvent.monitorId);
                    msg += "DigiCareSurgeryMonitorThreads removed!";

                    if (DigiCareStartMonitorEvent[stopMonitorEvent.monitorId] != null)
                    {
                        DigiCareStartMonitorEvent.Remove(stopMonitorEvent.monitorId);
                    }
                }

                LogWriter.WriteToFile(msg, LogHelperUtility.GetLogFileNameForCommonTraceing(DeviceIdentifier.DigiCare,
                                                                                stopMonitorEvent.monitorId.ToString()));

                return new SurgeryMonitorStatus
                {
                    monitorId = stopMonitorEvent.monitorId,
                    status = SurgeryMonitorStatus.Status.Stopped,
                };
            }
            catch (Exception ex)
            {
                LogWriter.WriteToFile(ex.ToString(), LogHelperUtility.GetLogFileNameForCommonTraceing(DeviceIdentifier.DigiCare,
                                                                                stopMonitorEvent.monitorId.ToString()));
                throw;
            }
        }
        /// <summary>
        /// Keep Watch On StatusCode fro DigiCare
        /// </summary>
        /// <CreatedBy>Om Shakya</CreatedBy>
        /// <CreatedDate>Nov 2016</CreatedDate>
        /// <ModifyBy>...</ModifyBy>
        /// <ModifyDate>...</ModifyDate>
        private void KeepWatchOnStatusCode_DigiCare()
        {
            try
            {
                string msg = "HasStopMonitorBasedOnStatusCodeTimerStartedDigiCare: " + HasStopMonitorBasedOnStatusCodeTimerStartedDigiCare.ToString();
                if (!HasStopMonitorBasedOnStatusCodeTimerStartedDigiCare)
                {
                    //Note: This object can not be disposed, if it is disposed application will break.
                    System.Timers.Timer timerWatch = new System.Timers.Timer();
                    double interval = 10 * 1000;

                    //Handle data transfer elapsed event
                    timerWatch.Elapsed += (sender, e) => OnElapsedEventOfTimer_DigiCare(sender, e);
                    timerWatch.Interval = Convert.ToInt32(interval);
                    timerWatch.Enabled = true;
                    timerWatch.Start();
                    HasStopMonitorBasedOnStatusCodeTimerStartedDigiCare = true;
                    msg += " HasStopMonitorBasedOnStatusCodeTimerStartedDigiCare: " + HasStopMonitorBasedOnStatusCodeTimerStartedDigiCare.ToString();
                    msg += " timerWatch started";
                }

                LogWriter.WriteToFile(msg, LogHelperUtility.GetTraceFileNameForAdminApp());
            }
            catch
            {
                throw;
            }
        }
        /// <summary>
        /// On Elapsed Event Of Timer for DigiCare
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// <CreatedBy>Om Shakya</CreatedBy>
        /// <CreatedDate>Nov 2016</CreatedDate>
        /// <ModifyBy>...</ModifyBy>
        /// <ModifyDate>...</ModifyDate>
        private void OnElapsedEventOfTimer_DigiCare(object sender, ElapsedEventArgs e)
        {
            try
            {
                CommonTimerElapsedEventMethod(DeviceIdentifier.DigiCare);

                //Check if still any surgery is running, if not then dispose the timer and set the flag to false
                if (DigiCareSurgeryMonitorThreads == null || DigiCareSurgeryMonitorThreads.Count == 0)
                {
                    try
                    {
                        HasStopMonitorBasedOnStatusCodeTimerStartedDigiCare = false;
                        System.Timers.Timer timer = (System.Timers.Timer)sender;
                        timer.Elapsed -= (sen, eve) => OnElapsedEventOfTimer_DigiCare(sen, eve);
                        timer.Stop();
                        timer.Dispose();
                    }
                    catch { throw; }
                }
            }
            catch
            {
                throw;
            }
        }
        #endregion DigiCare Server code block ends

        #region  VetLand Server code block starts
        private SurgeryMonitorStatus StartMonitor_VetLand(StartSurgeryMonitor startMonitorEvent)
        {
            try
            {
                //LOGIC to Start the Vetland listener
                KeepWatchOnStatusCode_VetLand();

                string msg = string.Empty;

                //Check whether this surgery monitor is in use or not, if not then start it
                if (!VetLandSurgeryMonitorThreads.Keys.Contains(startMonitorEvent.monitorId))
                {
                    msg += "Starting monitor - " + startMonitorEvent.monitorId.ToString();
                    msg += Environment.NewLine + "Starting surgeryId - " + startMonitorEvent.surgeryId.ToString();

                    //Create and start a thread to start the surgery monitor
                    Thread threadStartSurgeryMonitor = new Thread(new ParameterizedThreadStart(StartMonitorHandler_Vetland));
                    threadStartSurgeryMonitor.Start(startMonitorEvent);

                    //Add this surgery monitor in collection
                    VetLandSurgeryMonitorThreads.Add(startMonitorEvent.monitorId, threadStartSurgeryMonitor);
                    VetLandStartMonitorEvent.Add(startMonitorEvent.monitorId, startMonitorEvent);
                }
                //If monitor is already in use
                else
                {
                    msg += Environment.NewLine + "Already started monitor - " + startMonitorEvent.monitorId.ToString();
                    msg += Environment.NewLine + "Already started - new surgeryId - " + startMonitorEvent.surgeryId.ToString();

                    //if surgeryId id does not match
                    //then stop the previous one and start the surgery

                    if (VetLandStartMonitorEvent[startMonitorEvent.monitorId] != null)
                    {
                        bool doesExists = false;
                        doesExists = VetLandStartMonitorEvent[startMonitorEvent.monitorId].surgeryId.Equals(startMonitorEvent.surgeryId);

                        msg += Environment.NewLine + "Already started - existing surgeryId - " + VetLandStartMonitorEvent[startMonitorEvent.monitorId].surgeryId.ToString();
                        //If surgeryId id for the existing monitor does not exists
                        //If monitor has a new surgeryId for surgery
                        if (!doesExists)
                        {
                            msg += Environment.NewLine + "Both surgeryId differs! Stoping existing monitor!";

                            StopSurgeryMonitor obj = new StopSurgeryMonitor();
                            obj.monitorId = startMonitorEvent.monitorId;
                            SurgeryMonitorStatus stopMonitorStatus = StopMonitor(obj);
                            System.Threading.Thread.Sleep(1000);

                            SurgeryMonitorStatus.Status status = stopMonitorStatus.status;
                            if (status.Equals(SurgeryMonitorStatus.Status.Stopped))
                            {
                                msg += Environment.NewLine + "Existing monitor stopped! Starting this monitor with new surgeryId!";
                                //Create and start a thread to start the surgery monitor
                                Thread threadStartSurgeryMonitor = new Thread(new ParameterizedThreadStart(StartMonitorHandler_Vetland));
                                threadStartSurgeryMonitor.Start(startMonitorEvent);

                                //Add this surgery monitor in collection
                                VetLandSurgeryMonitorThreads.Add(startMonitorEvent.monitorId, threadStartSurgeryMonitor);
                                VetLandStartMonitorEvent.Add(startMonitorEvent.monitorId, startMonitorEvent);

                                msg += Environment.NewLine + "Started this monitor with new surgeryId!";
                            }
                            else
                            {
                                msg += Environment.NewLine + "Existing monitor could not be stopped!";
                                return new SurgeryMonitorStatus
                                {
                                    monitorId = startMonitorEvent.monitorId,
                                    status = SurgeryMonitorStatus.Status.ConnectionToMonitorFailed,
                                    statusMessage = "Surgery could not be started for already started monitor with different surgeryId."
                                };
                            }
                        }
                        //If surgeryId  for the existing monitor exists then post the anesthetic values right away
                        else
                        {
                            msg += Environment.NewLine + "Existing monitor with existing surgeryId!";
                            VetlandServer.PostAnestheticValuesOnDemand(startMonitorEvent);
                        }
                    }
                }
                LogWriter.WriteToFile(msg, LogHelperUtility.GetLogFileNameForCommonTraceing(DeviceIdentifier.VetLand, startMonitorEvent.monitorId.ToString()));

                return new SurgeryMonitorStatus
                {
                    monitorId = startMonitorEvent.monitorId,
                    status = SurgeryMonitorStatus.Status.Active,
                };
            }
            catch (Exception ex)
            {
                LogWriter.WriteToFile(ex.ToString(), LogHelperUtility.GetLogFileNameForCommonTraceing(DeviceIdentifier.VetLand, startMonitorEvent.monitorId.ToString()));
                throw;
            }
        }
        private void StartMonitorHandler_Vetland(object obj)
        {
            try
            {
                StartSurgeryMonitor startSurgeryMonitor = (StartSurgeryMonitor)obj;
                Console.WriteLine();
                VetlandServer.StartServer(startSurgeryMonitor);
            }
            catch
            {
                throw;
            }
        }
        private static SurgeryMonitorStatus StopMonitor_Vetland(StopSurgeryMonitor stopMonitorEvent)
        {
            try
            {
                //LOGIC to stop the Vetland listener

                string msg = string.Empty;
                if (VetLandSurgeryMonitorThreads[stopMonitorEvent.monitorId] != null)
                {
                    //Set the disconnect flag to true
                    SettingsUtility.SetDisconnectSetting(DisconnectSetting.True, DeviceIdentifier.VetLand, stopMonitorEvent.monitorId.ToString());
                    msg += "Diconnect flag set to true!";

                    //Stop the Vetland listener
                    VetlandServer.StopServer(stopMonitorEvent);
                    msg += "Vetland Server stoped!";

                    //Abort the VetlandSurgeryMonitorThread of this monitor
                    VetLandSurgeryMonitorThreads[stopMonitorEvent.monitorId].Abort();
                    msg += "VetlandSurgeryMonitorThreads aborted!";

                    //Remove the VetlandSurgeryMonitorThread for this monitor
                    VetLandSurgeryMonitorThreads.Remove(stopMonitorEvent.monitorId);
                    msg += "VetlandSurgeryMonitorThreads removed!";

                    if (VetLandStartMonitorEvent[stopMonitorEvent.monitorId] != null)
                    {
                        VetLandStartMonitorEvent.Remove(stopMonitorEvent.monitorId);
                    }
                }

                LogWriter.WriteToFile(msg, LogHelperUtility.GetLogFileNameForCommonTraceing(DeviceIdentifier.VetLand,
                                                                                stopMonitorEvent.monitorId.ToString()));

                return new SurgeryMonitorStatus
                {
                    monitorId = stopMonitorEvent.monitorId,
                    status = SurgeryMonitorStatus.Status.Stopped,
                };
            }
            catch (Exception ex)
            {
                LogWriter.WriteToFile(ex.ToString(), LogHelperUtility.GetLogFileNameForCommonTraceing(DeviceIdentifier.VetLand,
                                                                                stopMonitorEvent.monitorId.ToString()));
                throw;
            }
        }
        /// <summary>
        /// Keep Watch On StatusCode for VetLand
        /// </summary>
        /// <CreatedBy>Om Shakya</CreatedBy>
        /// <CreatedDate>Nov 2016</CreatedDate>
        /// <ModifyBy>...</ModifyBy>
        /// <ModifyDate>...</ModifyDate>
        private void KeepWatchOnStatusCode_VetLand()
        {
            try
            {
                string msg = "HasStopMonitorBasedOnStatusCodeTimerStartedVetLand: " + HasStopMonitorBasedOnStatusCodeTimerStartedVetLand.ToString();
                if (!HasStopMonitorBasedOnStatusCodeTimerStartedVetLand)
                {
                    //Note: This object can not be disposed, if it is disposed application will break.
                    System.Timers.Timer timerWatch = new System.Timers.Timer();
                    double interval = 10 * 1000;

                    //Handle data transfer elapsed event
                    timerWatch.Elapsed += (sender, e) => OnElapsedEventOfTimer_VetLand(sender, e);
                    timerWatch.Interval = Convert.ToInt32(interval);
                    timerWatch.Enabled = true;
                    timerWatch.Start();
                    HasStopMonitorBasedOnStatusCodeTimerStartedVetLand = true;
                    msg += " HasStopMonitorBasedOnStatusCodeTimerStartedVetLand: " + HasStopMonitorBasedOnStatusCodeTimerStartedVetLand.ToString();
                    msg += " timerWatch started";
                }

                LogWriter.WriteToFile(msg, LogHelperUtility.GetTraceFileNameForAdminApp());
            }
            catch
            {
                throw;
            }
        }
        /// <summary>
        /// On Elapsed Event Of Timer for VetLand
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// <CreatedBy>Om Shakya</CreatedBy>
        /// <CreatedDate>Nov 2016</CreatedDate>
        /// <ModifyBy>...</ModifyBy>
        /// <ModifyDate>...</ModifyDate>
        private void OnElapsedEventOfTimer_VetLand(object sender, ElapsedEventArgs e)
        {
            try
            {
                CommonTimerElapsedEventMethod(DeviceIdentifier.VetLand);
                //Check if still any surgery is running, if not then dispose the timer and set the flag to false
                if (VetLandSurgeryMonitorThreads == null || VetLandSurgeryMonitorThreads.Count == 0)
                {
                    try
                    {
                        HasStopMonitorBasedOnStatusCodeTimerStartedVetLand = false;
                        System.Timers.Timer timer = (System.Timers.Timer)sender;
                        timer.Elapsed -= (sen, eve) => OnElapsedEventOfTimer_VetLand(sen, eve);
                        timer.Stop();
                        timer.Dispose();
                    }
                    catch { throw; }
                }
            }
            catch
            {
                throw;
            }

        }
        #endregion Vetland Server code block ends

        #region  BioNet Server code block starts
        private SurgeryMonitorStatus StartMonitor_BioNet(StartSurgeryMonitor startMonitorEvent)
        {
            try
            {
                
                //LOGIC to Start the BioNet listener
                KeepWatchOnStatusCode_BioNet();

                string msg = string.Empty;

                //Check whether this surgery monitor is in use or not, if not then start it
                if (!BioNetSurgeryMonitorThreads.Keys.Contains(startMonitorEvent.monitorId))
                {
                    msg += "Starting monitor - " + startMonitorEvent.monitorId.ToString();
                    msg += Environment.NewLine + "Starting surgeryId - " + startMonitorEvent.surgeryId.ToString();

                    //Create and start a thread to start the surgery monitor
                    Thread threadStartSurgeryMonitor = new Thread(new ParameterizedThreadStart(StartMonitorHandler_BioNet));
                    threadStartSurgeryMonitor.Start(startMonitorEvent);

                    //Add this surgery monitor in collection
                    BioNetSurgeryMonitorThreads.Add(startMonitorEvent.monitorId, threadStartSurgeryMonitor);
                    BioNetStartMonitorEvent.Add(startMonitorEvent.monitorId, startMonitorEvent);
                }
                //If monitor is already in use
                else
                {
                    msg += Environment.NewLine + "Already started monitor - " + startMonitorEvent.monitorId.ToString();
                    msg += Environment.NewLine + "Already started - new surgeryId - " + startMonitorEvent.surgeryId.ToString();

                    //if surgeryId id does not match
                    //then stop the previous one and start the surgery

                    if (BioNetStartMonitorEvent[startMonitorEvent.monitorId] != null)
                    {
                        bool doesExists = false;
                        doesExists = BioNetStartMonitorEvent[startMonitorEvent.monitorId].surgeryId.Equals(startMonitorEvent.surgeryId);

                        msg += Environment.NewLine + "Already started - existing surgeryId - " + BioNetStartMonitorEvent[startMonitorEvent.monitorId].surgeryId.ToString();
                        //If surgeryId id for the existing monitor does not exists
                        //If monitor has a new surgeryId for surgery
                        if (!doesExists)
                        {
                            msg += Environment.NewLine + "Both surgeryId differs! Stoping existing monitor!";

                            StopSurgeryMonitor obj = new StopSurgeryMonitor();
                            obj.monitorId = startMonitorEvent.monitorId;
                            SurgeryMonitorStatus stopMonitorStatus = StopMonitor(obj);
                            System.Threading.Thread.Sleep(1000);

                            SurgeryMonitorStatus.Status status = stopMonitorStatus.status;
                            if (status.Equals(SurgeryMonitorStatus.Status.Stopped))
                            {
                                msg += Environment.NewLine + "Existing monitor stopped! Starting this monitor with new surgeryId!";
                                //Create and start a thread to start the surgery monitor
                                Thread threadStartSurgeryMonitor = new Thread(new ParameterizedThreadStart(StartMonitorHandler_BioNet));
                                threadStartSurgeryMonitor.Start(startMonitorEvent);

                                //Add this surgery monitor in collection
                                BioNetSurgeryMonitorThreads.Add(startMonitorEvent.monitorId, threadStartSurgeryMonitor);
                                BioNetStartMonitorEvent.Add(startMonitorEvent.monitorId, startMonitorEvent);

                                msg += Environment.NewLine + "Started this monitor with new surgeryId!";
                            }
                            else
                            {
                                msg += Environment.NewLine + "Existing monitor could not be stopped!";
                                return new SurgeryMonitorStatus
                                {
                                    monitorId = startMonitorEvent.monitorId,
                                    status = SurgeryMonitorStatus.Status.ConnectionToMonitorFailed,
                                    statusMessage = "Surgery could not be started for already started monitor with different surgeryId."
                                };
                            }
                        }
                        //If surgeryId  for the existing monitor exists then post the anesthetic values right away
                        else
                        {
                            msg += Environment.NewLine + "Existing monitor with existing surgeryId!";
                            BioNetServer.PostAnestheticValuesOnDemand(startMonitorEvent);
                        }
                    }
                }
                LogWriter.WriteToFile(msg, LogHelperUtility.GetLogFileNameForCommonTraceing(DeviceIdentifier.BioNet, startMonitorEvent.monitorId.ToString()));

                return new SurgeryMonitorStatus
                {
                    monitorId = startMonitorEvent.monitorId,
                    status = SurgeryMonitorStatus.Status.Active,
                };
            }
            catch (Exception ex)
            {
                LogWriter.WriteToFile(ex.ToString(), LogHelperUtility.GetLogFileNameForCommonTraceing(DeviceIdentifier.BioNet, startMonitorEvent.monitorId.ToString()));
                throw;
            }
        }
        private void StartMonitorHandler_BioNet(object obj)
        {
            try
            {
                StartSurgeryMonitor startSurgeryMonitor = (StartSurgeryMonitor)obj;
                Console.WriteLine();
                BioNetServer.StartServer(startSurgeryMonitor);
            }
            catch
            {
                throw;
            }
        }
        private static SurgeryMonitorStatus StopMonitor_BioNet(StopSurgeryMonitor stopMonitorEvent)
        {
            try
            {
                //LOGIC to stop the BioNet listener

                string msg = string.Empty;
                if (BioNetSurgeryMonitorThreads[stopMonitorEvent.monitorId] != null)
                {
                    //Set the disconnect flag to true
                    SettingsUtility.SetDisconnectSetting(DisconnectSetting.True, DeviceIdentifier.BioNet, stopMonitorEvent.monitorId.ToString());
                    msg += "Diconnect flag set to true!";

                    //Stop the BioNet listener
                    BioNetServer.StopServer(stopMonitorEvent);
                    msg += "BioNet Server stoped!";

                    //Abort the BioNetSurgeryMonitorThread of this monitor
                    BioNetSurgeryMonitorThreads[stopMonitorEvent.monitorId].Abort();
                    msg += "BioNetSurgeryMonitorThreads aborted!";

                    //Remove the BioNetSurgeryMonitorThread for this monitor
                    BioNetSurgeryMonitorThreads.Remove(stopMonitorEvent.monitorId);
                    msg += "BioNetSurgeryMonitorThreads removed!";

                    if (BioNetStartMonitorEvent[stopMonitorEvent.monitorId] != null)
                    {
                        BioNetStartMonitorEvent.Remove(stopMonitorEvent.monitorId);
                    }
                }

                LogWriter.WriteToFile(msg, LogHelperUtility.GetLogFileNameForCommonTraceing(DeviceIdentifier.BioNet,
                                                                                stopMonitorEvent.monitorId.ToString()));

                return new SurgeryMonitorStatus
                {
                    monitorId = stopMonitorEvent.monitorId,
                    status = SurgeryMonitorStatus.Status.Stopped,
                };
            }
            catch (Exception ex)
            {
                LogWriter.WriteToFile(ex.ToString(), LogHelperUtility.GetLogFileNameForCommonTraceing(DeviceIdentifier.BioNet,
                                                                                stopMonitorEvent.monitorId.ToString()));
                throw;
            }
        }
        /// <summary>
        /// Keep Watch On StatusCode for BioNet
        /// </summary>
        /// <CreatedBy>Om Shakya</CreatedBy>
        /// <CreatedDate>Nov 2016</CreatedDate>
        /// <ModifyBy>...</ModifyBy>
        /// <ModifyDate>...</ModifyDate>
        private void KeepWatchOnStatusCode_BioNet()
        {
            try
            {
                string msg = "HasStopMonitorBasedOnStatusCodeTimerStartedBioNet: " + HasStopMonitorBasedOnStatusCodeTimerStartedBioNet.ToString();
                if (!HasStopMonitorBasedOnStatusCodeTimerStartedBioNet)
                {
                    //Note: This object can not be disposed, if it is disposed application will break.
                    System.Timers.Timer timerWatch = new System.Timers.Timer();
                    double interval = 10 * 1000;

                    //Handle data transfer elapsed event
                    timerWatch.Elapsed += (sender, e) => OnElapsedEventOfTimer_BioNet(sender, e);
                    timerWatch.Interval = Convert.ToInt32(interval);
                    timerWatch.Enabled = true;
                    timerWatch.Start();
                    HasStopMonitorBasedOnStatusCodeTimerStartedBioNet = true;
                    msg += " HasStopMonitorBasedOnStatusCodeTimerStartedBioNet: " + HasStopMonitorBasedOnStatusCodeTimerStartedBioNet.ToString();
                    msg += " timerWatch started";
                }

                LogWriter.WriteToFile(msg, LogHelperUtility.GetTraceFileNameForAdminApp());
            }
            catch
            {
                throw;
            }
        }
        /// <summary>
        /// On Elapsed Event Of Timer for BioNet
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// <CreatedBy>Om Shakya</CreatedBy>
        /// <CreatedDate>Nov 2016</CreatedDate>
        /// <ModifyBy>...</ModifyBy>
        /// <ModifyDate>...</ModifyDate>
        private void OnElapsedEventOfTimer_BioNet(object sender, ElapsedEventArgs e)
        {
            try
            {
                CommonTimerElapsedEventMethod(DeviceIdentifier.BioNet);
                //Check if still any surgery is running, if not then dispose the timer and set the flag to false
                if (BioNetSurgeryMonitorThreads == null || BioNetSurgeryMonitorThreads.Count == 0)
                {
                    try
                    {
                        HasStopMonitorBasedOnStatusCodeTimerStartedBioNet = false;
                        System.Timers.Timer timer = (System.Timers.Timer)sender;
                        timer.Elapsed -= (sen, eve) => OnElapsedEventOfTimer_BioNet(sen, eve);
                        timer.Stop();
                        timer.Dispose();
                    }
                    catch { throw; }
                }
            }
            catch
            {
                throw;
            }

        }
        #endregion BioNet Server code block ends
    }
}
