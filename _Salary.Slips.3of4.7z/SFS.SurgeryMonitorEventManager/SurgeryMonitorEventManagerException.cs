﻿using System;

namespace SFS.SurgeryMonitorEventManager
{
    public class SurgeryMonitorEventManagerException : ApplicationException
    { 
        public SurgeryMonitorEventManagerException() : base() { }

        public SurgeryMonitorEventManagerException(string message) : base(message) { }
    }
}
