﻿using System;
using System.IO;
using System.Reflection;

namespace SFS.ObjectSerializer
{
    /// <summary>
    /// This class overrides the BindToType method of the System.Runtime.Serialization.SerializationBinder class 
    /// to deserialize the objects from any assembly, hence any assembly can deserialize the objects.
    /// </summary>
    /// <CreatedDate>Sep 2016</CreatedDate>
    /// <ModifyBy>...</ModifyBy>
    /// <ModifyDate>...</ModifyDate>
    sealed class AllAssemblyDeserializationBinder : System.Runtime.Serialization.SerializationBinder
    {
        /// <summary>
        /// This is overriding the BindToType method of System.Runtime.Serialization.SerializationBinder class
        /// to deserialize the objects from any assembly, hence any assembly can deserialize the objects.
        /// </summary>
        /// <param name="assemblyName"></param>
        /// <param name="typeName"></param>
        /// <returns></returns>
        /// <CreatedBy>Om Shakya</CreatedBy>
        /// <CreatedDate>Sep 2016</CreatedDate>
        /// <ModifyBy>...</ModifyBy>
        /// <ModifyDate>...</ModifyDate>
        public override Type BindToType(string assemblyName, string typeName)
        {
            Type typeToDeserialize = null;
            String currentAssembly = Assembly.GetExecutingAssembly().FullName;

            assemblyName = currentAssembly;
            typeToDeserialize = Type.GetType(String.Format("{0}, {1}", typeName, assemblyName));

            return typeToDeserialize;
        }
    }

    /// <summary>
    /// Class for serializer.
    /// </summary>
    /// <CreatedDate>Aug 2016</CreatedDate>
    /// <ModifyBy>...</ModifyBy>
    /// <ModifyDate>...</ModifyDate>
    /// <CreatedBy>Om Shakya</CreatedBy>
    /// <CreatedDate>Sep 2016</CreatedDate>
    /// <ModifyBy>...</ModifyBy>
    /// <ModifyDate>...</ModifyDate>
    public static class Serializer
    {
        #region Public Methods
        /// <summary>
        /// Method to write the object in binary file in the serialized form.
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="filePath"></param>
        /// <param name="objectToWrite"></param>
        /// <param name="append"></param>
        /// <returns></returns>
        /// <CreatedBy>Om Shakya</CreatedBy>
        /// <CreatedDate>Aug 2016</CreatedDate>
        /// <ModifyBy>...</ModifyBy>
        /// <ModifyDate>...</ModifyDate>
        public static bool WriteToBinaryFile<T>(string filePath, T objectToWrite, bool append = false)
        {
            bool isWritten = false;
            try
            {
                if (!Directory.Exists(Path.GetDirectoryName(filePath)))
                    Directory.CreateDirectory(Path.GetDirectoryName(filePath));

                if (!File.Exists(filePath))
                    using (FileStream fs = File.Create(filePath)) { fs.Close(); }

                if (File.Exists(filePath))
                    using (Stream stream = File.Open(filePath, append ? FileMode.Append : FileMode.Create))
                    {
                        System.Runtime.Serialization.Formatters.Binary.BinaryFormatter
                            binaryFormatter = new System.Runtime.Serialization.Formatters.Binary.BinaryFormatter();
                        binaryFormatter.Serialize(stream, objectToWrite);
                        isWritten = true;
                        stream.Close();
                    }
                return isWritten;
            }
            catch
            {
                throw;
            }
        }
        /// <summary>
        /// Method to read the object from binary file in deserialized form.
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="filePath"></param>
        /// <returns></returns>
        /// <CreatedBy>Om Shakya</CreatedBy>
        /// <CreatedDate>Aug 2016</CreatedDate>
        /// <ModifyBy>...</ModifyBy>
        /// <ModifyDate>...</ModifyDate>
        public static T ReadFromBinaryFile<T>(string filePath)
        {
            T t;
            try
            {
                using (Stream stream = File.Open(filePath, FileMode.Open, FileAccess.Read, FileShare.Read))
                {
                    System.Runtime.Serialization.Formatters.Binary.BinaryFormatter
                        binaryFormatter = new System.Runtime.Serialization.Formatters.Binary.BinaryFormatter();
                    binaryFormatter.Binder = new AllAssemblyDeserializationBinder();
                    t = (T)binaryFormatter.Deserialize(stream);
                    stream.Close();
                    return t;
                }
            }
            catch
            {
                throw;
            }
        }
        #endregion
    }
}
