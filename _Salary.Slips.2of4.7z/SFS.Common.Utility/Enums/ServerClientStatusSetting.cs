﻿namespace SFS.CommonUtilities.Enums
{
    /// <summary>
    /// Enum for server client status setting.
    /// </summary>
    /// <CreatedBy>Om Shakya</CreatedBy>
    /// <CreatedDate>Aug 2016</CreatedDate>
    /// <ModifyBy>...</ModifyBy>
    /// <ModifyDate>...</ModifyDate>
    public enum ServerClientStatusSetting
    {
        None,
        Waiting,
        Connected,
        Disconnected
    }
}
