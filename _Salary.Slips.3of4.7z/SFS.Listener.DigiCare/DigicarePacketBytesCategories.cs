﻿using System.Collections.Generic;

namespace SFS.Listener.DigiCare
{
    public class DigicarePacketBytesCategories
    {
        /// <summary>
        /// Get NIBPAlarm.
        /// </summary>
        public static Dictionary<ushort, string> NIBPAlarm
        {
            get
            {
                Dictionary<ushort, string> nibpalarm = new Dictionary<ushort, string>();

                nibpalarm.Add(0, "Normal");
                nibpalarm.Add(1, "BP alarm");
                nibpalarm.Add(2, "Check sensor");
                nibpalarm.Add(3, "Over pressure");
                nibpalarm.Add(4, "Overtime pressure");
                nibpalarm.Add(5, "Inflation failure");
                nibpalarm.Add(6, "Deflation failure");
                nibpalarm.Add(7, "Air leak");
                nibpalarm.Add(8, "Measurement error");
                nibpalarm.Add(9, "Excessive motion");
                nibpalarm.Add(10, "Measure time exceeded");
                nibpalarm.Add(11, "Pulse too week");

                return nibpalarm;
            }
        }
    }
}
