﻿using SFS.CommonUtilities;
using System;
using System.Collections.Generic;

namespace SFS.Listener.BioNet
{
    /// <summary>
    /// BioNet DataPackets Parser Class.
    /// </summary>
    /// <CreatedBy>Om Shakya</CreatedBy>
    /// <CreatedDate>Sep 2015</CreatedDate>
    /// <ModifyBy>...</ModifyBy>
    /// <ModifyDate>...</ModifyDate>
    public static class BioNetDataPacketsParser
    {
        /// <summary>
        /// Method to Parse PARAMETER_DATA packet.
        /// </summary>
        /// <param name="bytes_PARAMETER_DATA"></param>
        /// <returns></returns>
        /// <CreatedBy>Om Shakya</CreatedBy>
        /// <CreatedDate>Sep 2015</CreatedDate>
        /// <ModifyBy>...</ModifyBy>
        /// <ModifyDate>...</ModifyDate>
        public static Dictionary<string, string> Parse_PARAMETER_DATA(byte[] bytes_PARAMETER_DATA)
        {
            try
            {
                Dictionary<string, string> parsed_PARAMETER_DATA = new Dictionary<string, string>();

                if (bytes_PARAMETER_DATA != null && bytes_PARAMETER_DATA.Length > 0)
                {
                    UInt16 HR = GeneralMethodsUtility.ConvertTwoBytesToUInt16(GeneralMethodsUtility.ExtractBytes(bytes_PARAMETER_DATA, 2, 2));
                    parsed_PARAMETER_DATA.Add("HR_HeartRate", HR.ToString());

                    ushort SpO2Value = GeneralMethodsUtility.ConvertOneByteToUShort(bytes_PARAMETER_DATA[10]);
                    parsed_PARAMETER_DATA.Add("SpO2Value", SpO2Value.ToString()); //+" %"

                    ushort RespRate = GeneralMethodsUtility.ConvertOneByteToUShort(bytes_PARAMETER_DATA[14]);
                    parsed_PARAMETER_DATA.Add("RespRate", RespRate.ToString());

                    UInt16 NiBpSysDataHigh = GeneralMethodsUtility.ConvertTwoBytesToUInt16(GeneralMethodsUtility.ExtractBytes(bytes_PARAMETER_DATA, 16, 2));
                    parsed_PARAMETER_DATA.Add("NiBpSysDataHigh", NiBpSysDataHigh.ToString());

                    UInt16 NiBpMeanDataHigh = GeneralMethodsUtility.ConvertTwoBytesToUInt16(GeneralMethodsUtility.ExtractBytes(bytes_PARAMETER_DATA, 18, 2));
                    parsed_PARAMETER_DATA.Add("NiBpMeanDataHigh", NiBpMeanDataHigh.ToString());

                    UInt16 NiBpDiaDataHigh = GeneralMethodsUtility.ConvertTwoBytesToUInt16(GeneralMethodsUtility.ExtractBytes(bytes_PARAMETER_DATA, 20, 2));
                    parsed_PARAMETER_DATA.Add("NiBpDiaDataHigh", NiBpDiaDataHigh.ToString());

                    ushort TempDataRe = GeneralMethodsUtility.ConvertOneByteToUShort(bytes_PARAMETER_DATA[24]);
                    ushort TempDataIm = GeneralMethodsUtility.ConvertOneByteToUShort(bytes_PARAMETER_DATA[25]);
                    parsed_PARAMETER_DATA.Add("Temp1", TempDataRe.ToString() + "." + TempDataIm.ToString());// + " ℃"

                    ushort CO2Value = GeneralMethodsUtility.ConvertOneByteToUShort(bytes_PARAMETER_DATA[48]);
                    parsed_PARAMETER_DATA.Add("EtCO2", CO2Value.ToString());
                }
                return parsed_PARAMETER_DATA;
            }
            catch
            {
                throw;
            }
        }
    }
}
