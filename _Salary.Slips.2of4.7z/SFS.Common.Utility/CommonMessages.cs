﻿namespace SFS.CommonUtilities
{
    /// <summary>
    /// This is the class used to read and show the messages, actually contains the messages in their properties.
    /// </summary>
    public static class CommonMessages
    {
        public static string MonitorNotFoundOnLocalDisk = "Monitor could not be found. Check monitor in Admin app, if avalibalble then unregister and register again. Otherwise register the monitor.";
        public static string StartSurgeryMonitorDoesNotHaveEnoughInformation = "Failed to start monitor, not enough information.";
        public static string StopSurgeryMonitorDoesNotHaveEnoughInformation = "Failed to stop monitor, not enough information.";
        public static string SFSserverCannotStartMonitor = "Failed to start monitor.  Please check the Surgery Admin App for the monitor is installed and running properly.";
        public static string SFSserverCannotStopMonitor = "Failed to stop monitor.  Please check the Surgery Admin App for the monitor is installed and running properly.";
        public static string CanNotConnectTheMonitor = "Can't start monitor. Please check if monitor is connected properly to Network/PC.";
        public static string MonitorIsNotAvailable = "Can't start monitor. Please check if monitor is connected and configured properly.";
        public static string MonitorConnectedSuccessfully = "Monitor is active.";
        public static string MonitorConnectionFailedMsg = "Connection to the monitor failed. Please check if the monitor is connected properly to Network/PC.";
        public static string ApplicationRegisteredSuccessfully = "Application registered successfully!";
        public static string MonitorRegisteredSuccessfully = "Monitor registered successfully!";
        public static string SurgeryMonitorEndpointNotFound = "SurgeryMonitorEndpoint not found!";
        public static string AllMonitorsDownloadedSuccessfully = "All monitors downloaded successfully!";
        public static string AllMonitorsCouldNotBeDownloaded = "All monitors could not be downloaded successfully!";
    }
}
