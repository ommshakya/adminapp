﻿using SFS.CommonUtilities;
using SFS.CommonUtilities.Enums;
using SFS.FileWritter;
using smartflowsheet.surgery.api.model.objects;
using System;
using System.Linq;
using System.Net;
using System.Net.NetworkInformation;

namespace SFS.Helper
{
    public static class PingDeviceHelper
    {
        /// <summary>
        /// Method to Ping Monitor and Post SurgeryMonitorStatus.
        /// </summary>
        /// <param name="monitorId"></param>
        /// <param name="monitorIPAddress"></param>
        /// <param name="deviceIdentifier"></param>
        /// <returns></returns>
        public static bool PingMonitorPostSurgeryMonitorStatus(Guid monitorId, DeviceIdentifier deviceIdentifier, out bool isMonitorConnected)
        {
            isMonitorConnected = false;
            try
            {
                string trace = "Trying to check the monitor connection status. ";
                if (monitorId != null)
                {
                    //Logic starts
                    string liveFile = string.Empty;
                    liveFile = LogHelperUtility.GetLogFileNameForCommonLiveData(deviceIdentifier, monitorId.ToString());

                    bool isLiveFileExists = false;
                    if (System.IO.File.Exists(liveFile))
                    {
                        isLiveFileExists = true;
                    }
                    if (!isLiveFileExists)
                    {
                        System.Threading.Thread.Sleep(10 * 1000);
                        if (System.IO.File.Exists(liveFile))
                        {
                            isLiveFileExists = true;
                        }
                    }

                    if (isLiveFileExists)
                    {
                        trace += "Live data file exists. ";

                        string[] allLines = FileProcessorUtility.ReadLinesOfFile(liveFile);
                        if (allLines != null && allLines.Length > 0)
                        {
                            string currentData = allLines[allLines.Length - 1];
                            string[] paramPairs = currentData.Replace("\t", "|").Split('|');
                            if (paramPairs.Length > 0)
                            {
                                DateTime currentDataReceivedTime = DateTime.Parse(paramPairs[0].Trim());
                                DateTime currentTime = DateTime.Now;
                                TimeSpan timeSpan = currentTime.Subtract(currentDataReceivedTime);

                                trace += string.Format(@"currentDataReceivedTime: {0} - currentTime: {1} - Difference in seconds: {2} "
                                        , currentDataReceivedTime.ToString(), currentTime.ToString(), timeSpan.TotalSeconds.ToString());

                                if (timeSpan.TotalSeconds <= 10)
                                {
                                    isMonitorConnected = true;
                                }
                            }
                        }
                    }
                    else
                    {
                        trace += "Live data file does not exists. ";
                    }
                    //Logic ends

                    if (isMonitorConnected)
                    {
                        trace += "Monitor is connected. ";
                    }
                    else
                    {
                        trace += "Monitor is disconnected! ";

                        #region Clear file
                        //Remove the corresponding Live Data File to avoid posting the 
                        //anesthetic values in case if monitor is not connected
                        if (System.IO.File.Exists(liveFile))
                        {
                            System.IO.File.Delete(liveFile);
                            trace += "Removed live data file to avoid posting the anesthetic values. ";
                        }
                        else
                            trace += "Live data file does not exists to remove.";
                        #endregion
                    }
                    LogWriter.WriteToFile(trace, LogHelperUtility.GetLogFileNameForCommonTraceing(deviceIdentifier, monitorId.ToString()));
                }
                return isMonitorConnected;
            }
            catch
            {
                throw;
            }
        }
    }
}
