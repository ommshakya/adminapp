﻿using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Sockets;
using System.Threading;

namespace SFS.Listener.Vetland.VetlandDTO
{
    public static class VetlandMultiSupportDTO
    {
        /// <summary>
        /// Property to check whether Vetland listener is running or not.
        /// </summary>
        public static bool isVetlandListenerRunning;
        /// <summary>
        /// Collection of Vetland connected clients/monitors.
        /// </summary>
        public static Dictionary<Guid, IPAddress> VetlandConnectedClients;
        /// <summary>
        /// Collection of Vetland connected tcp clients.
        /// </summary>
        public static Dictionary<Guid, UdpClient> VetlandConnectedClientUdpClient;
        /// <summary>
        /// Collection of Vetland data transfer threads of connected client/monitor.
        /// </summary>
        public static Dictionary<Guid, Thread> VetlandConnectedClientDataTransferThreads;
        /// <summary>
        /// Collection of Vetland data transfer timers if thread of connected client/monitor.
        /// </summary>
        public static Dictionary<Guid, System.Timers.Timer> VetlandConnectedClientDataTransferThreadTimers;
        /// <summary>
        /// Collection of Vetland data transfer timers if thread of connected client/monitor.
        /// </summary>
        public static Dictionary<Guid, System.Timers.Timer> VetlandConnectedClientDataReceiveThreadTimers;
    }
}
