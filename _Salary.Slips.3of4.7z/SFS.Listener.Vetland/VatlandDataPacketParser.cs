﻿
using SFS.CommonUtilities;
using System;
using System.Collections.Generic;

namespace SFS.Listener.Vetland
{
    public class VetlandDataPacketParser
    {
        /// <summary>
        /// Method to Parse PARAMETER_DATA packet.
        /// </summary>
        /// <param name="bytes_PARAMETER_DATA"></param>
        /// <returns></returns>
        /// <CreatedBy>Om Shakya</CreatedBy>
        /// <CreatedDate>Sep 2015</CreatedDate>
        /// <ModifyBy>...</ModifyBy>
        /// <ModifyDate>...</ModifyDate>

        public Dictionary<string, string> Parse_FONT_DATA(byte[] bytes_FONT_DATA)
        {
            try
            {
                Dictionary<string, string> parsed_PARAMETER_DATA = new Dictionary<string, string>();
                int offsetValue = 512;
                if (bytes_FONT_DATA != null && bytes_FONT_DATA.Length > 0)
                {
                    UInt16 HR = GeneralMethodsUtility.ConvertTwoBytesWithOffsetToUInt16(GeneralMethodsUtility.ExtractBytes(bytes_FONT_DATA, 2, 2));
                    parsed_PARAMETER_DATA.Add("HR_HeartRate", (HR - offsetValue).ToString());

                    UInt16 SpO2Value = GeneralMethodsUtility.ConvertTwoBytesWithOffsetToUInt16(GeneralMethodsUtility.ExtractBytes(bytes_FONT_DATA, 32, 2));
                    parsed_PARAMETER_DATA.Add("SpO2Value", (SpO2Value - offsetValue).ToString());

                    UInt16 RespRate = GeneralMethodsUtility.ConvertTwoBytesWithOffsetToUInt16(GeneralMethodsUtility.ExtractBytes(bytes_FONT_DATA, 30, 2));
                    parsed_PARAMETER_DATA.Add("RespRate", (RespRate - offsetValue).ToString());

                    UInt16 NiBpSysDataHigh = GeneralMethodsUtility.ConvertTwoBytesWithOffsetToUInt16(GeneralMethodsUtility.ExtractBytes(bytes_FONT_DATA, 68, 2));
                    parsed_PARAMETER_DATA.Add("NiBpSysDataHigh", (NiBpSysDataHigh - offsetValue).ToString());

                    UInt16 NiBpMeanDataHigh = GeneralMethodsUtility.ConvertTwoBytesWithOffsetToUInt16(GeneralMethodsUtility.ExtractBytes(bytes_FONT_DATA, 72, 2));
                    parsed_PARAMETER_DATA.Add("NiBpMeanDataHigh", (NiBpMeanDataHigh - offsetValue).ToString());

                    UInt16 NiBpDiaDataHigh = GeneralMethodsUtility.ConvertTwoBytesWithOffsetToUInt16(GeneralMethodsUtility.ExtractBytes(bytes_FONT_DATA, 70, 2));
                    parsed_PARAMETER_DATA.Add("NiBpDiaDataHigh", (NiBpDiaDataHigh - offsetValue).ToString());

                    UInt16 TempDataRe = GeneralMethodsUtility.ConvertTwoBytesWithOffsetToUInt16(GeneralMethodsUtility.ExtractBytes(bytes_FONT_DATA, 36, 2));
                    parsed_PARAMETER_DATA.Add("Temp", ((TempDataRe - offsetValue) / 10.0).ToString());

                    UInt16 CO2Value = GeneralMethodsUtility.ConvertTwoBytesWithOffsetToUInt16(GeneralMethodsUtility.ExtractBytes(bytes_FONT_DATA, 100, 2));
                    parsed_PARAMETER_DATA.Add("EtCO2", (CO2Value - offsetValue).ToString());
                }
                return parsed_PARAMETER_DATA;
            }
            catch
            {
                throw;
            }
        }
    }
}
