﻿using SFS.CommonUtilities;
using SFS.ConfigManager;

namespace SFS.Listener.BioNet.BioNetUtility
{

    /// <summary>
    /// BioNet Utility Control Packets Class.
    /// </summary>
    /// <CreatedBy>Om Shakya</CreatedBy>
    /// <CreatedDate>Sep 2015</CreatedDate>
    /// <ModifyBy>...</ModifyBy>
    /// <ModifyDate>...</ModifyDate>
    public static class BioNetUtilityControlPackets
    {
        /// <summary>
        /// Get Connect_Req_Length (It is fixed as per Bionet protocol documentation).
        /// </summary>
        /// <CreatedBy>Om Shakya</CreatedBy>
        /// <CreatedDate>Sep 2015</CreatedDate>
        /// <ModifyBy>...</ModifyBy>
        /// <ModifyDate>...</ModifyDate>
        public static int Connect_Req_Length
        {
            get { return AppConfigurations.BioNet_Connect_Req_Length; }
        }

        /// <summary>
        /// Get Connect_Accept_Length (It is fixed as per Bionet protocol documentation).
        /// </summary>
        /// <CreatedBy>Om Shakya</CreatedBy>
        /// <CreatedDate>Sep 2015</CreatedDate>
        /// <ModifyBy>...</ModifyBy>
        /// <ModifyDate>...</ModifyDate>
        public static int Connect_Accept_Length
        {
            get { return AppConfigurations.BioNet_Connect_Accept_Length; }
        }

        /// <summary>
        /// Get Disconnect_Req_Length (It is fixed as per Bionet protocol documentation).
        /// </summary>
        /// <CreatedBy>Om Shakya</CreatedBy>
        /// <CreatedDate>Sep 2015</CreatedDate>
        /// <ModifyBy>...</ModifyBy>
        /// <ModifyDate>...</ModifyDate>
        public static int Disconnect_Req_Length
        {
            get { return AppConfigurations.BioNet_Disconnect_Req_Length; }
        }

        /// <summary>
        /// Get Data_Ack_Length (It is fixed as per Bionet protocol documentation).
        /// </summary>
        /// <CreatedBy>Om Shakya</CreatedBy>
        /// <CreatedDate>Sep 2015</CreatedDate>
        /// <ModifyBy>...</ModifyBy>
        /// <ModifyDate>...</ModifyDate>
        public static int Data_Ack_Length
        {
            get { return AppConfigurations.BioNet_Data_Ack_Length; }
        }
        /// <summary>
        /// Method CONNECT_REQ, it forms the CONNECT_REQ.
        /// </summary>
        /// <returns></returns>
        public static byte[] CONNECT_REQ()
        {
            byte[] bytes = null;
            try
            {
                bytes = new byte[3] { 0xC0, 0x01, ConstantsUtility.BedNumer };
                return bytes;
            }
            catch
            {
                throw;
            }
        }
        /// <summary>
        /// Method CONNECT_ACCEPT, it forms the CONNECT_ACCEPT.
        /// </summary>
        /// <param name="bedNum"></param>
        /// <returns></returns>
        public static byte[] CONNECT_ACCEPT(ushort bedNum)
        {
            byte[] bytes = null;
            try
            {
                bytes = new byte[3] { 0xC0, 0x01, (byte)bedNum };
                return bytes;
            }
            catch
            {
                throw;
            }
        }
        /// <summary>
        /// Method DISCONNECT_REQ, it forms the DISCONNECT_REQ.
        /// </summary>
        /// <returns></returns>
        public static byte[] DISCONNECT_REQ()
        {
            byte[] bytes = null;
            try
            {
                bytes = new byte[3] { 0xC0, 0x00, ConstantsUtility.BedNumer };
                return bytes;
            }
            catch
            {
                throw;
            }
        }
        /// <summary>
        /// Method DATA_ACK, it forms the DATA_ACK.
        /// </summary>
        /// <param name="bedNum"></param>
        /// <returns></returns>
        public static byte[] DATA_ACK(ushort bedNum)
        {
            byte[] bytes = null;
            try
            {
                bytes = new byte[3] { 0xC0, 0xD1, (byte)bedNum };
                return bytes;
            }
            catch
            {

                throw;
            }
        }
        /// <summary>
        /// Method DO_NOT_CONNECT_ACCEPT, it forms the DO_NOT_CONNECT_ACCEPT.
        /// </summary>
        /// <returns></returns>
        public static byte[] DO_NOT_CONNECT_ACCEPT()
        {
            byte[] bytes = null;
            try
            {
                bytes = new byte[3] { 0xC0, 0x01, 0x00 };
                return bytes;
            }
            catch
            {
                throw;
            }
        }
    }
}
