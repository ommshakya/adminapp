﻿using System;
using System.IO;

namespace SFS.FileWritter
{
    public static class LogWriter
    {
        #region Properties
        /// <summary>
        /// Get the current date.
        /// </summary>
        /// <CreatedDate>Aug 2016</CreatedDate>
        /// <ModifyBy>...</ModifyBy>
        /// <ModifyDate>...</ModifyDate>
        private static DateTime CurrentDate { get { return DateTime.Now; } }
        #endregion

        #region Public Methods
        /// <summary>
        /// Method to write to log. It is writing the log to the listener's log file.
        /// </summary>
        /// <param name="message"></param>
        /// <param name="fullFilePath"></param>
        /// <CreatedDate>Aug 2016</CreatedDate>
        /// <ModifyBy>...</ModifyBy>
        /// <ModifyDate>...</ModifyDate>
        public static void WriteToLog(string message, string fullFilePath)
        {
            try
            {
                WriteInternalMessage(message, fullFilePath);
            }
            catch
            {
                throw;
            }
        }
        /// <summary>
        /// Method to write to error.
        /// </summary>
        /// <param name="exception"></param>
        /// <param name="fullFilePath"></param>
        /// <CreatedDate>Aug 2016</CreatedDate>
        /// <ModifyBy>...</ModifyBy>
        /// <ModifyDate>...</ModifyDate>
        public static void WriteToError(Exception exception, string fullFilePath)
        {
            try
            {
                WriteInternalMessage(exception.ToString(), fullFilePath);
            }
            catch
            {
                throw;
            }
        }
        /// <summary>
        /// Method to write to file. It is writing log into trace files of each device.
        /// </summary>
        /// <param name="message"></param>
        /// <param name="fullFilePath"></param>
        /// <CreatedDate>Aug 2016</CreatedDate>
        /// <ModifyBy>...</ModifyBy>
        /// <ModifyDate>...</ModifyDate>
        public static void WriteToFile(string message, string fullFilePath)
        {
            try
            {
                WriteInternalMessage(message, fullFilePath);
            }
            catch
            {
                throw;
            }
        }
        /// <summary>
        /// Method to write log in the live file without appending any line. It is used to write parsed anesthetic values.
        /// </summary>
        /// <param name="message"></param>
        /// <param name="fullFilePath"></param>
        /// <CreatedDate>Nov 2016</CreatedDate>
        /// <ModifyBy>...</ModifyBy>
        /// <ModifyDate>...</ModifyDate>
        public static void WriteToLiveFile(string message, string fullFilePath)
        {
            try
            {
                WriteInternalMessage(message, fullFilePath, false);
            }
            catch
            {
                throw;
            }
        }
        #endregion

        #region Private Methods
        /// <summary>
        /// Method to write internal message.
        /// </summary>
        /// <param name="message"></param>
        /// <param name="fullFilePath"></param>
        /// <CreatedDate>Aug 2016</CreatedDate>
        /// <ModifyBy>...</ModifyBy>
        /// <ModifyDate>...</ModifyDate>
        private static void WriteInternalMessage(string message, string fullFilePath, bool appendBlankLine = true)
        {
            try
            {
                if (!Directory.Exists(Path.GetDirectoryName(fullFilePath)))
                    Directory.CreateDirectory(Path.GetDirectoryName(fullFilePath));
                
                if (!File.Exists(fullFilePath))
                    using (FileStream fs = File.Create(fullFilePath)) { fs.Close(); }

                if (File.Exists(fullFilePath))
                    using (StreamWriter sw = File.AppendText(fullFilePath))
                    {
                        sw.WriteLine(CurrentDate.ToString() + "\t" + message.Trim());
                        sw.WriteLine();
                        if(appendBlankLine)
                            sw.WriteLine();
                        sw.Close();
                    }
            }
            catch
            {
                throw;
            }
        }
        #endregion
    }
}