﻿using SFS.CommonUtilities.Enums;
using SFS.FileWritter;
using System.IO;

namespace SFS.CommonUtilities
{
    /// <summary>
    /// Class for file splitting.
    /// </summary>
    public static class FileSplitterUtility
    {
        /// <summary>
        /// Method to split and move the file.
        /// </summary>
        /// <param name="filename"></param>
        /// <param name="deviceName"></param>
        /// <returns></returns>
        /// <CreatedBy>Om Shakya</CreatedBy>
        /// <CreatedDate>Aug 2016</CreatedDate>
        /// <ModifyBy>...</ModifyBy>
        /// <ModifyDate>...</ModifyDate>
        public static bool SplitAndMoveFile(string filename, DeviceIdentifier deviceName)
        {
            bool isDone = false;
            try
            {
                string newName = string.Join("",
                                            Path.GetFileNameWithoutExtension(filename),
                                            ".",
                                            GeneralMethodsUtility.NewGuid(),
                                            Path.GetExtension(filename));
                if (FileProcessorUtility.RenameFile(
                                    filename,
                                    SettingsUtility.GetCommonDataPath(CommonDataSettingTypes.LiveDataFile_Folder, deviceName) + newName))
                {
                    //Move file from main folder to Pending data files folder
                    isDone = FileProcessorUtility.MoveFile(
                                    SettingsUtility.GetCommonDataPath(CommonDataSettingTypes.LiveDataFile_Folder, deviceName) + newName,
                                    SettingsUtility.GetCommonDataPath(CommonDataSettingTypes.PendingDataFiles_Folder, deviceName) + newName);
                }
                return isDone;
            }
            catch
            {
                throw;
            }
        }
    }
}
