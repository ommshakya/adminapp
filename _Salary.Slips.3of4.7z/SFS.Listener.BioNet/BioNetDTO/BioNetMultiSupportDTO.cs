﻿using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Sockets;
using System.Threading;

namespace SFS.Listener.BioNet.BioNetDTO
{
    /// <summary>
    /// DTO class for supporting the multiple surgeries implementation of BioNet.
    /// </summary>
    public static class BioNetMultiSupportDTO
    {
        /// <summary>
        /// Property to check whether BioNet listener is running or not.
        /// </summary>
        public static bool isBioNetListenerRunning;
        /// <summary>
        /// Collection of BioNet connected clients/monitors.
        /// </summary>
        public static Dictionary<Guid, IPAddress> BioNetConnectedClients;
        /// <summary>
        /// Collection of BioNet connected tcp clients.
        /// </summary>
        public static Dictionary<Guid, TcpClient> BioNetConnectedClientTcpClient;
        /// <summary>
        /// Collection of BioNet data transfer threads of connected client/monitor.
        /// </summary>
        public static Dictionary<Guid, Thread> BioNetConnectedClientDataTransferThreads;
        /// <summary>
        /// Collection of BioNet data transfer timers if thread of connected client/monitor.
        /// </summary>
        public static Dictionary<Guid, System.Timers.Timer> BioNetConnectedClientDataTransferThreadTimers;
    }
}
