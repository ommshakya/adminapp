﻿using SFS.CommonUtilities;
using System;
using System.Collections.Generic;

namespace SFS.Listener.DigiCare
{
    public static class DigicareDataPacketParser
    {
        /// <summary>
        /// Method to Parse PARAMETER_DATA packet.
        /// </summary>
        /// <param name="bytes_PARAMETER_DATA"></param>
        /// <returns></returns>
        /// <CreatedBy>Om Shakya</CreatedBy>
        /// <CreatedDate>Sep 2015</CreatedDate>
        /// <ModifyBy>...</ModifyBy>
        /// <ModifyDate>...</ModifyDate>

        public static Dictionary<string, string> Parse_OBSERVATION_DATA(byte[] bytes_OBSERVATION_DATA)
        {
            try
            {
                Dictionary<string, string> parsed_PARAMETER_DATA = new Dictionary<string, string>();

                if (bytes_OBSERVATION_DATA != null && bytes_OBSERVATION_DATA.Length > 0)
                {
                    UInt16 HR = GeneralMethodsUtility.ConvertTwoBytesToUInt16(GeneralMethodsUtility.ExtractBytes(bytes_OBSERVATION_DATA, 1, 2));
                    parsed_PARAMETER_DATA.Add("HR_HeartRate", HR.ToString());

                    ushort SpO2Value = GeneralMethodsUtility.ConvertOneByteToUShort(bytes_OBSERVATION_DATA[3]);
                    parsed_PARAMETER_DATA.Add("SpO2Value", SpO2Value.ToString());

                    ushort RespRate = GeneralMethodsUtility.ConvertOneByteToUShort(bytes_OBSERVATION_DATA[22]);
                    parsed_PARAMETER_DATA.Add("RespRate", RespRate.ToString());

                    UInt16 NiBpSysDataHigh = GeneralMethodsUtility.ConvertTwoBytesToUInt16(GeneralMethodsUtility.ExtractBytes(bytes_OBSERVATION_DATA, 6, 2));
                    parsed_PARAMETER_DATA.Add("NiBpSysDataHigh", NiBpSysDataHigh.ToString());

                    UInt16 NiBpMeanDataHigh = GeneralMethodsUtility.ConvertTwoBytesToUInt16(GeneralMethodsUtility.ExtractBytes(bytes_OBSERVATION_DATA, 10, 2));
                    parsed_PARAMETER_DATA.Add("NiBpMeanDataHigh", NiBpMeanDataHigh.ToString());

                    UInt16 NiBpDiaDataHigh = GeneralMethodsUtility.ConvertTwoBytesToUInt16(GeneralMethodsUtility.ExtractBytes(bytes_OBSERVATION_DATA, 8, 2));
                    parsed_PARAMETER_DATA.Add("NiBpDiaDataHigh", NiBpDiaDataHigh.ToString());

                    UInt16 TempDataRe = GeneralMethodsUtility.ConvertTwoBytesToUInt16(GeneralMethodsUtility.ExtractBytes(bytes_OBSERVATION_DATA, 23, 2));
                    parsed_PARAMETER_DATA.Add("Temp1", (TempDataRe / 100.0).ToString());

                    ushort CO2Value = GeneralMethodsUtility.ConvertOneByteToUShort(bytes_OBSERVATION_DATA[20]);
                    parsed_PARAMETER_DATA.Add("EtCO2", CO2Value.ToString());
                }

                return parsed_PARAMETER_DATA;
            }
            catch
            {
                throw;
            }
        }
    }
}
