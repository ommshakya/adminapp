﻿using System;
using System.Net;

namespace SFS.ObjectSerializer
{
    /// <summary>
    /// Surgery Monitor serialized DTO.
    /// </summary>
    /// <CreatedBy>Om Shakya</CreatedBy>
    /// <CreatedDate>Nov 2016</CreatedDate>
    /// <ModifyBy>...</ModifyBy>
    /// <ModifyDate>...</ModifyDate>
    [Serializable]
    public class StopMonitorBasedOnStatusCode
    {
        public Guid monitorId { get; set; }
        public HttpStatusCode httpStatusCode { get; set; }
    }
}
