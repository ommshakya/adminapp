﻿namespace SFS.FileWritter
{
    /// <summary>
    /// Enum for device identifier.
    /// </summary>
    /// <CreatedDate>Aug 2016</CreatedDate>
    /// <ModifyBy>...</ModifyBy>
    /// <ModifyDate>...</ModifyDate>
    public enum DeviceIdentifier
    {
        None,
        BioNet,
        DigiCare,
        ServiceBusEndPoint,
        Monitors,
        SurgeryApiKey,
        AdminApp,
        Cardell,
        VetLand,
        InstallCode
    }
}
