﻿using SFS.ConfigManager;
using System;

namespace SFS.Listener.BioNet.BioNetUtility
{

    /// <summary>
    /// BioNet Utility DataPackets Class.
    /// </summary>
    /// <CreatedBy>Om Shakya</CreatedBy>
    /// <CreatedDate>Sep 2015</CreatedDate>
    /// <ModifyBy>...</ModifyBy>
    /// <ModifyDate>...</ModifyDate>
    public static class BioNetUtilityDataPackets
    {
        /// <summary>
        /// Get Parameter_Data_Length (It is fixed as per Bionet protocol documentation).
        /// </summary>
        /// <CreatedBy>Om Shakya</CreatedBy>
        /// <CreatedDate>Sep 2015</CreatedDate>
        /// <ModifyBy>...</ModifyBy>
        /// <ModifyDate>...</ModifyDate>
        public static int Parameter_Data_Length
        {
            get { return AppConfigurations.BioNet_Parameter_Data_Length; }
        }

        /// <summary>
        /// Method PARAMETER_DATA, it forms the PARAMETER_DATA.
        /// </summary>
        /// <returns></returns>
        public static byte[] PARAMETER_DATA()
        {
            byte[] bytes_Parameter_Data = null;
            try
            {
                bytes_Parameter_Data = new byte[53];
                bytes_Parameter_Data[0] = 0xD1;

                // ECG Para-meter & Alarm ECG alarm  -- 0x00 : normal 0x01 : lead fault 0x02 : HR alarm 0x03 : ASYSTOLE 0x04 : VTAC/VFIB 0x05 : VTAC
                bytes_Parameter_Data[1] = 0x01;

                //-----------------------------------------------------------------------
                bool isLittleEndian = BitConverter.IsLittleEndian;

                //HR
                UInt16 HR = AppConfigurations.Simulator_Value_HR;
                byte[] bytes_HR = BitConverter.GetBytes(HR);
                if (isLittleEndian)
                    Array.Reverse(bytes_HR);
                bytes_HR.CopyTo(bytes_Parameter_Data, 2);

                //SpO2
                byte SpO2_Perc = AppConfigurations.Simulator_Value_SPO2;
                bytes_Parameter_Data[10] = SpO2_Perc;

                //RR
                byte RR = AppConfigurations.Simulator_Value_RR;
                bytes_Parameter_Data[14] = RR;

                //Systolic_BP  -- SBP
                UInt16 Systolic_BP = AppConfigurations.Simulator_Value_SBP;
                byte[] bytes_Systolic_BP = BitConverter.GetBytes(Systolic_BP);
                if (isLittleEndian)
                    Array.Reverse(bytes_Systolic_BP);
                bytes_Systolic_BP.CopyTo(bytes_Parameter_Data, 16);

                //Mean_BP  -- MAP
                UInt16 Mean_BP = AppConfigurations.Simulator_Value_MAP;
                byte[] bytes_Mean_BP = BitConverter.GetBytes(Mean_BP);
                if (isLittleEndian)
                    Array.Reverse(bytes_Mean_BP);
                bytes_Mean_BP.CopyTo(bytes_Parameter_Data, 18);

                //DIA_BP  -- DBP
                UInt16 DIA_BP = AppConfigurations.Simulator_Value_DBP;
                byte[] bytes_DIA_BP = BitConverter.GetBytes(DIA_BP);
                if (isLittleEndian)
                    Array.Reverse(bytes_DIA_BP);
                bytes_DIA_BP.CopyTo(bytes_Parameter_Data, 20);

                //TEMP1 -- Part1
                byte TEMP1_part1 = AppConfigurations.Simulator_Value_Temp_Part1;
                bytes_Parameter_Data[24] = TEMP1_part1;
                //TEMP1 -- Part2
                byte TEMP1_part2 = AppConfigurations.Simulator_Value_Temp_Part2;
                bytes_Parameter_Data[25] = TEMP1_part2;

                //EtCO2
                byte EtCO2 = AppConfigurations.Simulator_Value_ETCO2;
                bytes_Parameter_Data[48] = EtCO2;
                //-----------------------------------------------------------------------

                //ST -- 3.25mV , 1st part
                byte ST_part1 = 3;
                bytes_Parameter_Data[4] = ST_part1;

                //ST -- 3.25mV, 2nd part
                byte ST_part2 = 25;
                bytes_Parameter_Data[5] = ST_part2;

                // PVC  -- 0x00 : 0 ~ 0x12C : 300
                UInt16 PVC = 299;
                byte[] bytes_PVC = BitConverter.GetBytes(PVC);
                bytes_PVC.CopyTo(bytes_Parameter_Data, 6);

                //Pacemaker -- 0x00: none , 0x01 : detected
                //SpO2 alarm -- 0x00 : normal , 0x01 : % alarm, 0x02 : Rate alarm, 0x03 : lead fault, 0x04 : check probe, 0x05 : pulse search, 0x06 : poor signal, 0x07 : lost pulse
                bytes_Parameter_Data[8] = 0x01;
                bytes_Parameter_Data[9] = 0x02;

                // SpO2_R2  -- 0x00 : 0 ~ 0x12C: 300
                UInt16 SpO2_R2 = 299;
                byte[] bytes_SpO2_R2 = BitConverter.GetBytes(SpO2_R2);
                bytes_SpO2_R2.CopyTo(bytes_Parameter_Data, 11);

                //RR alarm -- 0x00 : normal 0x01 : RR alarm 0x02 : APNEA
                bytes_Parameter_Data[13] = 0x02;

                //NIBP alarm --  0x00 : normal , 0x01 : BP alarm, 0x02 : Check sensor, 0x03 : over pressure, 0x04 : overtime pressure, 0x05 : Inflation failure
                // 0x06 : deflation failure, 0x07 : Air leak, 0x08 : Measurement error, 0x09 : excessive motion, 0x0A : measure time exceeded, 0x0B : pulse too week
                bytes_Parameter_Data[15] = 0x03;

                //Pulse_Rate -- 0x00 : 0 ~ 0xFF : 255
                byte Pulse_Rate = 75;
                bytes_Parameter_Data[22] = Pulse_Rate;

                //TEMP1 alarm -- 0x00 : normal , 0x01 : lead fault
                bytes_Parameter_Data[23] = 0x01;

                //TEMP2 alarm -- 0x00 : normal , 0x01 : lead fault
                bytes_Parameter_Data[26] = 0x01;

                //TEMP2 -- 110.2F -- 1st part 110
                byte TEMP2_part1 = 110;
                bytes_Parameter_Data[27] = TEMP2_part1;

                //TEMP2 -- Ex: 110.2F -- 2nd part 2
                byte TEMP2_part2 = 2;
                bytes_Parameter_Data[28] = TEMP2_part2;

                //IBP1 alarm -- 0x00 : normal , 0x01 : lead fault 0x02 : disconnect, 0x03 : Abnormal BP
                bytes_Parameter_Data[29] = 0x03;

                // Systolic BP (IBP1)  -- 0x00( - 50 ) ~ 0x190 ( 350 )
                UInt16 Systolic_BP_IBP1 = 120;
                byte[] bytes_Systolic_BP_IBP1 = BitConverter.GetBytes(Systolic_BP_IBP1);
                bytes_Systolic_BP_IBP1.CopyTo(bytes_Parameter_Data, 30);

                // Mean BP (IBP1)  -- 0x00( - 50 ) ~ 0x190 ( 350 )
                UInt16 Mean_BP_IBP1 = 93;
                byte[] bytes_Mean_BP_IBP1 = BitConverter.GetBytes(Mean_BP_IBP1);
                bytes_Mean_BP_IBP1.CopyTo(bytes_Parameter_Data, 32);

                // Diastolic BP (IBP1)  -- 0x00( - 50 ) ~ 0x190 ( 350 )
                UInt16 Diastolic_BP_IBP1 = 80;
                byte[] bytes_Diastolic_BP_IBP1 = BitConverter.GetBytes(Diastolic_BP_IBP1);
                bytes_Diastolic_BP_IBP1.CopyTo(bytes_Parameter_Data, 34);

                // Pulse Rate (IBP1)  -- 0x00( - 50 ) ~ 0x12C ( 300 )
                UInt16 Pulse_Rate_IBP1 = 300;
                byte[] bytes_Pulse_Rate_IBP1 = BitConverter.GetBytes(Pulse_Rate_IBP1);
                bytes_Pulse_Rate_IBP1.CopyTo(bytes_Parameter_Data, 36);

                //IBP2 alarm -- 0x00 : normal , 0x01 : lead fault 0x02 : disconnect , 0x03 : Abnormal BP
                bytes_Parameter_Data[38] = 0x03;

                // Systolic BP (IBP2)  -- 0x00( - 50 ) ~ 0x190 ( 350 )
                UInt16 Systolic_BP_IBP2 = 350;
                byte[] bytes_Systolic_BP_IBP2 = BitConverter.GetBytes(Systolic_BP_IBP2);
                bytes_Systolic_BP_IBP2.CopyTo(bytes_Parameter_Data, 39);

                // Mean BP (IBP2)  -- 0x00( - 50 ) ~ 0x190 ( 350 )
                UInt16 Mean_BP_IBP2 = 350;
                byte[] bytes_Mean_BP_IBP2 = BitConverter.GetBytes(Mean_BP_IBP2);
                bytes_Mean_BP_IBP2.CopyTo(bytes_Parameter_Data, 41);

                // Diastolic BP (IBP2)  -- 0x00( - 50 ) ~ 0x190 ( 350 )
                UInt16 Diastolic_BP_IBP2 = 350;
                byte[] bytes_Diastolic_BP_IBP2 = BitConverter.GetBytes(Diastolic_BP_IBP2);
                bytes_Diastolic_BP_IBP2.CopyTo(bytes_Parameter_Data, 43);

                // Pulse Rate (IBP2)  -- 0x00( - 50 ) ~ 0x12C ( 300 )
                UInt16 Pulse_Rate_IBP2 = 300;
                byte[] bytes_Pulse_Rate_IBP2 = BitConverter.GetBytes(Pulse_Rate_IBP2);
                bytes_Pulse_Rate_IBP2.CopyTo(bytes_Parameter_Data, 45);

                //EtCO2 alarm -- 0x00 : normal , 0x01 : lead fault , 0x02 : Abnormal, 0x03 : system fault , 0x04 : APNEA, 0x05 : PURGE Progress
                //0x06 : SFM progress , 0x07 : SFM Request
                bytes_Parameter_Data[47] = 0x04;

                //FiCO2 -- 0x00 : 0 ~ 0x14 : 20
                byte FiCO2 = 20;
                bytes_Parameter_Data[49] = FiCO2;

                //Airway RR -- 0x00 : 0 ~ 0x78 : 120
                byte Airway_RR = 120;
                bytes_Parameter_Data[50] = Airway_RR;

                //Respiration Selection -- 0x00 : RR from Impedance, 0x01: Airway RR from EtCO2
                bytes_Parameter_Data[51] = 0x01;

                //16 - bed number
                byte bedNum = 16;
                bytes_Parameter_Data[52] = bedNum;
                return bytes_Parameter_Data;
            }
            catch
            {
                throw;
            }
        }
    }
}
