﻿using SFS.ConfigManager;

namespace SFS.Listener.Vetland.VetlandUtility
{
    /// <summary>
    /// Vetland Utility DataPackets Class.
    /// </summary>
    /// <CreatedBy>Om Shakya</CreatedBy>
    /// <CreatedDate>Sep 2015</CreatedDate>
    /// <ModifyBy>...</ModifyBy>
    /// <ModifyDate>...</ModifyDate>
    public static class VetlandUtilityDataPackets
    {
        public static int Data_Font_Length
        {
            get { return AppConfigurations.Vetland_Font_Data_Length; }
        }
    }
}
