﻿using SFS.CommonUtilities;
using System.Collections.Generic;

namespace SFS.Listener.DigiCare.DigiCareUtility
{
    /// <summary>
    /// Digicare Utility Packets Slicer class.
    /// </summary>
    /// <CreatedBy>Om Shakya</CreatedBy>
    /// <CreatedDate>Sep 2015</CreatedDate>
    /// <ModifyBy>...</ModifyBy>
    /// <ModifyDate>...</ModifyDate>
    public static class DigicareUtilityPacketsSlicer
    {
        /// <summary>
        /// Method to slice packets.
        /// </summary>
        /// <param name="bytes"></param>
        /// <param name="identifier"></param>
        /// <returns></returns>
        /// <CreatedDate>Aug 2016</CreatedDate>
        /// <ModifyBy>...</ModifyBy>
        /// <ModifyDate>...</ModifyDate>
        public static Dictionary<string, byte[]> SlicePackets(byte[] bytes, DigicarePacketsComboIdentifier identifier)
        {
            Dictionary<string, byte[]> slices = new Dictionary<string, byte[]>();
            try
            {
                if (bytes != null)
                {
                    switch (identifier)
                    {
                        case DigicarePacketsComboIdentifier.ADMIT_UNITS_PacketsCombo:
                            slices.Add(DigicareUtilityPacketNames.INFO_ADMIT,
                                        GeneralMethodsUtility.ExtractBytes(bytes, 0
                                                                                , DigicareUtilityInformationPackets.Info_Admit_Length));
                            slices.Add(DigicareUtilityPacketNames.INFO_UNITS,
                                        GeneralMethodsUtility.ExtractBytes(bytes, DigicareUtilityInformationPackets.Info_Admit_Length
                                                                                , DigicareUtilityInformationPackets.Info_Units_Length));
                            break;
                        case DigicarePacketsComboIdentifier.OBSERVATION_Packet:
                            slices.Add(DigicareUtilityPacketNames.DATA_OBSERVATION,
                                        GeneralMethodsUtility.ExtractBytes(bytes, 0
                                                                                , DigicareUtilityDataPackets.Data_Observation_Length));
                            break;
                    }
                }
                return slices;
            }
            catch
            {
                throw;
            }
        }
    }
}
