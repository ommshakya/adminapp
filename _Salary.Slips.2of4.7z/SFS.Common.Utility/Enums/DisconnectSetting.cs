﻿namespace SFS.CommonUtilities.Enums
{
    /// <summary>
    /// Enum for disconnect setting.
    /// </summary>
    /// <CreatedBy>Om Shakya</CreatedBy>
    /// <CreatedDate>Aug 2016</CreatedDate>
    /// <ModifyBy>...</ModifyBy>
    /// <ModifyDate>...</ModifyDate>
    public enum DisconnectSetting
    {
        None,
        False,
        True
    }
}
