﻿using System;
using System.Net;

namespace SFS.ObjectSerializer
{
    /// <summary>
    /// Surgery Monitor serialized DTO.
    /// </summary>
    /// <CreatedBy>Om Shakya</CreatedBy>
    /// <CreatedDate>Aug 2016</CreatedDate>
    /// <ModifyBy>...</ModifyBy>
    /// <ModifyDate>...</ModifyDate>
    [Serializable]
    public class SurgeryMonitor
    {
        public Guid monitorId { get; set; }
        public string name { get; set; }
        public string objectType { get; set; }
        public IPAddress monitorIPAddress { get; set; }
        public string deviceName { get; set; }
    }
}
