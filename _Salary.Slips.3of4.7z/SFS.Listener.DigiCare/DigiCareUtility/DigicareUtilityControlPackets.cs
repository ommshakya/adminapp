﻿using SFS.ConfigManager;

namespace SFS.Listener.DigiCare.DigiCareUtility
{
    /// <summary>
    /// Digicare Utility Control Packets Class.
    /// </summary>
    /// <CreatedBy>Om Shakya</CreatedBy>
    /// <CreatedDate>Sep 2015</CreatedDate>
    /// <ModifyBy>...</ModifyBy>
    /// <ModifyDate>...</ModifyDate>
    public static class DigicareUtilityControlPackets
    {
        /// <summary>
        /// Get Connect_Req_Length.
        /// </summary>
        /// <CreatedDate>Aug 2016</CreatedDate>
        /// <ModifyBy>...</ModifyBy>
        /// <ModifyDate>...</ModifyDate>
        public static int Connect_Req_Length
        {
            get { return AppConfigurations.Digicare_Connect_Req_Length; }
        }
        /// <summary>
        /// Get Connect_Accept_Length.
        /// </summary>
        /// <CreatedDate>Aug 2016</CreatedDate>
        /// <ModifyBy>...</ModifyBy>
        /// <ModifyDate>...</ModifyDate>
        public static int Connect_Accept_Length
        {
            get { return AppConfigurations.Digicare_Connect_Accept_Length; ; }
        }
        /// <summary>
        /// Get Disconnect_Req_Length.
        /// </summary>
        /// <CreatedDate>Aug 2016</CreatedDate>
        /// <ModifyBy>...</ModifyBy>
        /// <ModifyDate>...</ModifyDate>
        public static int Disconnect_Req_Length
        {
            get { return AppConfigurations.Digicare_Disconnect_Req_Length; }
        }
        /// <summary>
        /// Method CONNECT_REQ.
        /// </summary>
        /// <returns></returns>
        /// <CreatedDate>Aug 2016</CreatedDate>
        /// <ModifyBy>...</ModifyBy>
        /// <ModifyDate>...</ModifyDate>
        public static byte[] CONNECT_REQ()
        {
            byte[] bytes = null;
            try
            {
                bytes = new byte[Connect_Req_Length];
                bytes[0] = 0xC0;
                bytes[1] = 0x01;
                bytes[2] = 16;
                return bytes;
            }
            catch
            {
                throw;
            }
        }
        /// <summary>
        /// Method CONNECT_ACCEPT.
        /// </summary>
        /// <param name="bedNum"></param>
        /// <returns></returns>
        /// <CreatedDate>Aug 2016</CreatedDate>
        /// <ModifyBy>...</ModifyBy>
        /// <ModifyDate>...</ModifyDate>
        public static byte[] CONNECT_ACCEPT(ushort bedNum)
        {
            byte[] bytes = null;
            try
            {
                bytes = new byte[Connect_Accept_Length];
                bytes[0] = 0xC0;
                bytes[1] = 0x02;
                bytes[2] = (byte)bedNum;
                return bytes;
            }
            catch
            {
                throw;
            }
        }
        /// <summary>
        /// Method DISCONNECT_REQ.
        /// </summary>
        /// <returns></returns>
        /// <CreatedDate>Aug 2016</CreatedDate>
        /// <ModifyBy>...</ModifyBy>
        /// <ModifyDate>...</ModifyDate>
        public static byte[] DISCONNECT_REQ()
        {
            byte[] bytes = null;
            try
            {
                bytes = new byte[Disconnect_Req_Length];
                bytes[0] = 0xC0;
                bytes[1] = 0x03;
                bytes[2] = 16;
                return bytes;
            }
            catch
            {
                throw;
            }
        }
        /// <summary>
        /// Method DO_NOT_CONNECT_ACCEPT.
        /// </summary>
        /// <returns></returns>
        /// <CreatedDate>Aug 2016</CreatedDate>
        /// <ModifyBy>...</ModifyBy>
        /// <ModifyDate>...</ModifyDate>
        public static byte[] DO_NOT_CONNECT_ACCEPT()
        {
            byte[] bytes = null;
            try
            {
                bytes = new byte[3] { 0xC0, 0x00, 0x00 };
                return bytes;
            }
            catch
            {
                throw;
            }
        }
    }
}
