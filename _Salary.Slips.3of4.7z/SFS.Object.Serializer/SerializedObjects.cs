﻿using SFS.CommonUtilities;
using SFS.CommonUtilities.Enums;
using SFS.FileWritter;
using smartflowsheet.surgery.api.model.events;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;

namespace SFS.ObjectSerializer
{
    /// <summary>
    /// Class for serialized objects.
    /// </summary>
    /// <CreatedDate>Aug 2016</CreatedDate>
    /// <ModifyBy>...</ModifyBy>
    /// <ModifyDate>...</ModifyDate>
    public static class SerializedObjects
    {
        /// <summary>
        /// Method to get monitor list.
        /// </summary>
        /// <CreatedBy>Om Shakya</CreatedBy>
        /// <CreatedDate>Aug 2016</CreatedDate>
        /// <ModifyBy>...</ModifyBy>
        /// <ModifyDate>...</ModifyDate>
        public static List<SurgeryMonitor> MonitorsList
        {
            get
            {
                List<SurgeryMonitor> list = new List<SurgeryMonitor>();
                try
                {
                    string DirectoryPath = SettingsUtility.GetCommonDataPath(CommonDataSettingTypes.ServiceBusEndPoint, DeviceIdentifier.Monitors);
                    if (System.IO.Directory.Exists(DirectoryPath))
                    {
                        string[] allFiles = System.IO.Directory.GetFiles(DirectoryPath, "SFS.Monitor.*");
                        foreach (string file in allFiles)
                        {
                            list.Add(Serializer.ReadFromBinaryFile<SurgeryMonitor>(file));
                        }
                    }
                    return list;
                }
                catch
                {
                    throw;
                }
            }
        }
        /// <summary>
        /// Method to get surgery monitor end point.
        /// </summary>
        /// <CreatedBy>Om Shakya</CreatedBy>
        /// <CreatedDate>Aug 2016</CreatedDate>
        /// <ModifyBy>...</ModifyBy>
        /// <ModifyDate>...</ModifyDate>
        public static SurgeryMonitorEndPoint SurgeryMonitorEndpoint
        {
            get
            {
                try
                {
                    SurgeryMonitorEndPoint surgeryMonitorEndPointDTO = Serializer.ReadFromBinaryFile<SurgeryMonitorEndPoint>(
                             SettingsUtility.GetCommonDataPath(CommonDataSettingTypes.ServiceBusEndPoint, DeviceIdentifier.ServiceBusEndPoint)
                             + "\\"+ CommonFileNames.SurgeryMonitorEndPointSimulator_FileName);

                    return surgeryMonitorEndPointDTO;
                }
                catch
                {
                    throw;
                }
            }
        }
        /// <summary>
        /// Method to get surgery API key.
        /// </summary>
        /// <CreatedBy>Om Shakya</CreatedBy>
        /// <CreatedDate>Aug 2016</CreatedDate>
        /// <ModifyBy>...</ModifyBy>
        /// <ModifyDate>...</ModifyDate>
        public static string SurgeryApiKey
        {
            get
            {
                try
                {
                    string surgeryApiKey = Serializer.ReadFromBinaryFile<string>(
                             SettingsUtility.GetCommonDataPath(CommonDataSettingTypes.SurgeryApiKey, DeviceIdentifier.SurgeryApiKey)
                             + "\\"+ CommonFileNames.SurgeryApiKey_FileName);

                    return surgeryApiKey;
                }
                catch
                {
                    throw;
                }
            }
        }
        /// <summary>
        /// Method to Get SurgeryMonitor Device.
        /// </summary>
        /// <param name="monitorId"></param>
        /// <returns></returns>
        /// <CreatedBy>Om Shakya</CreatedBy>
        /// <CreatedDate>Oct 2016</CreatedDate>
        /// <ModifyBy>...</ModifyBy>
        /// <ModifyDate>...</ModifyDate>
        public static SurgeryMonitor GetSurgeryMonitorDevice(Guid monitorId)
        {
            SurgeryMonitor monitor = null;
            try
            {
                monitor = MonitorsList.Where(x => x.monitorId.Equals(monitorId)).FirstOrDefault();
                return monitor;
            }
            catch
            {
                throw;
            }
        }
        /// <summary>
        /// Method to Save Monitor To Stop Based On Status Code.
        /// </summary>
        /// <param name="startSurgeryMonitor"></param>
        /// <param name="statusCode"></param>
        /// <param name="deviceIdentifier"></param>
        /// <returns></returns>
        public static bool SaveMonitorToStopBasedOnStatusCode(StartSurgeryMonitor startSurgeryMonitor, HttpStatusCode statusCode, DeviceIdentifier deviceIdentifier)
        {
            bool b = false;
            try
            {
                if (statusCode.Equals(HttpStatusCode.NotFound) || statusCode.Equals(HttpStatusCode.MethodNotAllowed))
                {
                    StopMonitorBasedOnStatusCode obj = new StopMonitorBasedOnStatusCode();
                    obj.monitorId = startSurgeryMonitor.monitorId;
                    obj.httpStatusCode = statusCode;

                    Serializer.WriteToBinaryFile<StopMonitorBasedOnStatusCode>(
                           SettingsUtility.GetCommonDataPath(CommonDataSettingTypes.SettingsContainer_Folder, deviceIdentifier)
                           + "\\MonitorsToStopBasedOnStatusCode\\SFS.Monitor." + startSurgeryMonitor.monitorId.ToString() + ".sfs",
                           obj);

                    b = true;
                }
                return b;
            }
            catch
            {
                throw;
            }
        }
        /// <summary>
        /// Method to Get List Monitors To Stop Based On Status Code.
        /// </summary>
        /// <param name="identifiers"></param>
        /// <returns></returns>
        public static List<StopMonitorBasedOnStatusCode> GetListMonitorsToStopBasedOnStatusCode(DeviceIdentifier identifiers)
        {
            List<StopMonitorBasedOnStatusCode> list = new List<StopMonitorBasedOnStatusCode>();
            try
            {
                string DirectoryPath = SettingsUtility.GetCommonDataPath(CommonDataSettingTypes.SettingsContainer_Folder, identifiers)
                                        + "\\MonitorsToStopBasedOnStatusCode\\";
                if (System.IO.Directory.Exists(DirectoryPath))
                {
                    string[] allFiles = System.IO.Directory.GetFiles(DirectoryPath, "SFS.Monitor.*");
                    foreach (string file in allFiles)
                    {
                        list.Add(Serializer.ReadFromBinaryFile<StopMonitorBasedOnStatusCode>(file));
                    }
                }
                return list;
            }
            catch
            {
                throw;
            }
        }
    }
}
