﻿namespace SFS.Admin.App
{
    partial class frmMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.grpBoxRegisterMonitor = new System.Windows.Forms.GroupBox();
            this.label3 = new System.Windows.Forms.Label();
            this.lblMonitoIPAddress = new System.Windows.Forms.Label();
            this.lblMonitorName = new System.Windows.Forms.Label();
            this.btnCancelRegisterMonitor = new System.Windows.Forms.Button();
            this.btnRegisterMonitor = new System.Windows.Forms.Button();
            this.comboBoxDeviceName = new System.Windows.Forms.ComboBox();
            this.txtMonitoIPAddress = new System.Windows.Forms.TextBox();
            this.txtMonitorName = new System.Windows.Forms.TextBox();
            this.dataGridViewRegisteredMonitors = new System.Windows.Forms.DataGridView();
            this.lblEmailId = new System.Windows.Forms.Label();
            this.lblPassword = new System.Windows.Forms.Label();
            this.txtEmailId = new System.Windows.Forms.TextBox();
            this.txtPassword = new System.Windows.Forms.TextBox();
            this.btnRegisterApplication = new System.Windows.Forms.Button();
            this.btnUnRegisterApplication = new System.Windows.Forms.Button();
            this.grpBoxSignIn = new System.Windows.Forms.GroupBox();
            this.chkShowPassword = new System.Windows.Forms.CheckBox();
            this.btnUnregisterMonitor = new System.Windows.Forms.Button();
            this.linkHelp = new System.Windows.Forms.LinkLabel();
            this.grpBoxRegisterMonitor.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewRegisteredMonitors)).BeginInit();
            this.grpBoxSignIn.SuspendLayout();
            this.SuspendLayout();
            // 
            // grpBoxRegisterMonitor
            // 
            this.grpBoxRegisterMonitor.Controls.Add(this.label3);
            this.grpBoxRegisterMonitor.Controls.Add(this.lblMonitoIPAddress);
            this.grpBoxRegisterMonitor.Controls.Add(this.lblMonitorName);
            this.grpBoxRegisterMonitor.Controls.Add(this.btnCancelRegisterMonitor);
            this.grpBoxRegisterMonitor.Controls.Add(this.btnRegisterMonitor);
            this.grpBoxRegisterMonitor.Controls.Add(this.comboBoxDeviceName);
            this.grpBoxRegisterMonitor.Controls.Add(this.txtMonitoIPAddress);
            this.grpBoxRegisterMonitor.Controls.Add(this.txtMonitorName);
            this.grpBoxRegisterMonitor.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpBoxRegisterMonitor.Location = new System.Drawing.Point(12, 129);
            this.grpBoxRegisterMonitor.Name = "grpBoxRegisterMonitor";
            this.grpBoxRegisterMonitor.Size = new System.Drawing.Size(308, 281);
            this.grpBoxRegisterMonitor.TabIndex = 0;
            this.grpBoxRegisterMonitor.TabStop = false;
            this.grpBoxRegisterMonitor.Text = "Register Monitor";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(23, 144);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(72, 13);
            this.label3.TabIndex = 8;
            this.label3.Text = "Device Name";
            // 
            // lblMonitoIPAddress
            // 
            this.lblMonitoIPAddress.AutoSize = true;
            this.lblMonitoIPAddress.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMonitoIPAddress.Location = new System.Drawing.Point(23, 91);
            this.lblMonitoIPAddress.Name = "lblMonitoIPAddress";
            this.lblMonitoIPAddress.Size = new System.Drawing.Size(96, 13);
            this.lblMonitoIPAddress.TabIndex = 7;
            this.lblMonitoIPAddress.Text = "Monitor IP Address";
            // 
            // lblMonitorName
            // 
            this.lblMonitorName.AutoSize = true;
            this.lblMonitorName.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMonitorName.Location = new System.Drawing.Point(23, 39);
            this.lblMonitorName.Name = "lblMonitorName";
            this.lblMonitorName.Size = new System.Drawing.Size(73, 13);
            this.lblMonitorName.TabIndex = 6;
            this.lblMonitorName.Text = "Monitor Name";
            // 
            // btnCancelRegisterMonitor
            // 
            this.btnCancelRegisterMonitor.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCancelRegisterMonitor.Location = new System.Drawing.Point(160, 207);
            this.btnCancelRegisterMonitor.Name = "btnCancelRegisterMonitor";
            this.btnCancelRegisterMonitor.Size = new System.Drawing.Size(75, 23);
            this.btnCancelRegisterMonitor.TabIndex = 5;
            this.btnCancelRegisterMonitor.Text = "Cancel";
            this.btnCancelRegisterMonitor.UseVisualStyleBackColor = true;
            this.btnCancelRegisterMonitor.Click += new System.EventHandler(this.btnCancelRegisterMonitor_Click);
            // 
            // btnRegisterMonitor
            // 
            this.btnRegisterMonitor.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRegisterMonitor.Location = new System.Drawing.Point(59, 207);
            this.btnRegisterMonitor.Name = "btnRegisterMonitor";
            this.btnRegisterMonitor.Size = new System.Drawing.Size(75, 23);
            this.btnRegisterMonitor.TabIndex = 4;
            this.btnRegisterMonitor.Text = "Register";
            this.btnRegisterMonitor.UseVisualStyleBackColor = true;
            this.btnRegisterMonitor.Click += new System.EventHandler(this.btnRegisterMonitor_Click);
            // 
            // comboBoxDeviceName
            // 
            this.comboBoxDeviceName.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBoxDeviceName.FormattingEnabled = true;
            this.comboBoxDeviceName.Location = new System.Drawing.Point(26, 160);
            this.comboBoxDeviceName.Name = "comboBoxDeviceName";
            this.comboBoxDeviceName.Size = new System.Drawing.Size(254, 21);
            this.comboBoxDeviceName.TabIndex = 3;
            this.comboBoxDeviceName.Text = "Device Name";
            // 
            // txtMonitoIPAddress
            // 
            this.txtMonitoIPAddress.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMonitoIPAddress.Location = new System.Drawing.Point(26, 107);
            this.txtMonitoIPAddress.MaxLength = 15;
            this.txtMonitoIPAddress.Name = "txtMonitoIPAddress";
            this.txtMonitoIPAddress.Size = new System.Drawing.Size(254, 20);
            this.txtMonitoIPAddress.TabIndex = 1;
            // 
            // txtMonitorName
            // 
            this.txtMonitorName.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMonitorName.Location = new System.Drawing.Point(26, 55);
            this.txtMonitorName.MaxLength = 150;
            this.txtMonitorName.Name = "txtMonitorName";
            this.txtMonitorName.Size = new System.Drawing.Size(254, 20);
            this.txtMonitorName.TabIndex = 0;
            // 
            // dataGridViewRegisteredMonitors
            // 
            this.dataGridViewRegisteredMonitors.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewRegisteredMonitors.Location = new System.Drawing.Point(339, 135);
            this.dataGridViewRegisteredMonitors.Name = "dataGridViewRegisteredMonitors";
            this.dataGridViewRegisteredMonitors.ShowEditingIcon = false;
            this.dataGridViewRegisteredMonitors.Size = new System.Drawing.Size(371, 207);
            this.dataGridViewRegisteredMonitors.TabIndex = 2;
            this.dataGridViewRegisteredMonitors.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridViewRegisteredMonitors_CellClick);
            // 
            // lblEmailId
            // 
            this.lblEmailId.AutoSize = true;
            this.lblEmailId.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEmailId.Location = new System.Drawing.Point(23, 28);
            this.lblEmailId.Name = "lblEmailId";
            this.lblEmailId.Size = new System.Drawing.Size(44, 13);
            this.lblEmailId.TabIndex = 3;
            this.lblEmailId.Text = "Email Id";
            // 
            // lblPassword
            // 
            this.lblPassword.AutoSize = true;
            this.lblPassword.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPassword.Location = new System.Drawing.Point(230, 28);
            this.lblPassword.Name = "lblPassword";
            this.lblPassword.Size = new System.Drawing.Size(53, 13);
            this.lblPassword.TabIndex = 4;
            this.lblPassword.Text = "Password";
            // 
            // txtEmailId
            // 
            this.txtEmailId.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtEmailId.Location = new System.Drawing.Point(26, 44);
            this.txtEmailId.Name = "txtEmailId";
            this.txtEmailId.Size = new System.Drawing.Size(187, 20);
            this.txtEmailId.TabIndex = 5;
            // 
            // txtPassword
            // 
            this.txtPassword.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPassword.Location = new System.Drawing.Point(232, 44);
            this.txtPassword.Name = "txtPassword";
            this.txtPassword.PasswordChar = '*';
            this.txtPassword.Size = new System.Drawing.Size(177, 20);
            this.txtPassword.TabIndex = 6;
            // 
            // btnRegisterApplication
            // 
            this.btnRegisterApplication.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRegisterApplication.Location = new System.Drawing.Point(542, 41);
            this.btnRegisterApplication.Name = "btnRegisterApplication";
            this.btnRegisterApplication.Size = new System.Drawing.Size(132, 23);
            this.btnRegisterApplication.TabIndex = 7;
            this.btnRegisterApplication.Text = "Register Application";
            this.btnRegisterApplication.UseVisualStyleBackColor = true;
            this.btnRegisterApplication.Click += new System.EventHandler(this.btnRegisterApplication_Click);
            // 
            // btnUnRegisterApplication
            // 
            this.btnUnRegisterApplication.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnUnRegisterApplication.Location = new System.Drawing.Point(586, 5);
            this.btnUnRegisterApplication.Name = "btnUnRegisterApplication";
            this.btnUnRegisterApplication.Size = new System.Drawing.Size(124, 23);
            this.btnUnRegisterApplication.TabIndex = 8;
            this.btnUnRegisterApplication.Text = "Unregister Application";
            this.btnUnRegisterApplication.UseVisualStyleBackColor = true;
            this.btnUnRegisterApplication.Visible = false;
            this.btnUnRegisterApplication.Click += new System.EventHandler(this.btnUnRegisterApplication_Click);
            // 
            // grpBoxSignIn
            // 
            this.grpBoxSignIn.Controls.Add(this.chkShowPassword);
            this.grpBoxSignIn.Controls.Add(this.btnRegisterApplication);
            this.grpBoxSignIn.Controls.Add(this.lblEmailId);
            this.grpBoxSignIn.Controls.Add(this.lblPassword);
            this.grpBoxSignIn.Controls.Add(this.txtPassword);
            this.grpBoxSignIn.Controls.Add(this.txtEmailId);
            this.grpBoxSignIn.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpBoxSignIn.Location = new System.Drawing.Point(12, 30);
            this.grpBoxSignIn.Name = "grpBoxSignIn";
            this.grpBoxSignIn.Size = new System.Drawing.Size(698, 93);
            this.grpBoxSignIn.TabIndex = 9;
            this.grpBoxSignIn.TabStop = false;
            this.grpBoxSignIn.Text = "Sign In";
            // 
            // chkShowPassword
            // 
            this.chkShowPassword.AutoSize = true;
            this.chkShowPassword.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkShowPassword.Location = new System.Drawing.Point(429, 46);
            this.chkShowPassword.Name = "chkShowPassword";
            this.chkShowPassword.Size = new System.Drawing.Size(102, 17);
            this.chkShowPassword.TabIndex = 9;
            this.chkShowPassword.Text = "Show Password";
            this.chkShowPassword.UseVisualStyleBackColor = true;
            this.chkShowPassword.CheckedChanged += new System.EventHandler(this.chkShowPassword_CheckedChanged);
            // 
            // btnUnregisterMonitor
            // 
            this.btnUnregisterMonitor.Location = new System.Drawing.Point(574, 348);
            this.btnUnregisterMonitor.Name = "btnUnregisterMonitor";
            this.btnUnregisterMonitor.Size = new System.Drawing.Size(136, 23);
            this.btnUnregisterMonitor.TabIndex = 11;
            this.btnUnregisterMonitor.Text = "Unregister Monitor";
            this.btnUnregisterMonitor.UseVisualStyleBackColor = true;
            this.btnUnregisterMonitor.Click += new System.EventHandler(this.btnUnregisterMonitor_Click);
            // 
            // linkHelp
            // 
            this.linkHelp.AutoSize = true;
            this.linkHelp.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.linkHelp.ForeColor = System.Drawing.SystemColors.ControlText;
            this.linkHelp.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline;
            this.linkHelp.LinkColor = System.Drawing.Color.Black;
            this.linkHelp.Location = new System.Drawing.Point(681, 397);
            this.linkHelp.Name = "linkHelp";
            this.linkHelp.Size = new System.Drawing.Size(33, 13);
            this.linkHelp.TabIndex = 12;
            this.linkHelp.TabStop = true;
            this.linkHelp.Text = "Help";
            this.linkHelp.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel1_LinkClicked);
            // 
            // frmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(722, 422);
            this.Controls.Add(this.linkHelp);
            this.Controls.Add(this.btnUnregisterMonitor);
            this.Controls.Add(this.grpBoxSignIn);
            this.Controls.Add(this.dataGridViewRegisteredMonitors);
            this.Controls.Add(this.btnUnRegisterApplication);
            this.Controls.Add(this.grpBoxRegisterMonitor);
            this.Name = "frmMain";
            this.Text = "Surgery Admin";
            this.grpBoxRegisterMonitor.ResumeLayout(false);
            this.grpBoxRegisterMonitor.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewRegisteredMonitors)).EndInit();
            this.grpBoxSignIn.ResumeLayout(false);
            this.grpBoxSignIn.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox grpBoxRegisterMonitor;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label lblMonitoIPAddress;
        private System.Windows.Forms.Label lblMonitorName;
        private System.Windows.Forms.Button btnCancelRegisterMonitor;
        private System.Windows.Forms.Button btnRegisterMonitor;
        private System.Windows.Forms.ComboBox comboBoxDeviceName;
        private System.Windows.Forms.TextBox txtMonitoIPAddress;
        private System.Windows.Forms.TextBox txtMonitorName;
        private System.Windows.Forms.DataGridView dataGridViewRegisteredMonitors;
        private System.Windows.Forms.Label lblEmailId;
        private System.Windows.Forms.Label lblPassword;
        private System.Windows.Forms.TextBox txtEmailId;
        private System.Windows.Forms.TextBox txtPassword;
        private System.Windows.Forms.Button btnRegisterApplication;
        private System.Windows.Forms.Button btnUnRegisterApplication;
        private System.Windows.Forms.GroupBox grpBoxSignIn;
        private System.Windows.Forms.CheckBox chkShowPassword;
        private System.Windows.Forms.Button btnUnregisterMonitor;
        private System.Windows.Forms.LinkLabel linkHelp;
        //private System.Windows.Forms.Label lblNotification;
    }
}

